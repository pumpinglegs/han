import {
  createStackNavigator
} from '@react-navigation/stack';
import React from 'react';
import { useSelector } from 'react-redux';
import { getIsLoading } from '../src/appSlice';
import Login from '../src/auth/Login';
import LoginForm from '../src/auth/LoginForm';
import RegisterForm from '../src/auth/RegisterForm';
import ResetConfirmForm from '../src/auth/ResetConfirmForm';
import ResetPassForm from '../src/auth/ResetPassForm';
import { getIsAuthenticated } from '../src/auth/userSlice';
import VerifyForm from '../src/auth/VerifyForm';
import EventDetailsScreen from '../src/events/EventDetailsScreen';
import PlaceDetailsScreen from '../src/places/PlaceDetailsScreen';
import SplashScreen from '../src/splash/SplashScreen';
import SelectTableScreen from '../src/tables/SelectTableScreen';
import DrawerNavigator from './DrawerNavigator';

export type RootStackParamList = {
  Home: undefined;
  Login: undefined;
  LoginForm: undefined;
  RegisterForm: undefined;
  Verify: undefined;
  PlaceDetails: undefined;
  EventDetails: undefined;
  SelectTable: undefined;
  ResetPass: undefined;
  ResetConfirm: undefined;
};

const Stack = createStackNavigator<RootStackParamList>();

const RootNavigator = () => {
  const isLoading = useSelector(getIsLoading);
  const isLoggedIn = useSelector(getIsAuthenticated);

  if (isLoading) {
    return <SplashScreen />;
  }

  if (!isLoggedIn) {
    return (
      <Stack.Navigator initialRouteName="Login" headerMode="none">
        {getScreens(isLoggedIn)}
      </Stack.Navigator>
    );
  }

  return (
    <Stack.Navigator initialRouteName="Home" headerMode="none">
      {getScreens(isLoggedIn)}
    </Stack.Navigator>
  );
};

const getScreens = (isAuthenticated: boolean) => {
  return (
    <>
      {isAuthenticated ? (
        <></>
      ) : (
        <>
          <Stack.Screen
            name="Login"
            component={Login}
            options={{headerShown: false}}
          />
          <Stack.Screen name="LoginForm" component={LoginForm} />
          <Stack.Screen name="RegisterForm" component={RegisterForm} />
          <Stack.Screen name="Verify" component={VerifyForm} />
          <Stack.Screen name="ResetPass" component={ResetPassForm} />
          <Stack.Screen name="ResetConfirm" component={ResetConfirmForm} />
        </>
      )}
      <Stack.Screen name="Home" component={DrawerNavigator} />
      <Stack.Screen name="PlaceDetails" component={PlaceDetailsScreen} />
      <Stack.Screen name="EventDetails" component={EventDetailsScreen} />
      <Stack.Screen name="SelectTable" component={SelectTableScreen} />
    </>
  );
};

export default RootNavigator;
