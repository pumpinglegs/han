import { createDrawerNavigator } from '@react-navigation/drawer';
import React, { useEffect, useState } from 'react';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import ContactScreen from '../src/contact/ContactScreen';
import EventsScreen from '../src/events/EventsScreen';
import ManagerNavigation from '../src/manager/ManagerNavigation';
import ManagePlace from '../src/manager/screens/ManagePlace';
import MyReservationsScreen from '../src/my-reservations/MyReservationsScreen';
import DrawerContent from '../src/navigation/DrawerContent';
import PlacesScreen from '../src/places/PlacesScreen';
import ProfileScreen from '../src/profile/ProfileScreen';
import messaging from '@react-native-firebase/messaging';
import { updateFcmToken } from '../src/api/user';
import NotificationsScreen from '../src/notifications/NotificationsScreen';
import axios from '../src/axios';
import { useDispatch } from 'react-redux';
import { setUnreadNotifications } from '../src/appSlice';
import { showMessage, hideMessage } from "react-native-flash-message";
import { useNavigation } from '@react-navigation/native';
import PlacesSearchScreen from '../src/places/PlacesSearchScreen';
import TableSchemaScreen from '../src/my-reservations/TableSchemaScreen';

const DrawerNav = createDrawerNavigator();

const getIcon = ({color, size, focused, name}) => {
  return <Icon name={name} size={size} color={color} />;
};

const DrawerNavigator = () => {

  const dispatch = useDispatch();
  const {navigate} = useNavigation();
  const [initialRoute, setInitialRoute] = useState('Places');
  
  useEffect(() => {
    messaging()
      .getToken()
      .then(token => {
        updateFcmToken(token);
      })
      .catch(err => {
        // log
      });

    messaging().onNotificationOpenedApp(remoteMessage => {
      navigate("Notifications");
    });

    // Check whether an initial notification is available
    messaging()
      .getInitialNotification()
      .then(remoteMessage => {
        if (remoteMessage) {
          setInitialRoute("Notifications");
          navigate("Notifications");
        }
      });
      
    setInterval(() => {
        
      // get count of new notifications
      axios.get('/api/notification/count')
        .then((response) => {
          if (response.data?.count) {
            dispatch(setUnreadNotifications(response.data.count));
          }
        })
        .catch(err => {
            // log
        });

    }, 1000 * 120)

    // get unread announcements
    axios.get('/api/notification/announcements')
      .then((response) => {
        if (response.data && response.data.length > 0) {
          showMessage({
            message: response.data[0].data?.title || "",
            type: "info",
            duration: 15000,
            onPress: () => {
              navigate('Notifications');
            }
          });
        }
      })
      .catch(err => {
        // log
      });
  }, []);


  return (
    <DrawerNav.Navigator
      initialRouteName={initialRoute}
      drawerContentOptions={{
        activeTintColor: '#fff',
        inactiveTintColor: '#fff',
      }}
      drawerStyle={{backgroundColor: '#333'}}
      drawerContent={(props) => <DrawerContent {...props} />}>
      <DrawerNav.Screen
        name="Places"
        component={PlacesScreen}
        options={{
          drawerLabel: 'Lokali',
          drawerIcon: (props) => getIcon({...props, name: 'glass-cocktail'}),
        }}
      />

      <DrawerNav.Screen
        name="PlacesSearch"
        component={PlacesSearchScreen}
      />

      <DrawerNav.Screen
        name="Events"
        component={EventsScreen}
        options={{
          drawerLabel: 'Događaji / žurke',
          drawerIcon: (props) => getIcon({...props, name: 'calendar'}),
        }}
      />

      <DrawerNav.Screen
        name="MyReservations"
        component={MyReservationsScreen}
      />

      <DrawerNav.Screen
        name="Notifications"
        component={NotificationsScreen}
      />

      <DrawerNav.Screen
        name="Contact"
        component={ContactScreen}
      />

      <DrawerNav.Screen
        name="Profile"
        component={ProfileScreen}
      />

      <DrawerNav.Screen
        name="ManagePlace"
        component={ManagePlace}
      />

      <DrawerNav.Screen
        name="TableSchema"
        component={TableSchemaScreen}
        />

      <DrawerNav.Screen name="Manager" component={ManagerNavigation} />
    </DrawerNav.Navigator>
  );
};

export default DrawerNavigator;
