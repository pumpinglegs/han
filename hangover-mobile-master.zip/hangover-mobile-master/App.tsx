/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * Generated with the TypeScript template
 * https://github.com/react-native-community/react-native-template-typescript
 *
 * @format
 */
import 'react-native-gesture-handler';

import React, { createContext, useEffect, useMemo, useState } from 'react';
import { Alert, StatusBar, StyleSheet } from 'react-native';
import {
  NavigationContainer,
  DarkTheme as NavigationDarkTheme,
} from '@react-navigation/native';
import { DarkTheme, Portal, Provider as PaperProvider } from 'react-native-paper';

import { Provider as ReduxProvider, useDispatch, useSelector } from 'react-redux';

import store from './src/store';
import RootNavigator from './navigation/RootNavigator';
import { Theme } from 'react-native-paper/lib/typescript/src/types';
import { checkAuth } from './src/auth/checkAuth';
import GlobalSnackbar from './src/GlobalSnackbar';

import i18n from 'i18n-js';
import cg from './src/locales/cg';
import en from './src/locales/en';
import { getLanguage, setLanguage } from './src/auth/userSlice';
import { LocalizationContext } from './src/helpers/contexts';
import LanguageModal from './src/translation/LanguageModal';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getStorageItem } from './src/helpers/asyncStorage';
import { getLangModalVisible } from './src/translation/LanguageModalSlice';
import LocationPickerModal from './src/location-picker/LocationPickerModal';
import messaging from '@react-native-firebase/messaging';
import FlashMessage from 'react-native-flash-message';
import { showMessage, hideMessage } from "react-native-flash-message";
import { useQueryCache } from 'react-query';
import axios from './src/axios';
import { setUnreadNotifications } from './src/appSlice';

const App = () => {
  const dispatch = useDispatch();
  const [locale, setLocale] = useState('');
  const language = useSelector(getLanguage);
  const langModalVisible = useSelector(getLangModalVisible);
  const queryCache = useQueryCache();

  const paperTheme = {
    ...DarkTheme,
    colors: {
      ...DarkTheme.colors,
      primary: '#03a9f4',
    },
  };

  const navTheme = {
    ...NavigationDarkTheme,
    colors: {
      ...NavigationDarkTheme,
      background: '#191919',
    },
  };

  i18n.translations = { cg, en };
  i18n.fallbacks = true;

  const localizationContext = useMemo(
    () => ({
      t: (scope: i18n.Scope, options: i18n.TranslateOptions | undefined) => i18n.t(scope, { locale, ...options }),
      locale,
      setLocale,
    }),
    [locale]
  );

  const loadLang = async () => {
    const lang = await getStorageItem('APP_LANGUAGE') || 'cg';   
    dispatch(setLanguage(lang));
  };

  useEffect(() => {
    if (language) {
      setLocale(language);
    }
  }, [language]);

  useEffect(() => {
    const unsubscribe = messaging().onMessage(async remoteMessage => {
      
      // get count of new notifications
      axios.get('/api/notification/count')
        .then((response) => {
          if (response.data?.count) {
            dispatch(setUnreadNotifications(response.data.count));
          }
        })
        .catch(err => {
            // log
        });

      showMessage({
        message: remoteMessage.notification?.title || "",
        description: remoteMessage.notification?.body || "",
        type: "info",
        duration: 5000,
      });
    });

    return unsubscribe;
  }, []);


  useEffect(() => {
    loadLang();
    checkAuth();
  }, []);

  return (
    <PaperProvider theme={paperTheme}>
      <LocalizationContext.Provider value={localizationContext}>
        <StatusBar
          barStyle="light-content"
          backgroundColor={DarkTheme.colors.background}
        />
        <NavigationContainer theme={navTheme}>
          <Portal.Host>
            <RootNavigator />
            <GlobalSnackbar />
            <LanguageModal language={language} />
            <LocationPickerModal />
          </Portal.Host>
        </NavigationContainer>
      </LocalizationContext.Provider>
    </PaperProvider>
  );
};

export default () => (
  <ReduxProvider store={store}>
    <App />
    <FlashMessage position="top" />
  </ReduxProvider>
);
