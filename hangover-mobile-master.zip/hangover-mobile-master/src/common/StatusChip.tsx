import React, { useContext } from 'react';
import { Chip, useTheme } from 'react-native-paper';
import { LocalizationContext } from '../helpers/contexts';


const StatusChip = ({status}: {status: string}) => {
  const { t } = useContext(LocalizationContext);
  const { colors } = useTheme();  

  const getStatusText = (st: string) => {
    if (st === 'approved') {
      return t('manageReservationsEvent.approved');
    } else if (st === 'pending') {
      return t('manageReservationsEvent.pending');
    } else if (st === 'user-canceled') {
      return t('manageReservationsEvent.userCanceled');
    } else {
      return t('manageReservationsEvent.canceled');
    }
  };

  const getBgColorStatus = (st: string) => {
    switch (st) {
        case 'approved':
          return '#28a745';
        case 'canceled': 
          return '#dc3545';
        case 'user-canceled':
          return '#777777';
        default: 
          return colors.primary;
    }
  }

  const getChipIcon = (st: string) =>{
    switch (st) {
      case 'approved':
        return 'check';
      case 'canceled': 
      case 'user-canceled':
        return 'close';
      default: 
        return 'timer-sand';
    }
  };

  return <Chip icon={getChipIcon(status)} style={{backgroundColor: getBgColorStatus(status)}} textStyle={{fontWeight: 'bold'}}>{getStatusText(status)}</Chip>;
};

export default StatusChip;