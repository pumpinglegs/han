import {useNavigation} from '@react-navigation/native';
import React from 'react';
import {Appbar} from 'react-native-paper';

interface SimpleAppbarProps {
  title: string;
  children?: JSX.Element;
}
const SimpleAppbar = ({title, children}: SimpleAppbarProps) => {
  const {goBack} = useNavigation();

  return (
    <Appbar>
      <Appbar.BackAction onPress={() => goBack()} />
      <Appbar.Content title={title} />
      {children ?? <></>}
    </Appbar>
  );
};

export default SimpleAppbar;
