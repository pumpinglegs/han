import React, {useState} from 'react';
import {Image, StyleSheet, View} from 'react-native';
import {launchImageLibrary} from 'react-native-image-picker';
import {Button, Text} from 'react-native-paper';
import {onChange} from 'react-native-reanimated';

interface ImageInputProps {
  onChange: (value: ImageInputValue) => void;
  onBlur: (value: ImageInputValue) => void;
  value: ImageInputValue;
  label: string;
  disabled: boolean;
}

export interface ImageInputValue {
  uri: string;
  name: string;
  type: string;
  isDefault: boolean;
}

const ImageInput = ({onChange, onBlur, value, label, disabled}: ImageInputProps) => {
  const [photo, setPhoto] = useState(value);

  const handleChoosePhoto = () => {
    const options = {
      mediaType: 'photo',
      maxWidth: 1500,
      maxHeight: 1500,
    };

    launchImageLibrary(options, (response) => {
      if (response.uri) {
        const nextPhoto = {
          uri: response.uri,
          name: response.fileName ?? '',
          type: response.type ?? '',
          isDefault: false,
        };
        setPhoto(nextPhoto);
        onBlur(nextPhoto);
        onChange(nextPhoto);
      }
    });
  };

  return (
    <View style={styles.field}>
      <View style={styles.imageHolder}>
        {photo ? (
          <Image
            source={{uri: photo.uri}}
            style={{width: 100, height: 100, resizeMode: 'contain'}}
          />
        ) : (
          []
        )}
      </View>
      <Button disabled={disabled} onPress={handleChoosePhoto} style={styles.btn}>
        <Text>{label}</Text>
      </Button>
    </View>
  );
};

const styles = StyleSheet.create({
  field: {
    borderWidth: 1,
    borderColor: '#888',
    borderRadius: 3,
  },
  btn: {
    borderTopWidth: 1,
    borderTopColor: '#444',
  },
  imageHolder: {
    flexDirection: 'row',
    justifyContent: 'center',
    backgroundColor: '#000',
  },
});

export default ImageInput;
