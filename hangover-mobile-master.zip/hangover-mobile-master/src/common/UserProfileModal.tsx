import { useNavigation } from '@react-navigation/core';
import React, { useContext, useState } from 'react';
import { Linking, StyleSheet, TouchableHighlight, View } from 'react-native';
import { Portal, Modal, Text, List, Avatar, ActivityIndicator } from 'react-native-paper';
import { getReservationById } from '../api/reservation';
import { getImageUrl } from '../axios';
import { LocalizationContext } from '../helpers/contexts';

const UserProfileModal = (props) => {
  const { navigate } = useNavigation();
  const { t } = useContext(LocalizationContext);
  
  const [userModalVisible, setUserModalVisible] = useState(false);

  const reservationId = props.reservationid;
  const userFullName = props.userFullName;
  const userImage = props.userImage;

  const { data, isLoading } = getReservationById(reservationId);
  
  const user = data?.user;

  const callUser = () => {
    Linking.openURL(`tel:+${user.phone}`);
  }

  const openViber = () => {
    const url = `viber://chat?number=${user.phone}`;
    Linking.openURL(url);
  }

  const openInsta = () => {
    const url = `https://instagram.com/${user.ins_url}/`;
    Linking.openURL(url);
  }

  const reportUser = () => {
    setUserModalVisible(false);
    setTimeout(() => {
      navigate("ReportUser", { userId: user.id });
    }, 0)
  }

  return (
    <>
      <TouchableHighlight onPress={() => setUserModalVisible(true)} style={{borderRadius:50}}>
        <View style={styles.itemUser}>
          <Avatar.Image source={{ uri: getImageUrl(userImage) }} size={32} style={{ backgroundColor: '#444'}} />
          <Text style={styles.itemUsername}>{userFullName}</Text>
        </View>
      </TouchableHighlight>
      <Portal>
        <Modal visible={userModalVisible} onDismiss={() => setUserModalVisible(false)} contentContainerStyle={styles.modal}>
          <View style={styles.modalHeader}>
            <Avatar.Image source={{ uri: getImageUrl(userImage) }} size={140} style={{ backgroundColor: '#444'}} />
            <Text style={{marginTop: 10, fontSize: 18}}>{userFullName}</Text>
          </View>
          <View>
            {
              isLoading ? <ActivityIndicator style={{marginVertical: 20}} /> : !user ? <></> : (
                <>
                  <List.Item left={() => <List.Icon icon="phone" />} title={t('manageReservationsEvent.callUser')} description={'+'+user.phone} onPress={() => callUser()} />
                  { user.has_viber && <List.Item left={() => <List.Icon icon={require('../assets/viber.png')} />} title={t('manageReservationsEvent.openViber')} description={'+'+user.phone} onPress={() => openViber()} /> }
                  { user.ins_url && <List.Item left={() => <List.Icon icon="instagram" />} title={t('manageReservationsEvent.openInsta')} description={user.ins_url} onPress={() => openInsta()} /> }
                  { user.fb_url && <List.Item left={() => <List.Icon icon="facebook" />} title={t('manageReservationsEvent.openFacebook')} description={user.fb_url} onPress={() => Linking.openURL(user.fb_url)} /> }
                  <List.Item left={() => <List.Icon icon="cancel" />} title={t('manageReservationsEvent.reportUser')} onPress={() => reportUser()} />
                </>
              )
            }
          </View>
        </Modal>
      </Portal>
    </>
  );
};

const styles = StyleSheet.create({
  itemUser: {
    flexDirection: 'row', 
    alignItems: 'center',
    borderColor: '#555',
    borderWidth: 1,
    borderRadius: 50
  },
  itemUsername: {
    padding: 6,
    paddingRight: 12
  },
  modal: {
    marginHorizontal: 16,
    backgroundColor: '#333'
  },
  modalHeader: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomColor: '#555',
    borderBottomWidth: 1
  }
});

export default UserProfileModal;