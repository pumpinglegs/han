import React from 'react';
import {StyleSheet, View} from 'react-native';
import {IconButton, Text, Title} from 'react-native-paper';

interface NoResultsProps {
  title: string;
  text: string;
}

const NoResults = ({title, text}: NoResultsProps) => {
  return (
    <View style={styles.container}>
      <Title>{title}</Title>
      <Text style={styles.txt}>{text}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
    paddingHorizontal: 40,
  },
  txt: {
    color: '#999',
    textAlign: 'center',
  },
});

export default NoResults;
