import axios from '../axios';
import {Table} from './types/Table';

export const editTable = async (data: Table) => {
  try {
    const response = await axios.post(
      `/api/place/${data.place_id}/tables/edit/${data.id}`,
      data,
    );
    return response.data;
  } catch (error) {
    if (error.response?.data?.error) {
      return {error: error.response?.data?.error};
    } else {
      return {error: 'common.errorTryAgain'};
    }
  }
};

export const addTable = async (data: any) => {
  try {
    const response = await axios.post(
      `/api/place/${data.place_id}/tables/add`,
      data,
    );
    return response.data;
  } catch (error) {
    if (error.response?.data?.error) {
      return {error: error.response?.data?.error};
    } else {
      return {error: 'common.errorTryAgain'};
    }
  }
};
