import {useQuery} from 'react-query';
import axios from '../axios';

export const getUserProfile = () => {
  return useQuery('getUserProfile', () => {
    return axios.get(`/api/user/profile`).then((response) => {
      // console.log(response.data);
      return response.data;
    });
  });
};

export const updateFcmToken = async (token: string) => {
  try {
    await axios.post('/api/user/fcmtoken', { token });
  } catch (err) {
    // log
  }
};

export const reportUser = async (data: any) => {
  try {
    const response = await axios.post('/api/user/report', data);
    return response.data;
  } catch (e) {
    return { error: 'common.tryAgain' };
  }
};