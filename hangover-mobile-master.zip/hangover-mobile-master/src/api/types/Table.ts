export interface Table {
  id: number;
  name: string;
  place_id: number;
  status: string;
  table_num: number;
}
