export interface User {
    id: number;
    first_name: string | undefined;
    last_name: string | undefined;
    email: string;
    username: string;
    phone: string | undefined;
    active: number;
    image: string;
    ban_count: number;
    role: string;
    created_at: string | null;
    updated_at: string | null;
}