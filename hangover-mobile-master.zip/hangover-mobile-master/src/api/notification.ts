import axios from '../axios';

import {
  useInfiniteQuery,
  useMutation,
  usePaginatedQuery,
  useQuery,
} from 'react-query';

export const getAllNotifications = () => {
  return useInfiniteQuery(
    'getAllNotifications',
    (key, cursor = 1) => {
      return axios.get(`/api/notification?page=${cursor}`).then((response) => {
        return response.data.data;
      });
    },
    {
      getFetchMore: (lastPage, allPages) => {
        if (!lastPage) {
          return 1;
        }
        return lastPage.last_page - lastPage.current_page > 0
          ? lastPage.current_page + 1
          : false;
      },
    },
  );
};

export const updateReadAt = async () => {
  try {
    await axios.post(`/api/notification/readat`, {});
  } catch {}
};