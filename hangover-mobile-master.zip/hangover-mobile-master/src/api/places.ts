import { Platform } from 'react-native';
import {
  useInfiniteQuery,
  useMutation,

  useQuery
} from 'react-query';
import axios from '../axios';
import { Table } from './types/Table';


export const getAllPlaces = (city, query = '') => {
  return useInfiniteQuery(
    ['getAllPlaces', city, query],
    (key, city, query, cursor = 1) => {
      const s = query ? `&s=${query}` : '';
      return axios.get(`/api/place?page=${cursor}&city_id=${city?.id}${s}`).then((response) => {
        return response.data.data;
      });
    },
    {
      enabled: !!city,
      getFetchMore: (lastPage, allPages) => {
        if (!lastPage) {
          return 1;
        }
        return lastPage.last_page - lastPage.current_page > 0
          ? lastPage.current_page + 1
          : false;
      },
    },
  );
};

export const getPlace = (id: string) => {
  return useQuery(
    ['getPlace', id],
    (key, id) => {
      return axios.get(`/api/place/${id}`).then((response) => response.data);
    },
    { enabled: id && id != '0' },
  );
};

export const getPlaceTablesForEvent = (placeId: number, eventId: number) => {
  return useQuery(
    ['getPlaceTablesForEvent', placeId, eventId],
    (key, placeId, eventId) => {
      return axios
        .get(`/api/place/${placeId}/tables/${eventId}`)
        .then((response) => response.data);
    },
  );
};

export const getPlaceTablesAll = (placeId: number) => {
  return useQuery(['getPlaceTablesAll', placeId], (key, placeId) => {
    return axios
      .get<Table[]>(`/api/place/${placeId}/tables/all`)
      .then((response) => response.data);
  });
};

export const createReservation = () => {
  return useMutation(async (data: any) => {
    try {
      const response = await axios.post(`/api/reservation/save`, data);
      return response.data;
    } catch (error) {
      console.log(error.response);
      if (error.response?.data?.error) {
        return { error: error.response?.data?.error };
      } else {
        return { error: 'common.errorTryAgain' };
      }
    }
  });
};

export const editPlace = async (data: any) => {
  try {
    const formData = new FormData();
    if (data.logo_image && !data.logo_image.isDefault) {
      formData.append('logo_image', {
        name: data.logo_image.name,
        type: data.logo_image.type,
        uri:
          Platform.OS == 'android'
            ? data.logo_image.uri
            : data.logo_image.uri.replace('file://', ''),
      });
    }

    if (data.schema_place_image && !data.schema_place_image.isDefault) {
      formData.append('schema_place_image', {
        name: data.schema_place_image.name,
        type: data.schema_place_image.type,
        uri:
          Platform.OS == 'android'
            ? data.schema_place_image.uri
            : data.schema_place_image.uri.replace('file://', ''),
      });
    }

    Object.keys(data).forEach((key) => {
      if (key != 'logo_image' && key != 'schema_place_image') {
        if (data[key]) {
          formData.append(key, data[key]);
        }
      }
    });

    const response = await axios.post(`/api/place/edit/${data.id}`, formData);

    return response.data;
  } catch (error) {
    if (error.response?.data?.error) {
      return { error: error.response?.data?.error };
    } else {
      return { error: 'common.errorTryAgain' };
    }
  }
  // });
};

export const addPlaceImage = async (data: any) => {
  try {
    const formData = new FormData();
    formData.append('slide_image', {
      name: data.slide_image.name,
      type: data.slide_image.type,
      uri:
        Platform.OS == 'android'
          ? data.slide_image.uri
          : data.slide_image.uri.replace('file://', ''),
    });
    formData.append('id', data.id);
    formData.append('title', Math.random().toString(36).substring(7));

    const response = await axios.post(`/api/place/slider/add`, formData);

    return response.data;
  } catch (error) {
    if (error.response?.data?.error) {
      return { error: error.response?.data?.error };
    } else {
      return { error: 'common.errorTryAgain' };
    }
  }
};

export const removePlaceImage = async (id: any) => {
  try {
    const response = await axios.delete(
      `/api/place/slider/remove?image_id=${id}`,
    );
    return response.data;
  } catch (error) {
    if (error.response?.data?.error) {
      return { error: error.response?.data?.error };
    } else {
      return { error: 'common.errorTryAgain' };
    }
  }
};


export const deletePlace = async (placeId: any, tableId: any) => {
  try {
    const response = await axios.delete(`/api/place/${placeId}/tables/delete/${tableId}`);
    return response.data;
  } catch (error) {
    console.log(error.response);
    if (error.response?.data?.error) {
      return { error: error.response?.data?.error };
    } else {
      return { error: 'common.errorTryAgain' };
    }
  }
};