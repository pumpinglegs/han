import { Platform } from 'react-native';
import axios from '../axios';

export const editProfile = async (data: any) => {
    try {
      const formData = new FormData();
      if (data.profile_image && !data.profile_image.isDefault) {
        formData.append('profile_image', {
          name: data.profile_image.name,
          type: data.profile_image.type,
          uri:
            Platform.OS == 'android'
              ? data.profile_image.uri
              : data.profile_image.uri.replace('file://', ''),
        });
      }
  
      Object.keys(data).forEach((key) => {
        if (key != 'profile_image') {
          if (data[key]) {
            formData.append(key, data[key]);
          } else {
            formData.append(key, "");
          }
        }
      });
      
      const response = await axios.post(`/api/user/update`, formData);
  
      return response.data;
    } catch (error) {
      console.log(error.response);
      if (error.response?.data?.error) {
        return { error: error.response?.data?.error };
      } else {
        return { error: 'common.errorTryAgain' };
      }
    }
  };