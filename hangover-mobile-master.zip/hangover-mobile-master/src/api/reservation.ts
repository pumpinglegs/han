import axios from '../axios';

import {
  useInfiniteQuery,
  useMutation,
  usePaginatedQuery,
  useQuery,
} from 'react-query';

export const getAllReservations = () => {
  return useInfiniteQuery(
    'getAllReservations',
    (key, cursor = 1) => {
      console.log("CURSOR:");
      console.log(cursor);
      return axios.get(`/api/reservation?page=${cursor}`).then((response) => {
        return response.data.data;
      });
    },
    {
      getFetchMore: (lastPage, allPages) => {
        if (!lastPage) {
          return 1;
        }
        console.log(allPages.length+1);
        return allPages.length+1;
      },
    },
  );
};


export const getManagerReservations = (status: string, eventId: any) => {
  return useInfiniteQuery(
    ['getManagerReservations', status, eventId],
    (key, status, eventId, cursor = 1) => {
      return axios.get(`/api/reservation/manager?page=${cursor}&event_id=${eventId}&status=${status}`).then((response) => {
        return response.data.data;
      });
    },
    {
      getFetchMore: (lastPage, allPages) => {
        if (!lastPage) {
          return 1;
        }
        return lastPage.last_page - lastPage.current_page > 0
          ? lastPage.current_page + 1
          : false;
      },
    },
  );
};

export const changeStatus = async (status: string, reservation_id: any) => {
  try {
    const response = await axios.post(
      `/api/reservation/status`,
      {
        status,
        reservation_id
      },
    );
    return response.data;
  } catch (error) {
    console.log(error.response);
    if (error.response?.data?.error) {
      return {error: error.response?.data?.error};
    } else {
      return {error: 'common.errorTryAgain'};
    }
  }
}

export const cancelReservation = async (reservation_id: any) => {
  try {
    const response = await axios.post(
      `/api/reservation/cancel`,
      {
        reservation_id
      },
    );
    return response.data;
  } catch (error) {
    return {error: 'common.errorTryAgain'};
  }
}

export const getReservationById = (id) => {
  return useQuery(['getReservationById', id], (key, id) => {
    return axios.get(`/api/reservation/${id}`).then(response => response.data);
  });
}