import { LocalizationContext } from './../helpers/contexts';
import { useContext } from 'react';
// /event/next

import axios from '../axios';

import { useInfiniteQuery, usePaginatedQuery, useQuery } from 'react-query';
import { Platform } from 'react-native';


export const getAllEvents = (city) => {
  return useInfiniteQuery(
    ['getAllEvents', city],
    (key, city, cursor = 1) => {
      return axios
        .get(`/api/event/next?page=${cursor}&city_id=${city?.id}`)
        .then((response) => {
          return response.data.data;
        });
    },
    {
      enabled: !!city,
      getFetchMore: (lastPage, allPages) => {
        if (!lastPage) {
          return 1;
        }
        return lastPage.last_page - lastPage.current_page > 0
          ? lastPage.current_page + 1
          : false;
      },
    },
  );
};

export const getEvent = (id: number) => {
  return useQuery(['getEvent', id], (key, id) => {
    return axios.get(`/api/event/${id}`).then((response) => response.data);
  });
};

export const addEvent = async (data: any) => {
  try {
    const formData = new FormData();
    if (data.event_image && !data.event_image.isDefault) {
      formData.append('event_image', {
        name: data.event_image.name,
        type: data.event_image.type,
        uri:
          Platform.OS == 'android'
            ? data.event_image.uri
            : data.event_image.uri.replace('file://', ''),
      });
    }

    Object.keys(data).forEach((key) => {
      if (key != 'event_image') {
        if (data[key]) {
          formData.append(key, data[key]);
        }
      }
    });

    const response = await axios.post(`/api/event/add`, formData);

    return response.data;
  } catch (error) {
    console.log(error.response);
    if (error.response?.data?.error) {
      return { error: error.response?.data?.error };
    } else {
      return { error: 'common.errorTryAgain' };
    }
  }
};

export const editEvent = async (data: any) => {
  try {
    const formData = new FormData();
    if (data.event_image && !data.event_image.isDefault) {
      formData.append('event_image', {
        name: data.event_image.name,
        type: data.event_image.type,
        uri:
          Platform.OS == 'android'
            ? data.event_image.uri
            : data.event_image.uri.replace('file://', ''),
      });
    }

    Object.keys(data).forEach((key) => {
      if (key != 'event_image') {
        if (data[key]) {
          formData.append(key, data[key]);
        }
      }
    });

    const response = await axios.post(`/api/event/edit/${data.id}`, formData);

    return response.data;
  } catch (error) {
    console.log(error.response);
    if (error.response?.data?.error) {
      return { error: error.response?.data?.error };
    } else {
      return { error: 'common.errorTryAgain' };
    }
  }
};

export const deleteEvent = async (id: any) => {
  try {
    const response = await axios.delete(`/api/event/delete/${id}`);
    return response.data;
  } catch (error) {
    console.log(error.response);
    if (error.response?.data?.error) {
      return { error: error.response?.data?.error };
    } else {
      return { error: 'common.errorTryAgain' };
    }
  }
};

export const addMeToWaitlist = async (id: any, table_id: any) => {
  try {
    const response = await axios.post('/api/event/waitlist', { id, table_id });
    return response.data;
  } catch (error) {
    console.log(error.response);
    if (error.response?.data?.error) {
      return { error: error.response?.data?.error };
    } else {
      return { error: 'common.errorTryAgain' };
    }
  }
}

export const isOnWaitlist = (id: any) => {
  return useQuery(['isOnWaitlist', id], (key, id) => {
    return axios.get(`/api/event/waitlist/${id}`).then((response) => response.data);
  })
}