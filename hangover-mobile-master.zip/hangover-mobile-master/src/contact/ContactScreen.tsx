import { DrawerActions, useNavigation } from '@react-navigation/native';
import React, { useContext } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Linking } from 'react-native';
import {
    Appbar
} from 'react-native-paper';
import { LocalizationContext } from '../helpers/contexts';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';


const ContactScreen = () => {
    const { t } = useContext(LocalizationContext);
    const navigation = useNavigation();

    const openDrawer = () => {
        navigation.dispatch(DrawerActions.openDrawer());
    };

    return (
        <>
            <Appbar>
                <Appbar.Action icon="menu" onPress={() => openDrawer()} />
                <Appbar.Content title={t('drawerContent.contact')} />
            </Appbar>
            <View style={styles.container}>
                <Text style={styles.title}>theHangover team</Text>
                <View style={styles.row}>
                    <Text style={styles.label}>{t('contact.emailLabel')}</Text>
                    <TouchableOpacity onPress={() => Linking.openURL('mailto:contact@thehangover.me')}>
                        <Text style={styles.details}>contact@thehangover.me</Text>
                    </TouchableOpacity>
                </View>
                <View style={styles.row}>
                    <Text style={styles.label}>{t('contact.socialNetworks')}</Text>
                    <View style={styles.socialNetworks}>
                        <TouchableOpacity onPress={() => Linking.openURL('https://www.facebook.com/thehangover.me/')}>
                            <Icon name="facebook" size={35} style={{ marginLeft: 5 }} />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => Linking.openURL('https://www.instagram.com/thehangover.me/')}>
                            <Icon name="instagram" size={35} style={{ marginLeft: 15 }} />
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        </>
    );
};

const styles = StyleSheet.create({
    container: {
        padding: 16
    },
    title: {
        fontSize: 20,
        marginBottom: 30,
        marginTop: 10
    },
    details: {
        fontSize: 16
    },
    label: {
        fontSize: 16,
        fontWeight: 'bold'
    },
    row: {
        marginBottom: 20
    },
    socialNetworks: {
        flexDirection: 'row',
        marginTop: 5,
    }
});

export default ContactScreen;
