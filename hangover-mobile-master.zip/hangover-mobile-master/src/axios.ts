import axios from 'axios';
import { getUserToken, signOut } from './auth/checkAuth';
import { getStorageItem } from './helpers/asyncStorage';

export const getImageUrl = (url) => {
    return "http://hangover.sreten.me/storage/" + url;
};

const instance = axios.create({
    baseURL: process.env.API_URL ? process.env.API_URL : "http://hangover.sreten.me",
    headers: {
        'Content-Type': 'application/json'
    }
});


instance.interceptors.request.use(
    async config => {
        const accessToken = await getUserToken();
        
        if (accessToken) {
            config.headers.common.Authorization = `Bearer ${accessToken}`;
        }

        try {
            const lang = await getStorageItem('APP_LANGUAGE') || 'cg';   
            config.headers.AppLanguage = lang;
        } catch(err){}

        return config;
    },
    error => {
        Promise.reject(error)
});

instance.interceptors.response.use(
    async (response) => {
        if (response.status === 418) {
            await signOut();
        }
        return response;
    },
    error => {
        Promise.reject(error)
    }
)

export default instance;