import React from 'react';
import {Snackbar} from 'react-native-paper';
import {useDispatch, useSelector} from 'react-redux';
import {getSnackbarMessage, getSnackbarVisible, hideSnackbar} from './appSlice';

const GlobalSnackbar = () => {
  const dispatch = useDispatch();
  const visible = useSelector(getSnackbarVisible);
  const message = useSelector(getSnackbarMessage);

  const onClose = () => {
    dispatch(hideSnackbar());
  };

  return (
    <Snackbar visible={visible} onDismiss={onClose} duration={3700}>
      {message}
    </Snackbar>
  );
};

export default GlobalSnackbar;
