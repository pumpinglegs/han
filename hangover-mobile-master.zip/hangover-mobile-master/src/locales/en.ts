export default {
    common: {
        errorTryAgain: 'An unexpected error happened. Please try again.',
        verification: 'Verification',
        error: 'Error',
        unexpectedError: 'An unexpected error happened.',
        fieldRequired: 'This field is required.',
        save: 'Save',
        connectionError: 'An unexpected error happened. Please check your internet connection.',
        imageSaved: 'Image saved successfully.',
        cancel: 'Cancel',
        delete: 'Delete',
        report: 'Report',
        for: 'for',
        logOut: 'Log out',
        language: 'Language',
        searchPlaceholder: 'Search...'
    },
    login: {
        login: 'Login',
        registration: 'Register',
        selectLanguage: 'Choose language'
    },
    loginForm: {
        title: 'Login',
        username: 'Username or phone number',
        password: 'Password',
        logIn: 'Login',
        user_not_existing: "User doesn't exist.",
        forgotPassword: 'Forgot your password?'
    },
    registrationForm: {
        title: 'Registration',
        username: 'Username',
        phoneNumber: 'Phone number',
        register: 'Register',
        usernameError: 'Please enter a valid username.',
        phoneNumberTaken: 'An account with this phone number already exists.',
        usernameTaken: 'An account with this username already exists.'
    },
    eventAvailability: {
        entriesAvailable: 'Tables available'
    },
    eventDetails: {
        reservations: 'Reservations',
    },
    eventsScreen: {
        title: 'Events'
    },
    formAddEvent: {
        eventAddedSuccessfully: 'Event added successfully.',
        addEvent: 'Adding new event',
        description: 'Description',
        descLengthError: 'Description must have more than 10 characters.',
        chooseImage: 'Choose image'
    },
    formAddSlide: {
        addImage: 'Adding new image',
    },
    formAddTable: {
        spotDataSaved: 'Table data saved successfully',
        addPlace: 'Adding new table',
        numOfSpots: 'Number of spots/chairs',
        spotName: 'Table name',
        spotNameLengthError: 'Table name must have at least 3 characters.',
        spotAvailable: 'Table available'
    },
    formEditEvent: {
        eventChangedSuccess: 'Event successfully updated.',
        eventRemovedSuccess: 'Event successfully deleted.',
        editEvent: 'Updating event',
        eventName: 'Event name',
        removeEvent: 'Deleting event',
        removeEventCheck: 'Are you sure you want to delete this event?',
        reservationPossible: 'Reservations allowed'
    },
    formEditTable: {
        editTable: 'Updating table',
        tableNameLengthError: 'Table name must have at least 3 characters',
        deleteTable: 'Deleting table',
        deleteTableCheck: 'Are you sure you want to delete this table',
        tableRemoveSuccess: 'Table successfully deleted.'
    },
    manageEvents: {
        events: 'Events',
        noEvents: 'No events yet',
        noEventsText: 'Press + to create your first event.'
    },
    managePlace: {
        placeSavedSuccess: 'Changes saved successfully.',
        editPlace: 'Updating your place',
        name: 'Name',
        description: 'Description',
        address: 'Address',
        website: 'Website URL',
        chooseLogo: 'Choose logo',
        urlError: 'Enter a valid URL. It must start with https://'
    },
    manageReservations: {
        noEventsText: 'After creating events, you will be able to see them with reservations here.'
    },
    manageReservationsEvent : {
        pending: 'Pending',
        approved: 'Approved',
        canceled: 'Canceled',
        userCanceled: 'User canceled',
        waitlist: 'Waitlist',
        reservations: 'Reservations',
        table: 'Table',
        noReservations: 'No reservations',
        callUser: 'Call user',
        openViber: 'Open viber profile',
        openInsta: 'Open instagram profile',
        openFacebook: 'Open facebook profile',
        thisReservationIsManual: 'This reservation was added by the manager.',
        tableName: 'Table:',
        anyTable: 'Any table'
    },
    manageSchema: {
        schema: 'Blueprint',
        chooseImage: 'Choose blueprint image'
    },
    manageSlider: {
        imageRemoved: 'Image deleted successfully.',
        images: 'Images',
        removeImage: 'Deleting the image',
        removeImageCheck: 'Are you sure you want to delete this image?'
    },
    managerScreen: {
        manager: 'Manager',
        reservations: 'Reservations',
        events: 'Events',
        places: 'Tables',
        schema: 'Blueprint',
        cafe: 'Place',
        images: 'Images',
        report: 'Report',
        reservationsDesc: 'Review, accept and cancel reservations',
        eventsDesc: 'Add and update events',
        placesDesc: 'Add and update tables',
        schemaDesc: 'Update table blueprint',
        cafeDesc: 'Change details about your place',
        imagesDesc: 'Upload images of your place',
        reportDesc: 'Show a report of reservations',
        yourPlaceNotCreated: 'Your place wasn\'t created',
        contactAdmins: 'Contact'
    },
    myReservations: {
        title: 'My reservations'
    },
    reservationListItem: {
        eventDetails: 'Event details',
        spotsSchema: 'Table blueprint',
        paragraphOne: 'You selected table number',
        persons: 'persons',
        cancelReservation: 'Cancel reservation',
        cancelDialogTitle: 'Cancel reservation',
        cancelDialogText: 'Are you sure that you want to cancel your reservation?',
        cancelDialogNo: 'No',
        cancelDialogYes: 'Cancel reservation',
        cancelSuccess: 'Reservation successfully canceled.'
    },
    drawerContent: {
        manager: 'Manager',
        cafes: 'Places',
        events: 'Events',
        notifications: 'Notifications',
        myReservations: 'My reservations',
        contact: 'Contact',
    },
    placeDetails: {
        shortDesc: 'Short description',
        socialNetworks: 'Social',
        events: 'Events',
        info: 'Information',
        location: 'Location',
        openMap: 'Open in maps',
        address: 'Address'
    },
    selectTable: {
        userHasBeenApproved: 'You already have a reservation for this event',
        tooManyReservations: 'You created too many reservations for this date',
        tooManyTableRes: 'Too many reservations for this event',
        resSuccess: 'Your reservation has been sent. Expect a confirmation soon.',
        resSuccessManager: 'You added a reservation successfully.',
        chooseSpot: 'Choose table',
        spotsList: 'List of tables',
        spotsSchema: 'Table blueprint',
        numOfPeople: 'Number of persons',
        reserve: 'Reserve',
        customerName: 'Customer name',
        tableTaken: 'This table is already taken.',
        waitListDescription: 'All tables are reserved. Would you like to be notified if a table becomes available?',
        waitListButton: 'Notify me',
        addedToWaitlist: 'You will be notified if a table becomes available.',
        warningTaken: 'This table already has a reservation! If you create a new reservation, the existing one will be cancelled for user: ',
        tableIsNotAvailable: 'This table already has a reservation. Would you like to be notified if it becomes available?',
        isOnTableWaitlist: 'You will be notified if this table becomes available.',
    },
    languageModal: {
        chooseYourLanguage: 'Choose language',
        montenegrian: 'Montenegrin',
        english: 'English',
        languageSaved: 'Language changed'
    },
    locationPickerModal: {
        chooseCity: 'Choose city'
    },
    contact: {
        emailLabel: 'Email:',
        socialNetworks: 'Social networks',
    },
    verification: {
        wrongCode: 'An error occurred. Did you enter the verification code correctly?',
        errorRepeat: 'To resend SMS you have to wait for ',
        errorRepeatS: ' more seconds.',
        resend: 'Verification code was resent to: +',
        description: 'Confirm your account by entering a password and the verification code that we sent to: ',
        resendBtn: 'Resend SMS',
        keyCodeLabel: 'SMS verification code',
        repeatPassword: 'Repeat password',
        repeatPasswordError: "Passwords don't match.",
        confirmBtn: 'Confirm registration'
    },
    resetForm: {
        resetBtn: 'Continue',
        title: 'Password reset',
        confirmTitle: 'New password',
        confirmPassBtn: 'Confirm password'
    },
    profile: {
        title: 'Profile',
        username: 'Username',
        phone: 'Phone',
        name: 'First name',
        surname: 'Last name',
        email: 'Email',
        image: 'Profile image',
        ins_url: 'Instagram profile (username)',
        fb_url: 'Facebook profile (link)',
        has_viber: 'I use Viber',
        phoneLengthError: 'Phone number must contain at least 9 digits.',
        nameLengthError: 'First name must contain at least 3 characters.',
        surnameLengthError: 'Last name must contain at least 3 characters.',
        emailError: 'Wrong email format.',
        profileEditSuccess: 'Profile updated successfully.',
        date_of_birth: 'Date of birth',
        gender: 'Gender',
        genderMale: 'Male',
        genderFemale: 'Female'
    },
    notifications: {
        title: 'Notifications',
        openEvent: 'Event',
        openReservations: 'Reservations',
        new: 'New'
    },
    managerReport: {
        startDate: 'Start date:',
        endDate: 'End date:',
        status: 'Status:',
        result: 'Number of reservations in selected date and status: '
    },
    reportUser: {
        title: "Report user",
        description: "Reason for reporting",
        reportBtn: "Report",
        userReported: "User reported successfully. theHangover team will review your report and take appropriate action."
    }
}