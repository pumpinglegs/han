export default {
    common: {
        errorTryAgain: 'Došlo je do greške. Pokušajte ponovo.',
        verification: 'Verifikacija',
        error: 'Greška',
        unexpectedError: 'Došlo je do greške.',
        fieldRequired: 'Polje je obavezno.',
        save: 'Sačuvaj',
        connectionError: 'Došlo je do greške. Provjerite internet konekciju.',
        imageSaved: 'Slika uspješno sačuvana.',
        cancel: 'Odustani',
        delete: 'Obriši',
        report: 'Izvještaj',
        for: 'za',
        logOut: 'Odjavi se',
        language: 'Jezik',
        searchPlaceholder: 'Pretraga...'
    },
    login: {
        login: 'Pristup',
        registration: 'Registracija',
        selectLanguage: 'Odaberite jezik'
    },
    loginForm: {
        title: 'Prijava',
        username: 'Korisničko ime ili broj telefona',
        password: 'Lozinka',
        logIn: 'Prijavi se',
        user_not_existing: 'Korisnik ne postoji.',
        forgotPassword: 'Zaboravili ste lozinku?'
    },
    registrationForm: {
        title: 'Registracija',
        username: 'Korisničko ime',
        phoneNumber: 'Broj telefona',
        register: 'Registruj se',
        usernameError: 'Unesite validno korisničko ime.',
        phoneNumberTaken: 'Već postoji korisnik sa ovim brojem telefona.',
        usernameTaken: 'Već postoji korisnik sa ovim korisničkim imenom.'
    },
    eventAvailability: {
        entriesAvailable: 'Mjesta dostupna'
    },
    eventDetails: {
        reservations: 'Rezervacije',
    },
    eventsScreen: {
        title: 'Događaji / žurke'
    },
    formAddEvent: {
        eventAddedSuccessfully: 'Događaj uspješno dodat.',
        addEvent: 'Dodavanje događaja',
        description: 'Opis',
        descLengthError: 'Opis mora imati više od 10 karaktera.',
        chooseImage: 'Odaberi sliku'
    },
    formAddSlide: {
        addImage: 'Dodavanje slike',
    },
    formAddTable: {
        spotDataSaved: 'Podaci o mjestu uspjesno sacuvani.',
        addPlace: 'Dodavanje mjesta',
        numOfSpots: 'Broj mjesta',
        spotName: 'Naziv mjesta',
        spotNameLengthError: 'Ime mjesta mora imati najmanje 3 karaktera.',
        spotAvailable: 'Dostupnost mjesta'
    },
    formEditEvent: {
        eventChangedSuccess: 'Događaj uspješno izmijenjen.',
        eventRemovedSuccess: 'Događaj uspješno obrisan.',
        editEvent: 'Izmjena događaja',
        eventName: 'Naziv događaja',
        removeEvent: 'Brisanje događaja',
        removeEventCheck: 'Da li ste sigurni da želite da obrišete događaj?',
        reservationPossible: 'Mogućnost rezervacije'
    },
    formEditTable: {
        editTable: 'Uređivanje mjesta',
        tableNameLengthError: 'Ime mjesta mora imati najmanje 3 karaktera.',
        deleteTable: 'Brisanje mjesta',
        deleteTableCheck: 'Da li ste sigurni da želite da obrišete mjesto',
        tableRemoveSuccess: 'Mjesto uspješno obrisano.'
    },
    manageEvents: {
        events: 'Događaji',
        noEvents: 'Nema kreiranih događaja',
        noEventsText: 'Pritisni + da kreiraš prvi događaj.'
    },
    managePlace: {
        placeSavedSuccess: 'Podaci o lokalu uspješno sačuvani.',
        editPlace: 'Uređivanje lokala',
        name: 'Ime',
        description: 'Opis',
        address: 'Adresa',
        website: 'Web sajt url',
        chooseLogo: 'Odaberi logo',
        urlError: 'Unesite validan link. Mora počinjati sa https://'
    },
    manageReservations: {
        noEventsText: 'Ovdje će biti prikazani događaji sa pregledom rezervacija.'
    },
    manageReservationsEvent : {
        pending: 'Na čekanju',
        approved: 'Prihvaćeno',
        canceled: 'Nije prihvaćeno',
        userCanceled: 'Otkazano',
        waitlist: 'Lista čekanja',
        reservations: 'Pregled rezervacija',
        table: 'Mjesto',
        noReservations: 'Nema rezervacija',
        callUser: 'Pozovi korisnika',
        openViber: 'Otvori viber profil',
        openInsta: 'Otvori instagram profil',
        openFacebook: 'Otvori facebook profil',
        thisReservationIsManual: 'Ovu rezervaciju je dodao menadžer.',
        reportUser: 'Prijavi korisnika',
        tableName: 'Sto:',
        anyTable: 'Bilo koji sto'
    },
    manageSchema: {
        schema: 'Šema',
        chooseImage: 'Odaberi sliku šeme'
    },
    manageSlider: {
        imageRemoved: 'Slika uspješno obrisana.',
        images: 'Slike',
        removeImage: 'Brisanje slike',
        removeImageCheck: 'Da li ste sigurni da želite da obrišete sliku?'
    },
    managerScreen: {
        manager: 'Menadžer',
        reservations: 'Rezervacije',
        events: 'Događaji',
        places: 'Mjesta',
        schema: 'Šema',
        cafe: 'Lokal',
        images: 'Slike',
        report: 'Izvještaj',
        reservationsDesc: 'Pregled, prihvatanje i odbijanje rezervacija',
        eventsDesc: 'Kreiranje i izmjena događaja',
        placesDesc: 'Podešavanje broja i naziva stolova',
        schemaDesc: 'Uređivanje šeme mjesta',
        cafeDesc: 'Uređivanje podataka o lokalu',
        imagesDesc: 'Uređivanje slika lokala',
        reportDesc: 'Prikaz izvještaja o rezervacijama',
        yourPlaceNotCreated: 'Vaš lokal nije kreiran',
        contactAdmins: 'Kontakt'
    },
    myReservations: {
        title: 'Moje rezervacije'
    },
    reservationListItem: {
        eventDetails: 'Detalji događaja',
        spotsSchema: 'Šema mjesta',
        paragraphOne: 'Izabrali ste sto broj',
        persons: 'osobe',
        cancelReservation: 'Otkaži rezervaciju',
        cancelDialogTitle: 'Otkazivanje rezervacije',
        cancelDialogText: 'Da li ste sigurni da želite da otkažete rezervaciju?',
        cancelDialogNo: 'Odustani',
        cancelDialogYes: 'Otkaži rezervaciju',
        cancelSuccess: 'Rezervacija uspješno otkazana.'
    },
    drawerContent: {
        manager: 'Menadžer',
        cafes: 'Lokali',
        events: 'Događaji / žurke',
        notifications: 'Notifikacije',
        myReservations: 'Moje rezervacije',
        contact: 'Kontakt',
    },
    placeDetails: {
        shortDesc: 'Kratak opis',
        socialNetworks: 'Društvene mreže',
        events: 'Događaji',
        info: 'Informacije',
        location: 'Lokacija',
        openMap: 'Otvori na mapi',
        address: 'Adresa'
    },
    selectTable: {
        userHasBeenApproved: 'Već imate rezervaciju za ovaj događaj',
        tooManyReservations: 'Prešli ste limit mogućih zahtjeva za rezervacije na ovaj dan',
        tooManyTableRes: 'Previše zahtjeva za rezervaciju na ovaj događaj',
        resSuccess: 'Uspješno ste poslali rezervaciju. Očekujte potvrdu u najkraćem roku.',
        resSuccessManager: 'Uspješno ste dodali rezervaciju.',
        chooseSpot: 'Izaberi mjesto',
        spotsList: 'Lista mjesta',
        spotsSchema: 'Šema mjesta',
        numOfPeople: 'Broj osoba',
        reserve: 'Rezerviši',
        customerName: 'Ime i prezime',
        tableTaken: 'Ovo mjesto je već rezervisano',
        waitListDescription: 'Sva mjesta su popunjena. Da li želite da dobijete obavještenje ukoliko se neko mjesto oslobodi?',
        waitListButton: 'Obavijesti me',
        addedToWaitlist: 'Bićete obaviješteni ukoliko se neko mjesto oslobodi.',
        warningTaken: 'Ovo mjesto je već rezervisano! Ukoliko kreirate novu rezervaciju, biće odbijena rezervacija za korisnika: ',
        tableIsNotAvailable: 'Ovo mjesto je već rezervisano. Da li želite da dobijete obavještenje ukoliko oslobodi?',
        isOnTableWaitlist: 'Bićete obaviješteni ukoliko se ovo mjesto oslobodi.',
    },
    languageModal: {
        chooseYourLanguage: 'Odaberite jezik',
        montenegrian: 'Crnogorski',
        english: 'Engleski',
        languageSaved: 'Jezik uspješno sačuvan'
    },
    locationPickerModal: {
        chooseCity: 'Odaberite grad'
    },
    contact: {
        emailLabel: 'Email:',
        socialNetworks: 'Društvene mreže',
    },
    verification: {
        wrongCode: 'Došlo je do greške. Da li ste unijeli ispravan verifikacioni kod?',
        errorRepeat: 'Da bi ponovili slanje SMS-a morate sačekati još ',
        errorRepeatS: ' sekundi.',
        resend: 'Verifikacioni kod je ponovo poslat na broj: +',
        description: 'Potvrdi registraciju unošenjem lozinke i verifikacionog koda koji smo Vam poslali na broj: ',
        resendBtn: 'Pošalji opet SMS',
        keyCodeLabel: 'SMS verifikacioni kod',
        repeatPassword: 'Ponovi lozinku',
        repeatPasswordError: 'Lozinke se ne podudaraju.',
        confirmBtn: 'Potvrdi registraciju'
    },
    resetForm: {
        resetBtn: 'Nastavi',
        title: 'Resetovanje lozinke',
        confirmTitle: 'Nova lozinka',
        confirmPassBtn: 'Potvrdi lozinku'
    },
    profile: {
        title: 'Profil',
        username: 'Korisničko ime',
        phone: 'Tel',
        name: 'ime',
        surname: 'Prezime',
        email: 'Email',
        image: 'Profilna slika',
        ins_url: 'Instagram profil (korisničko ime)',
        fb_url: 'Facebook profil (link)',
        has_viber: 'Imam Viber',
        phoneLengthError: 'Broj telefona mora sadržati najmanje 9 cifara.',
        nameLengthError: 'Ime mora sadržati najmanje 3 karaktera.',
        surnameLengthError: 'Prezime mora sadržati najmanje 3 karaktera.',
        emailError: 'Pogrešan unos email adrese.',
        profileEditSuccess: 'Podaci uspješno sačuvani.',
        date_of_birth: 'Datum rođenja',
        gender: 'Pol',
        genderMale: 'Muško',
        genderFemale: 'Žensko'
    },
    notifications: {
        title: 'Notifikacije',
        openEvent: 'Događaj',
        openReservations: 'Rezervacije',
        new: 'Novo'
    },
    managerReport: {
        startDate: 'Datum od:',
        endDate: 'Datum do:',
        status: 'Status:',
        result: 'Broj rezervacija u odabranom periodu je: '
    },
    reportUser: {
        title: "Prijavi korisnika",
        description: "Razlog prijave",
        reportBtn: "Prijavi",
        userReported: "Korisnik je prijavljen. theHangover tim će provjeriti moguće zloupotrebe i preduzeti korake ka rješavanju problema."
    }
}