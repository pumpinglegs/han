import { createSlice } from '@reduxjs/toolkit';

export const appSlice = createSlice({
    name: 'app',
    initialState: {
        isLoading: true,
        snackbarVisible: false,
        snackbarMessage: '',
        unreadNotifications: 0
    },
    reducers: {
        setIsLoading: (state, action) => {
            state.isLoading = action.payload;
        },
        showSnackbar: (state, action) => {
            state.snackbarVisible = true;
            state.snackbarMessage = action.payload;
        },
        hideSnackbar: (state) => {
            state.snackbarVisible = false;
        },
        setUnreadNotifications: (state, action) => {
            state.unreadNotifications = action.payload;
        }
    }
});

export const { setIsLoading,showSnackbar,hideSnackbar, setUnreadNotifications } = appSlice.actions;

export const getIsLoading = state => state.app.isLoading;

export const getSnackbarVisible = state => state.app.snackbarVisible;
export const getSnackbarMessage = state => state.app.snackbarMessage;

export const getUnreadNotifications = state => state.app.unreadNotifications;


export default appSlice.reducer;