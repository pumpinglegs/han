import React, { useContext, useEffect } from 'react';
import { FlatList, Modal, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { TouchableRipple } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useQueryCache } from 'react-query';
import { useDispatch, useSelector } from 'react-redux';
import { editProfile } from '../api/profile';
import { getUserProfile } from '../api/user';
import { getIsAuthenticated } from '../auth/userSlice';
import { setStorageObjectItem } from '../helpers/asyncStorage';
import { LocalizationContext } from '../helpers/contexts';
import { getCities, getLocationFromLocalStorage } from './cities';
import { getLocationPickerModalVisible, setLocationPickerModalVisible } from './LocationPickerSlice';

const LocationPickerModal = () => {
  const { t } = useContext(LocalizationContext);
  const dispatch = useDispatch();
  const queryCache = useQueryCache();
  const visible = useSelector(getLocationPickerModalVisible);
  const isAuthenticated = useSelector(getIsAuthenticated);
  const cities = getCities(isAuthenticated).data;

  const selectedCity = getLocationFromLocalStorage().data;
  const profile = getUserProfile();

  const hideModal = () => {
    dispatch(setLocationPickerModalVisible(false));
  };

  const listItem = ({ item }) => {
    return (
      <TouchableRipple
        rippleColor="#555"
        style={{ flex: 1 }}
        onPress={() => onCitySelect({ name: item.name, id: item.id })}>
        <View style={styles.listItem}>
          <Text style={{ fontSize: 16 }}>{item.name}</Text>
        </View>
      </TouchableRipple>
    )
  };

  const onCitySelect = async (item) => {
    setStorageObjectItem('SELECTED_CITY', item);
    queryCache.refetchQueries(['getLocationFromLocalStorage']);
    hideModal();
  };

  useEffect(() => {
    if (profile.data && selectedCity && profile.data.city_id != selectedCity.id) {
      editProfile({
        first_name: profile.data.first_name,
        last_name: profile.data.last_name,
        has_viber: profile.data.has_viber,
        city_id: selectedCity.id
      }).then(() => {
        queryCache.refetchQueries(['getUserProfile'])
      });
    }
  }, [profile.data, selectedCity]);

  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={visible}
      statusBarTranslucent={true}
      onDismiss={hideModal}
      onRequestClose={hideModal}
    >
      <View style={styles.container}>
        <View style={styles.modal}>
          <View style={styles.header}>
            <Text style={styles.title}>{t('locationPickerModal.chooseCity')}</Text>
          </View>
          <TouchableOpacity onPress={hideModal} delayPressIn={0} activeOpacity={.6} style={{ position: 'absolute', top: 45, left: 13 }}>
            <Icon name="close" size={30} style={{}} />
          </TouchableOpacity>
          <FlatList
            contentContainerStyle={styles.list}
            data={cities}
            renderItem={listItem}
            keyExtractor={(item) => item.id.toString()}
          />
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  modal: {
    height: '100%',
    width: '100%',
    backgroundColor: '#222',
    paddingVertical: 15,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
    justifyContent: 'center',
    paddingBottom: 10,
    borderBottomWidth: 1,
  },
  title: {
    fontFamily: 'Roboto-Medium',
    fontSize: 22,
  },
  list: {
    marginTop: 15,
  },
  listItem: {
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    borderColor: '#555',
    borderBottomWidth: 1,
  },
});

export default LocationPickerModal;