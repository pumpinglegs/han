import { useQuery } from 'react-query';
import axios from '../axios';
import { getStorageObjectItem } from '../helpers/asyncStorage';

export const getCities = (isAuthenticated: boolean) => {
  return useQuery('getCities', () => {
    return axios.get('/api/location/5').then((response) => response.data);
  },
  {
    enabled: isAuthenticated
  });
};

export const getLocationFromLocalStorage = () => {
  return useQuery('getLocationFromLocalStorage', async () => {
    return await getStorageObjectItem('SELECTED_CITY') || { name: 'Podgorica', id: 1 };
  });
};
