import { createSlice } from '@reduxjs/toolkit';

export const locationPickerModalSlice = createSlice({
    name: 'locationPickerModal',
    initialState: { 
        visible: false
    },
    reducers: {
        setLocationPickerModalVisible: (state, action) => {
            state.visible = action.payload;
        }
    },
});

export const { setLocationPickerModalVisible } = locationPickerModalSlice.actions;

export const getLocationPickerModalVisible = state => state.locationPickerModal.visible;

export default locationPickerModalSlice.reducer;
