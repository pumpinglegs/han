import {
  DrawerContentComponentProps,
  DrawerContentOptions
} from '@react-navigation/drawer';
import { useNavigation, useRoute } from '@react-navigation/native';
import React, { useContext } from 'react';
import { TouchableHighlight, View } from 'react-native';
import { Avatar, Drawer, Text, useTheme } from 'react-native-paper';
import { useQueryCache } from 'react-query';
import { useDispatch, useSelector } from 'react-redux';
import { getUserProfile } from '../api/user';
import { getUnreadNotifications } from '../appSlice';
import { signOut } from '../auth/checkAuth';
import { getIsAuthenticated, getUser } from '../auth/userSlice';
import { getImageUrl } from '../axios';
import { LocalizationContext } from '../helpers/contexts';
import { setLangModalVisible } from '../translation/LanguageModalSlice';

const DrawerContent = (
  props: DrawerContentComponentProps<DrawerContentOptions>,
) => {
  const { navigate } = useNavigation();
  const { t } = useContext(LocalizationContext);
  const dispatch = useDispatch();
  const queryCache = useQueryCache();
  const { colors } = useTheme();
  const route = useRoute();
  
  const unreadCount = useSelector(getUnreadNotifications);

  const profileQuery = getUserProfile();

  const user = profileQuery.isSuccess ? profileQuery.data : null;

  const logout = async () => {
    await signOut();
    queryCache.invalidateQueries();
    navigate('Login');
  }; 

  const isManager = user?.role == 'admin' || user?.role == 'manager';
  const isLoggedIn = useSelector(getIsAuthenticated);

  const isActive = (name: string) => {
    const current = props.state.routes[props.state.index];
    return name == current.name;
  }

  return (
    <>
      <View>
        <Drawer.Section>
          {user && (
            <View style={{ padding: 16 }}>
              <TouchableHighlight onPress={() => navigate('Profile')} style={{ flexDirection: 'row', alignItems: 'center' }}>
                <>
                  { user.image ? (
                    <Avatar.Image
                      source={{ uri: getImageUrl(user.image) }}
                      size={50}
                      style={{ backgroundColor: '#444', marginRight: 15 }}
                    />
                    ) 
                    :
                    <Avatar.Icon icon="account" size={50} style={{backgroundColor: '#444', marginRight: 15}} />
                  }
                  <Text>{user.username}</Text>
                </>
              </TouchableHighlight>
            </View>
          )}
        </Drawer.Section>
        {isManager && (
          <Drawer.Section>
            <Drawer.Item
              icon="shield-key-outline"
              label={t('drawerContent.manager')}
              onPress={() => navigate('Manager', {screen: 'ManagerHome'})}
              active={isActive('Manager')}
            />
          </Drawer.Section>
        )}
        <Drawer.Section style={{ borderBottomWidth: .7, borderBottomColor: '#414141' }}>
          {/* <DrawerItemList {...props} /> */}
          <Drawer.Item
            icon="glass-cocktail"
            label={t('drawerContent.cafes')}
            onPress={() => navigate('Places')}
            active={isActive('Places')}
          />
          <Drawer.Item
            icon="calendar"
            label={t('drawerContent.events')}
            onPress={() => navigate('Events')}
            active={isActive('Events')}
          />
          <View>
            <Drawer.Item 
              icon="bell-outline" 
              label={t('drawerContent.notifications')}
              onPress={() => navigate('Notifications')}
              active={isActive('Notifications')}
              />
            <Text style={{ fontWeight: 'bold', position: 'absolute', right: 16, top: 12, backgroundColor: unreadCount > 0 ? colors.primary : colors.surface, paddingVertical: 3, paddingHorizontal: 6, borderRadius: 8 }}>{unreadCount}</Text>
          </View>
          <Drawer.Item
            icon="calendar-check-outline"
            label={t('drawerContent.myReservations')}
            onPress={() => navigate('MyReservations')}
            active={isActive('MyReservations')}
          />
          <Drawer.Item
            icon="information-outline"
            label={t('drawerContent.contact')}
            onPress={() => navigate('Contact')}
            active={isActive('Contact')}
          />
        </Drawer.Section>
        <Drawer.Section>
          {isLoggedIn &&
            <Drawer.Item icon="earth" label={t('common.language')} onPress={() => dispatch(setLangModalVisible(true))} />
          }
          <Drawer.Item icon="logout" label={t('common.logOut')} onPress={() => logout()} />
        </Drawer.Section>
      </View>
    </>
  );
};

export default DrawerContent;
