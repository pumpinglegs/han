import { DrawerActions, useNavigation } from '@react-navigation/native';
import React, { useContext, useEffect, useState } from 'react';
import { Dimensions, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Appbar, TextInput, Button, ActivityIndicator, TouchableRipple, Checkbox, RadioButton } from 'react-native-paper';
import SimpleAppbar from '../common/SimpleAppbar';
import { LocalizationContext } from '../helpers/contexts';
import { Controller, useForm } from 'react-hook-form';
import { getUserProfile } from '../api/user';
import ImageInput from '../common/ImageInput';
import { getImageUrl } from '../axios';
import { editProfile } from '../api/profile';
import { useDispatch, useSelector } from 'react-redux';
import { showSnackbar } from '../appSlice';
import { useQueryCache } from 'react-query';
import DatePicker from 'react-native-date-picker';
import moment from 'moment';


const ProfileScreen = ({ navigation }) => {
    const { t } = useContext(LocalizationContext);
    const dispatch = useDispatch();
    const [editActive, setEditActive] = useState(false);
    const queryCache = useQueryCache();

    const { control, handleSubmit, errors, formState, reset } = useForm({
        reValidateMode: 'onBlur',
    });

    const { data, status } = getUserProfile();

    const onSubmit = async (d: any) => {
        try {
            d.date_of_birth = moment(d.date_of_birth).format('YYYY-MM-DD');

            const result = await editProfile(d);

            if (result?.error) {
                dispatch(
                    showSnackbar(t('common.connectionError')),
                );
            } else {
                queryCache.refetchQueries();
                dispatch(showSnackbar(t('profile.profileEditSuccess')));
                reset();
                navigation.goBack();
            }
        } catch (e) {
            dispatch(
                showSnackbar(t('common.connectionError')),
            );
        }
    };

    useEffect(() => {
        reset();
    }, [data]);

    useEffect(() => {
        const unsubscribe = navigation.addListener('blur', e => {
            setEditActive(false);
            reset();
        });

        return unsubscribe;
    }, [navigation])

    return (
        <>
            <SimpleAppbar title={t('profile.title')}>
                <Appbar.Action icon="pencil" onPress={() => setEditActive(true)} />
            </SimpleAppbar>
            {status == 'loading' ? (
                <ActivityIndicator />
            ) : status == 'error' ? (
                <Text>{t('common.error')}</Text>
            ) : (
                        <ScrollView>
                            <View style={styles.field}>
                                <Controller
                                    control={control}
                                    name="username"
                                    defaultValue={data.username}
                                    rules={{ required: false, minLength: 3 }}
                                    render={({ onChange, onBlur, value }) => (
                                        <TextInput
                                            label={t('profile.username')}
                                            mode="outlined"
                                            disabled={true}
                                            onBlur={onBlur}
                                            onChangeText={(val) => onChange(val)}
                                            value={value}
                                        />
                                    )}
                                />
                                {errors.username && <Text>{t('common.fieldRequired')}</Text>}
                            </View>
                            <View style={styles.field}>
                                <Controller
                                    control={control}
                                    name="phone"
                                    defaultValue={data.phone}
                                    rules={{ required: true, minLength: 9 }}
                                    render={({ onChange, onBlur, value }) => (
                                        <TextInput
                                            label={t('profile.phone')}
                                            mode="outlined"
                                            disabled={true}
                                            onBlur={onBlur}
                                            onChangeText={(val) => onChange(val)}
                                            value={value}
                                            keyboardType="phone-pad"
                                        />
                                    )}
                                />
                                {errors.phone?.type == 'required' && (
                                    <Text>{t('common.fieldRequired')}</Text>
                                )}
                                {errors.phone?.type == 'minLength' && (
                                    <Text>{t('profile.phoneLengthError')}</Text>
                                )}
                            </View>
                            <View style={styles.field}>
                                <Controller
                                    control={control}
                                    name="has_viber"
                                    defaultValue={data.has_viber}
                                    render={({ onChange, onBlur, value }) => (
                                        <TouchableRipple
                                        onPress={() => {
                                            onChange(!value);
                                        }}>
                                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                            <Checkbox status={value ? 'checked' : 'unchecked'} disabled={!editActive} />
                                            <Text style={{ color: editActive ? '#fff' : '#999' }}>{t('profile.has_viber')}</Text>
                                        </View>
                                        </TouchableRipple>
                                    )}
                                />
                            </View>
                            <View style={styles.field}>
                                <Controller
                                    control={control}
                                    name="first_name"
                                    defaultValue={data.first_name}
                                    rules={{ required: false, minLength: 3 }}
                                    render={({ onChange, onBlur, value }) => (
                                        <TextInput
                                            label={t('profile.name')}
                                            mode="outlined"
                                            disabled={!editActive}
                                            onBlur={onBlur}
                                            onChangeText={(val) => onChange(val)}
                                            value={value}
                                        />
                                    )}
                                />
                                {errors.first_name && <Text>{t('common.fieldRequired')}</Text>}
                                {errors.first_name?.type == 'minLength' && (
                                    <Text>{t('profile.nameLengthError')}</Text>
                                )}
                            </View>
                            <View style={styles.field}>
                                <Controller
                                    control={control}
                                    name="last_name"
                                    defaultValue={data.last_name}
                                    rules={{ required: false, minLength: 3 }}
                                    render={({ onChange, onBlur, value }) => (
                                        <TextInput
                                            label={t('profile.surname')}
                                            mode="outlined"
                                            disabled={!editActive}
                                            onBlur={onBlur}
                                            onChangeText={(val) => onChange(val)}
                                            value={value}
                                        />
                                    )}
                                />
                                {errors.last_name && <Text>{t('common.fieldRequired')}</Text>}
                                {errors.last_name?.type == 'minLength' && (
                                    <Text>{t('profile.surnameLengthError')}</Text>
                                )}
                            </View>
                            <View style={styles.field}>
                                <Controller
                                    control={control}
                                    name="email"
                                    defaultValue={data.email}
                                    rules={{
                                        validate: {
                                            email: validateEmail,
                                        },
                                    }}
                                    render={({ onChange, onBlur, value }) => (
                                        <TextInput
                                            label={t('profile.email')}
                                            mode="outlined"
                                            onBlur={onBlur}
                                            disabled={!editActive}
                                            onChangeText={(val) => onChange(val)}
                                            value={value}
                                        />
                                    )}
                                />
                                {errors.email && <Text>{t('profile.emailError')}</Text>}
                            </View>
                            <View style={styles.field}>
                                <Controller
                                    control={control}
                                    name="profile_image"
                                    defaultValue={{
                                        uri: getImageUrl(data.image),
                                        isDefault: true,
                                        type: '',
                                        name: '',
                                    }}
                                    rules={{ setValueAs: (value) => value }}
                                    render={({ onChange, onBlur, value }) => (
                                        <ImageInput
                                            onBlur={onBlur}
                                            onChange={onChange}
                                            disabled={!editActive}
                                            value={value}
                                            label={t('formAddEvent.chooseImage')}
                                        />
                                    )}
                                />
                            </View>
                            <View style={styles.field}>
                                <Controller
                                    control={control}
                                    name="ins_url"
                                    defaultValue={data.ins_url}
                                    render={({ onChange, onBlur, value }) => (
                                        <TextInput
                                            label={t('profile.ins_url')}
                                            mode="outlined"
                                            disabled={!editActive}
                                            onBlur={onBlur}
                                            onChangeText={(val) => onChange(val)}
                                            value={value}
                                        />
                                    )}
                                />
                            </View>
                            <View style={styles.field}>
                                <Controller
                                    control={control}
                                    name="fb_url"
                                    defaultValue={data.fb_url}
                                    rules={{
                                        validate: {
                                            url: validateUrl,
                                        },
                                    }}
                                    render={({ onChange, onBlur, value }) => (
                                        <TextInput
                                            label={t('profile.fb_url')}
                                            mode="outlined"
                                            disabled={!editActive}
                                            onBlur={onBlur}
                                            onChangeText={(val) => onChange(val)}
                                            value={value}
                                        />
                                    )}
                                />
                            </View>
                            <View style={styles.field}>
                                <Text style={{marginBottom:5}}>{t('profile.date_of_birth')}</Text>
                                <View style={styles.datePickerContainer}>
                                    <Controller
                                    control={control}
                                    name="date_of_birth"
                                    defaultValue={data.date_of_birth ? moment(data.date_of_birth, "YYYY-MM-DD").toDate() : new Date()}
                                    render={({ onChange, onBlur, value }) => !editActive ? (value ? <Text style={{padding:5}}>{moment(value, "YYYY-MM-DD").format('DD.MM.YYYY')}</Text> : <Text>-</Text>) : (
                                        <DatePicker
                                        style={styles.datePicker}
                                        fadeToColor="#191919"
                                        textColor="#fff"
                                        locale="sr-ME"
                                        mode="date"
                                        is24hourSource="locale"
                                        onDateChange={(val) => {
                                            onChange(val);
                                            onBlur();
                                        }}
                                        date={value}
                                        />
                                    )}
                                    />
                                </View>
                            </View>
                            <View style={styles.field}>
                                <Text style={{marginBottom:5}}>{t('profile.gender')}</Text>
                                <Controller
                                    control={control}
                                    name="gender"
                                    defaultValue={data.gender ?? 'male'}
                                    render={({ onChange, onBlur, value }) => !editActive ? (value ? <Text style={styles.txtValue}>{value == 'male' ? t('profile.genderMale') : t('profile.genderFemale')}</Text> : <Text style={styles.txtValue}>{t('profile.genderMale')}</Text>) : (
                                    <RadioButton.Group onValueChange={newValue => {onChange(newValue); onBlur();}} value={value}>
                                        <View>
                                        <RadioButton.Item label={t('profile.genderMale')} value="male" />
                                        </View>
                                        <View>
                                        <RadioButton.Item label={t('profile.genderFemale')} value="female" />
                                        </View>
                                    </RadioButton.Group>
                                    )} 
                                />
                            </View>
                            {editActive &&
                                <View style={styles.field}>
                                    <Button
                                        mode="contained"
                                        onPress={handleSubmit(onSubmit)}
                                        loading={formState.isSubmitting}
                                        disabled={formState.isSubmitting || !formState.isDirty}>
                                        <Text>{formState.isSubmitting ? '' : t('common.save')}</Text>
                                    </Button>
                                </View>
                            }
                        </ScrollView>
                    )}
        </>
    );
};

const validateEmail = (value: any) => {
    return !value || value.match(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/) != null;
};

const validateUrl = (value: any) => {
    const valid =
      !value ||
      value.match(
        /^$|https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/,
      ) != null;
    return valid;
};

const wid = Dimensions.get('window').width;
const styles = StyleSheet.create({
    field: {
        paddingHorizontal: 16,
        paddingVertical: 8,
    },
    datePickerContainer: {
      borderWidth: 1,
      borderColor: '#777',
      borderRadius: 3,
    },
    txtValue: {
        borderWidth: 1,
        borderColor: '#777',
        borderRadius: 3,
        padding: 8
    },
    datePicker: {
      width: wid - 17 * 2,
    },
});

export default ProfileScreen;
