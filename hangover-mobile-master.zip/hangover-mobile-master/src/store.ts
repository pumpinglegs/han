import { configureStore } from '@reduxjs/toolkit';
import appReducer from './appSlice';
import userReducer from './auth/userSlice';
import languageModalReducer from './translation/LanguageModalSlice';
import locationPickerModalReducer from './location-picker/LocationPickerSlice';

export default configureStore({
  devTools: true,
  reducer: {
    app: appReducer,
    user: userReducer,
    languageModal: languageModalReducer,
    locationPickerModal: locationPickerModalReducer,
  }
});
