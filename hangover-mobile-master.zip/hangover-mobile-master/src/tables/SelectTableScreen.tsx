import { useNavigation, useRoute } from '@react-navigation/native';
import React, { useContext, useState } from 'react';
import { Alert, ScrollView, StyleSheet, View } from 'react-native';
import { ImageViewer } from 'react-native-image-zoom-viewer';
import {
  ActivityIndicator,
  Appbar,
  Avatar,
  Button,
  Divider,
  List,
  Modal,
  Paragraph,
  Portal,
  RadioButton,
  Text,
  TextInput,
  Title,
  TouchableRipple,
  useTheme,
} from 'react-native-paper';
import { useMutation, useQueryCache } from 'react-query';
import { useDispatch } from 'react-redux';
import { addMeToWaitlist, isOnWaitlist } from '../api/events';
import {
  createReservation,
  getPlace,
  getPlaceTablesForEvent,
} from '../api/places';
import { getUserProfile } from '../api/user';
import { showSnackbar } from '../appSlice';
import { getImageUrl } from '../axios';
import { LocalizationContext } from '../helpers/contexts';

const SelectTableScreen = () => {
  const { t } = useContext(LocalizationContext);
  const { goBack } = useNavigation();
  const { params } = useRoute();
  const { colors } = useTheme();
  const dispatch = useDispatch();
  const queryCache = useQueryCache();

  const [activeTab, setActiveTab] = useState(0);
  const [selectedTable, setSelectedTable] = useState(null);
  const [selectedPersonNum, setSelectedPersonNum] = useState(2);
  const [customerName, setCustomerName] = useState("");
  const [mutate] = createReservation();

  // TODO: 'Da bi mogli da rezervišete mjesto morate dodati ime i prezime na vaš profil!'

  const user = getUserProfile();
  const isManager = (user.data?.role == 'manager' || user.data?.role == 'admin') && user.data?.places?.[0]?.id == params?.placeId;
  
  const { isLoading, isError, data } = getPlaceTablesForEvent(
    params?.placeId,
    params?.eventId,
  );

  let allTablesReserved = false;
  if (!isLoading && data) {
    allTablesReserved = data?.some(x => x.reservations.length == 0) ? false : true;
  }

  const { data: placeData } = getPlace(params?.placeId);
  const schemaImage = getImageUrl(placeData?.schema_image);

  const { data: waitlistData, refetch: refetchWaitlist } = isOnWaitlist(params?.eventId);
  
  const isOnGlobalWaitlist = waitlistData && waitlistData.some(x => x.table_id === null);
  const waitlistTableIds = waitlistData ? waitlistData.map(x => x.table_id) : [];

  // console.log('WAITLIST DATA:');
  // console.log(waitlistData);

  const selectTable = (item) => {
    console.log(item.reservations);
    setSelectedTable(item);
  };

  const getTabColor = (index: number) => {
    return activeTab == index ? colors.primary : colors.surface;
  };

  const makeReservation = async () => {
    try {
      const result = await mutate({
        table_id: selectedTable?.id,
        event_id: params?.eventId,
        person_num: selectedPersonNum,
        is_manual: isManager,
        customer_name: isManager ? customerName : null
      });
      setSelectedTable(null);

      if (result?.error) {
        let text = result?.error;
        switch (result?.error) {
          case 'user_has_been_approved_for_one_of_events':
            text = t('selectTable.userHasBeenApproved');
            break;
          case 'to_many_reservation_on_this_day':
            text = t('selectTable.tooManyReservations');
            break;
          case 'could_not_create_reservation':
            text = t('selectTable.tooManyTableRes');
            break;
          default:
            break;
        }
        dispatch(showSnackbar(text));
      } else {
        queryCache.invalidateQueries();
        const txt = isManager ? t('selectTable.resSuccessManager') : t('selectTable.resSuccess');
        dispatch(
          showSnackbar(txt),
        );
      }
    } catch (error) {
      setSelectedTable(null);
    }
  };

  const addToWaitlist = async () => {
    try {
      // params?.eventId
      const result = await addMeToWaitlist(params?.eventId, null);
      
      if (result?.error) {
        dispatch(showSnackbar(t('common.tryAgain')));
      } else {
        dispatch(showSnackbar(t('selectTable.addedToWaitlist')));
        refetchWaitlist();
      }
    } catch (error) {
      dispatch(showSnackbar(t('common.tryAgain')));
    }
  };

  const addToTableWaitlist = async () => {
    try {
      console.log("SELECTED TABLE IS");
      console.log(selectedTable);
      const result = await addMeToWaitlist(params?.eventId, selectedTable.id);
      if (result?.error) {
        dispatch(showSnackbar(t('common.tryAgain')));
      } else {
        dispatch(showSnackbar(t('selectTable.addedToWaitlist')));
        refetchWaitlist();
        setSelectedTable(null);
      }
    } catch (error) {
      dispatch(showSnackbar(t('common.tryAgain')));
    }
  };

  const renderItem = (item) => {
    let dotStyle: any = {
      borderRadius: 30,
      width: 8,
      height: 8,
      alignSelf: 'center',
      marginRight: 20,
    };

    if (item.reservations.length == 0) {
      dotStyle = {
        ...dotStyle,
        backgroundColor: '#71ce3e',
      };
    } else {
      dotStyle = {
        ...dotStyle,
        backgroundColor: '#ff4848',
      };
    }

    return (
      <View key={item.id}>
        <List.Item
          title={item.name}
          left={() => <Text style={styles.tableNum}>{item.table_num}</Text>}
          right={() => <View style={dotStyle}></View>}
          onPress={() => selectTable(item)}
          description={waitlistTableIds.length > 0 && waitlistTableIds.includes(item.id) ? t('selectTable.isOnTableWaitlist') : null}
        />
        <Divider />
      </View>
    );
  };

  return (
    <>
      <Appbar>
        <Appbar.BackAction onPress={() => goBack()} />
        <Appbar.Content title={t('selectTable.chooseSpot')} />
      </Appbar>
      {activeTab == 0 ? (
        <>
          { allTablesReserved && (
            <View style={{margin: 16, backgroundColor: '#222', borderRadius: 5, padding: 16, paddingBottom: 8}}>
              <Text>{t('selectTable.waitListDescription')}</Text>
              { !isOnGlobalWaitlist && <View style={{flexDirection: 'row', justifyContent: 'flex-end'}}>
                <Button onPress={() => addToWaitlist()}>{t('selectTable.waitListButton')}</Button>
              </View> }
              { isOnGlobalWaitlist && (
                <View>
                  <Text style={{ fontStyle: 'italic', marginTop: 6, marginBottom: 8 }}>{t('selectTable.addedToWaitlist')}</Text>
                </View>
              ) }
            </View>
          )}
          <ScrollView>{data?.map((item) => renderItem(item))}</ScrollView>
        </>
      ) : (
          <View style={styles.schemaContainer}>
            <ImageViewer
              imageUrls={[{ url: schemaImage }]}
              renderIndicator={() => null}
              loadingRender={() => <ActivityIndicator />}
            />
          </View>
        )}
      <View style={styles.bottomBar}>
        <Button
          mode="contained"
          style={styles.tabBtn}
          contentStyle={styles.tabBtnContent}
          color={getTabColor(0)}
          theme={{ roundness: 0 }}
          onPress={() => setActiveTab(0)}>
          {t('selectTable.spotsList')}
        </Button>
        <Button
          mode="contained"
          color={getTabColor(1)}
          style={styles.tabBtn}
          contentStyle={styles.tabBtnContent}
          theme={{ roundness: 0 }}
          onPress={() => setActiveTab(1)}>
          {t('selectTable.spotsSchema')}
        </Button>
      </View>
      <Portal>
        <Modal
          visible={selectedTable != null}
          dismissable={true}
          contentContainerStyle={styles.modalContent}
          onDismiss={() => setSelectedTable(null)}>
          <Title>{selectedTable?.name}</Title>
          {
            isManager && selectedTable?.reservations.length > 0 && (
              <View style={{flexDirection: 'row', backgroundColor: '#333', marginVertical: 8, paddingRight: 8, borderRadius: 4, paddingVertical: 8, paddingLeft: 2}}>
                <Avatar.Icon icon="alert" color="#ffa805" size={36} style={{backgroundColor: '#333'}} />
                <Paragraph style={{flex: 1, marginLeft: 4}}>{t('selectTable.warningTaken')}<Text style={{fontWeight: 'bold'}}>{selectedTable.reservations[0].is_manual ? selectedTable.reservations[0].customer_name : selectedTable.reservations[0].user.first_name + " " + selectedTable.reservations[0].user.last_name}</Text></Paragraph>
              </View>
            )
          }
          {isManager && (
            <View style={{marginVertical: 10}}>
              <TextInput placeholder={t('selectTable.customerName')} mode="flat" style={{ backgroundColor: "#333" }} onChangeText={(txt) => setCustomerName(txt)} />
            </View>
          )}
          {selectedTable?.reservations.length > 0 ? (
            <>
              <Text>{t('selectTable.tableIsNotAvailable')}</Text>
              <Button style={{marginTop:10}} onPress={addToTableWaitlist}>{t('selectTable.waitListButton')}</Button>
            </>
          ) : (
            <>
            <Text>{t('selectTable.numOfPeople')}:</Text>
            <View style={styles.personsList}>
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <TouchableRipple
                  key={i}
                  onPress={() => setSelectedPersonNum(i)}
                  style={styles.personsListItemWrapper}>
                  <View
                    style={[
                      styles.personsListItem,
                      selectedPersonNum == i
                        ? styles.personsListItemSelected
                        : {},
                    ]}>
                    <Text>{i.toString()}</Text>
                  </View>
                </TouchableRipple>
              ))}
            </View>
            <Button
              mode="contained"
              style={{ marginTop: 10 }}
              onPress={() => makeReservation()}>
              {t('selectTable.reserve')}
            </Button>
            </>
          )}
        </Modal>
      </Portal>
    </>
  );
};

const styles = StyleSheet.create({
  tableNum: {
    backgroundColor: '#03a9f4',
    borderRadius: 20,
    width: 24,
    height: 24,
    textAlign: 'center',
    textAlignVertical: 'center',
    alignSelf: 'center',
    marginLeft: 10,
  },
  schemaContainer: {
    flex: 1,
  },
  bottomBar: {
    flexDirection: 'row',
  },
  tabBtn: {
    width: '50%',
    elevation: 0,
  },
  tabBtnContent: {
    height: 55,
  },
  modalContent: {
    width: 300,
    alignSelf: 'center',
    backgroundColor: '#444',
    padding: 18,
    elevation: 10,
  },
  personsList: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  personsListItemWrapper: {
    width: '30%',
    marginBottom: 10,
  },
  personsListItem: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#333',
    paddingVertical: 10,
    justifyContent: 'center',
  },
  personsListItemSelected: {
    backgroundColor: '#03a9f4',
  },
});

export default SelectTableScreen;
