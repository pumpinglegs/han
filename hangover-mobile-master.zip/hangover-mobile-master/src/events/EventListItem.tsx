import {useNavigation} from '@react-navigation/native';
import React from 'react';
import {Image, StyleSheet, View} from 'react-native';
import {Text, TouchableRipple} from 'react-native-paper';
import EventAvailability from './EventAvailability';
import {getImageUrl} from '../axios';
import moment from 'moment';

const EventListItem = ({item, onPress}) => {
  // const navigation = useNavigation();
  // const openEvent = (id: number) => {
  //   navigation.navigate('EventDetails', {id});
  // };
  //const date = moment(item.event_date, "YYYY-MM-DD").format('DD.MM.YYYY');
  return (
    <TouchableRipple
      rippleColor="#555"
      style={{flex: 1}}
      onPress={() => onPress(item.id)}>
      <View style={styles.listItem}>
        <Image
          source={{uri: getImageUrl(item.image)}}
          style={styles.listItemImg}
        />
        <View>
          <Text style={styles.listItemName}>{item.name}</Text>
          <Text style={{marginBottom: 4}}>{item.place?.name}</Text>
          <EventAvailability status={item.status} />
        </View>
      </View>
    </TouchableRipple>
  );
};

const styles = StyleSheet.create({
  listItem: {
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    borderColor: '#444',
    borderBottomWidth: 1,
  },
  listItemName: {
    marginTop: 0,
    fontSize: 16,
    fontWeight: 'bold',
  },
  listItemImg: {
    width: 80,
    height: 80,
    resizeMode: 'cover',
    borderColor: '#444',
    borderWidth: 1,
    marginRight: 16,
  },
});

export default EventListItem;
