import React, { useContext } from 'react';
import {View} from 'react-native';
import {Text} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { LocalizationContext } from '../helpers/contexts';

const EventAvailability = ({status}: {status: string}) => {
  const { t } = useContext(LocalizationContext);
  
  let color = '#999';
  if (status == 'active') {
    color = '#0ec911';
  }
  return (
    <View style={{flexDirection: 'row', alignItems: 'center'}}>
      <Icon name="circle" size={8} style={{marginRight: 5}} color={color} />
      <Text style={{color}}>{t('eventAvailability.entriesAvailable')}</Text>
    </View>
  );
};

export default EventAvailability;
