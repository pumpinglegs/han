import { DrawerActions, useNavigation } from '@react-navigation/native';
import moment from 'moment';
import React, { useContext, useState } from 'react';
import { FlatList, SectionList, StyleSheet, View } from 'react-native';
import {
  ActivityIndicator,
  Appbar,
  Text
} from 'react-native-paper';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useDispatch } from 'react-redux';
import { getAllEvents } from '../api/events';
import { LocalizationContext } from '../helpers/contexts';
import { getLocationFromLocalStorage } from '../location-picker/cities';
import { setLocationPickerModalVisible } from '../location-picker/LocationPickerSlice';
import EventListItem from './EventListItem';

var groupByArray = (xs, key) => { return xs.reduce(function (rv, x) { let v = key instanceof Function ? key(x) : x[key]; let el = rv.find((r) => r && r.key === v); if (el) { el.data.push(x); } else { rv.push({ key: v, data: [x] }); } return rv; }, []); } 

const EventsScreen = () => {
  const insets = useSafeAreaInsets();

  const dispatch = useDispatch();
  const { t } = useContext(LocalizationContext);
  const navigation = useNavigation();
  const openDrawer = () => {
    navigation.dispatch(DrawerActions.openDrawer());
  };
  const selectedCity = getLocationFromLocalStorage().data;

  const [isRefreshing, setIsRefreshing] = useState(false);

  const {
    status,
    data,
    isFetching,
    isFetchingMore,
    fetchMore,
    canFetchMore,
    refetch,
  } = getAllEvents(selectedCity);

  const refresh = async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  };

  const resolvedData: any[] = [];

  data?.forEach((list) => resolvedData.push(...list));

  const groupedData = groupByArray(resolvedData, (item) => {
    return item.priority + "_" + item.event_date;
  });

  const openEvent = (id) => {
    navigation.navigate('EventDetails', {id});
  };

  const renderItem = ({item, index}) => {
    return <EventListItem item={item} onPress={(id) => openEvent(id)} />;
  };

  const AppBarLocationSelect = () => {
    return (
      <>
        <Text>{selectedCity?.name}</Text>
        <Icon name="map-marker" size={20} style={{marginLeft: 5}} />
      </>
    )
  };

  const onCitySelect = () => {
    dispatch(setLocationPickerModalVisible(true));
  };

  return (
    <View>
      <Appbar>
        <Appbar.Action icon="menu" onPress={() => openDrawer()} />
        <Appbar.Content title={<AppBarLocationSelect />} style={{ alignItems: 'center' }} onPress={onCitySelect} />
        <View style={{width: 32}}></View>
      </Appbar>
      <View>
        {status == 'loading' ? (
          <ActivityIndicator />
        ) : status == 'error' ? (
          <Text>{t('common.unexpectedError')}</Text>
        ) : (
          <SectionList
            refreshing={isRefreshing}
            onRefresh={refresh}
            contentContainerStyle={{paddingBottom: insets.bottom}}
            sections={groupedData}
            keyExtractor={(item, index) => item + index}
            renderItem={renderItem}
            renderSectionHeader={({ section: { key } }) => {
              const dateStr = key?.split('_')[1];
              const date = moment(dateStr, "YYYY-MM-DD").format('DD.MM.YYYY');
              return (
                <Text style={styles.header}>{date}</Text>
              )
            }}
          />
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {},
  header: {
    textAlign: 'center',
    fontWeight: 'bold',
    color: '#bbb',
    paddingVertical: 8,
    backgroundColor: '#222',
    borderBottomColor: '#444',
    borderBottomWidth: 1
  }
});

export default EventsScreen;
