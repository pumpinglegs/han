import { useNavigation, useRoute } from '@react-navigation/native';
import React, { useContext, useState } from 'react';
import { Dimensions, Image, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import {
  ActivityIndicator,
  Appbar,
  Button,
  Paragraph,
  Text,
  useTheme,
} from 'react-native-paper';
import { getEvent } from '../api/events';
import { getImageUrl } from '../axios';
import { LocalizationContext } from '../helpers/contexts';
import EventAvailability from './EventAvailability';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { ImageViewer } from 'react-native-image-zoom-viewer';

const EventDetailsScreen = () => {
  const { t } = useContext(LocalizationContext);

  const { params } = useRoute();
  const { goBack, navigate } = useNavigation();
  const { colors } = useTheme();
  const id = params?.id;

  const [showImage, setShowImage] = useState(false);

  const { isLoading, isError, data, error } = getEvent(id);
  const place = data?.place;

  const openReservations = () => {
    navigate('SelectTable', { eventId: id, placeId: data?.place_id });
  };
  
  const renderContent = () => {
    return (
      <>
        { showImage ? (
          <View style={{flex:1}}>
            <ImageViewer
              imageUrls={[{ url: getImageUrl(data?.image) }]}
              renderIndicator={() => null}
              loadingRender={() => <ActivityIndicator />}
            />
          </View>
        )
        :
        (
          <>
            <ScrollView style={styles.container}>
              <TouchableOpacity onPress={() => {
                setShowImage(true);
              }}>
                <Image
                  source={{ uri: getImageUrl(data?.image) }}
                  style={styles.image}
                />
              </TouchableOpacity>
              <View style={styles.details}>
                <Text style={styles.date}>{data?.event_date}</Text>
                <EventAvailability status={data?.status} />
                <Paragraph style={styles.paragraph}>{data?.short_desc}</Paragraph>
                <TouchableOpacity
                  onPress={() => navigate('PlaceDetails', { id: place.id })}
                  delayPressIn={0}
                  activeOpacity={.6}
                  style={{ flexDirection: 'row', alignItems: 'center' }}
                >
                  <Text style={{ fontSize: 17, marginTop: 15, color: colors.primary }}>{place.name}</Text>
                  <Icon name="information-outline" color={colors.primary} size={20} style={{ marginLeft: 5, marginTop: 7 }} />
                </TouchableOpacity>
              </View>
            </ScrollView>
            <Button
              mode="contained"
              style={styles.btn}
              theme={{ roundness: 0 }}
              contentStyle={styles.btnContent}
              onPress={() => openReservations()}>
              {t('eventDetails.reservations')}
            </Button>
          </>
        )
        }
      </>
    );
  };

  return (
    <>
      <Appbar>
        <Appbar.BackAction onPress={() => goBack()} />
        <Appbar.Content title={data?.name} />
        { showImage && <Appbar.Action icon="close" onPress={() => setShowImage(false)} /> }
      </Appbar>

      {isLoading ? (
        <ActivityIndicator />
      ) : isError ? (
        <View>{t('common.error')}</View>
      ) : (
            renderContent()
          )}
    </>
  );
};

const styles = StyleSheet.create({
  image: {
    marginTop: 16,
    width: Dimensions.get('window').width-32,
    height: Dimensions.get('window').height * .35,
    resizeMode: 'contain'
  },
  container: {
    paddingVertical: 0,
    paddingHorizontal: 16
  },
  date: {
    marginTop: 24,
  },
  paragraph: {
    marginTop: 24,
  },
  details: {
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  btn: {},
  btnContent: {
    height: 48,
  },
});

export default EventDetailsScreen;
