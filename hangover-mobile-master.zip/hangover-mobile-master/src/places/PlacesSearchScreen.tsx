import { DrawerActions, useNavigation } from '@react-navigation/native';
import React, { useContext, useEffect, useState } from 'react';
import { FlatList, Image, StyleSheet, View, TextInput } from 'react-native';
import {
  ActivityIndicator,
  Appbar,
  Searchbar,
  Text,
  TouchableRipple
} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useDispatch } from 'react-redux';
import { getAllPlaces } from '../api/places';
import { getImageUrl } from '../axios';
import { LocalizationContext } from '../helpers/contexts';
import { getLocationFromLocalStorage } from '../location-picker/cities';
import { setLocationPickerModalVisible } from '../location-picker/LocationPickerSlice';

const PlacesSearchScreen = () => {
  const { t } = useContext(LocalizationContext);
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const selectedCity = getLocationFromLocalStorage().data;

  const [query, setQuery] = useState('');
  
  const debouncedSearchTerm = useDebounce(query, 500);

  const openDrawer = () => {
    navigation.dispatch(DrawerActions.openDrawer());
  };

  const openPlace = (id) => {
    navigation.navigate('PlaceDetails', { id });
  };

  const [isRefreshing, setIsRefreshing] = useState(false);
  
  const {
    status,
    data,
    isFetching,
    isFetchingMore,
    fetchMore,
    canFetchMore,
    refetch,
  } = getAllPlaces(selectedCity, debouncedSearchTerm);

  const refresh = async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  };

  const resolvedData: any[] = [];

  data?.forEach((list) => resolvedData.push(...list));

  const renderItem = ({ item, index }) => {
    let itemStyle = styles.listItem;

    if (index == 0 || index % 2 == 0) {
      itemStyle = { ...styles.listItem, ...styles.listItemOdd };
    }

    return (
      <TouchableRipple
        rippleColor="#555"
        style={itemStyle}
        onPress={() => openPlace(item.id)}>
        <View style={{ alignItems: 'center' }}>
          <Image
            source={{ uri: getImageUrl(item.logo) }}
            style={styles.listItemImg}
          />
          <Text style={styles.listItemName}>{item.name}</Text>
        </View>
      </TouchableRipple>
    );
  };

  const AppBarLocationSelect = () => {
    return (
      <>
        <Text>{selectedCity?.name}</Text>
        <Icon name="map-marker" size={20} style={{marginLeft: 5}} />
      </>
    )
  };

  const onCitySelect = () => {
    dispatch(setLocationPickerModalVisible(true));
  };

  return (
    <View>
      <Appbar>
        <Appbar.BackAction onPress={() => navigation.goBack()} />
        <TextInput 
          autoFocus={true}
          multiline={false}
          style={{ flex: 1, color: '#fff', fontSize: 18 }}
          placeholderTextColor="#fff"
          onChangeText={(val) => {
            setQuery(val);
          }} 
          placeholder={t('common.searchPlaceholder')} />
      </Appbar>
      <View>
        {status == 'loading' ? (
          <ActivityIndicator />
        ) : status == 'error' ? (
          <Text>{t('common.unexpectedError')}</Text>
        ) : (
              <FlatList
                contentContainerStyle={styles.container}
                refreshing={isRefreshing}
                onRefresh={refresh}
                numColumns={2}
                data={resolvedData}
                renderItem={renderItem}
                keyExtractor={(item) => item.id}
                onEndReached={() => fetchMore()}
                //ListFooterComponent={listFooter()}
                //ListHeaderComponent={listHeader()}
                ItemSeparatorComponent={() => <View style={{ height: 16 }}></View>}
              />
            )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {},
  listItem: {
    width: '50%',
    justifyContent: 'center',
    alignContent: 'center',
    alignItems: 'center',
    paddingVertical: 30,
    paddingHorizontal: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#444',
  },
  listItemOdd: {
    borderRightWidth: 1,
    borderRightColor: '#444',
  },
  listItemName: {
    marginTop: 10,
  },
  listItemImg: {
    width: 100,
    height: 100,
    resizeMode: 'contain',
  },
});

function useDebounce(value, delay) {
  // State and setters for debounced value
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(
    () => {
      // Update debounced value after delay
      const handler = setTimeout(() => {
        setDebouncedValue(value);
      }, delay);

      // Cancel the timeout if value changes (also on delay change or unmount)
      // This is how we prevent debounced value from updating if value is changed ...
      // .. within the delay period. Timeout gets cleared and restarted.
      return () => {
        clearTimeout(handler);
      };
    },
    [value, delay] // Only re-call effect if value or delay changes
  );

  return debouncedValue;
}

export default PlacesSearchScreen;
