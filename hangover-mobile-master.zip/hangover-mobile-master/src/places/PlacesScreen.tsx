import { DrawerActions, useNavigation } from '@react-navigation/native';
import React, { useContext, useState } from 'react';
import { FlatList, Image, StyleSheet, View } from 'react-native';
import {
  ActivityIndicator,
  Appbar,
  Text,
  TouchableRipple
} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useDispatch } from 'react-redux';
import { getAllPlaces } from '../api/places';
import { getImageUrl } from '../axios';
import { LocalizationContext } from '../helpers/contexts';
import { getLocationFromLocalStorage } from '../location-picker/cities';
import { setLocationPickerModalVisible } from '../location-picker/LocationPickerSlice';

const PlacesScreen = () => {
  const { t } = useContext(LocalizationContext);
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const selectedCity = getLocationFromLocalStorage().data;

  const openDrawer = () => {
    navigation.dispatch(DrawerActions.openDrawer());
  };

  const openPlace = (id) => {
    navigation.navigate('PlaceDetails', { id });
  };

  const [isRefreshing, setIsRefreshing] = useState(false);
  
  const {
    status,
    data,
    isFetching,
    isFetchingMore,
    fetchMore,
    canFetchMore,
    refetch,
  } = getAllPlaces(selectedCity);

  const refresh = async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  };

  const resolvedData: any[] = [];

  data?.forEach((list) => resolvedData.push(...list));

  const renderItem = ({ item, index }) => {
    let itemStyle = styles.listItem;

    if (index == 0 || index % 2 == 0) {
      itemStyle = { ...styles.listItem, ...styles.listItemOdd };
    }

    return (
      <TouchableRipple
        rippleColor="#555"
        style={itemStyle}
        onPress={() => openPlace(item.id)}>
        <View style={{ alignItems: 'center' }}>
          <Image
            source={{ uri: getImageUrl(item.logo) }}
            style={styles.listItemImg}
          />
          <Text style={styles.listItemName}>{item.name}</Text>
        </View>
      </TouchableRipple>
    );
  };

  const AppBarLocationSelect = () => {
    return (
      <>
        <Text>{selectedCity?.name}</Text>
        <Icon name="map-marker" size={20} style={{marginLeft: 5}} />
      </>
    )
  };

  const onCitySelect = () => {
    dispatch(setLocationPickerModalVisible(true));
  };

  return (
    <View>
      <Appbar>
        <Appbar.Action icon="menu" onPress={() => openDrawer()} />
        <Appbar.Content title={<AppBarLocationSelect />} style={{ alignItems: 'center' }} onPress={onCitySelect} />
        <Appbar.Action icon="magnify" onPress={() => {
          navigation.navigate('PlacesSearch');
        }} />
      </Appbar>
      <View>
        {status == 'loading' ? (
          <ActivityIndicator />
        ) : status == 'error' ? (
          <Text>{t('common.unexpectedError')}</Text>
        ) : (
              <FlatList
                contentContainerStyle={styles.container}
                refreshing={isRefreshing}
                onRefresh={refresh}
                numColumns={2}
                data={resolvedData}
                renderItem={renderItem}
                keyExtractor={(item) => item.id}
                onEndReached={() => fetchMore()}
                //ListFooterComponent={listFooter()}
                //ListHeaderComponent={listHeader()}
              />
            )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
  },
  listItem: {
    width: '50%',
    justifyContent: 'center',
    alignContent: 'center',
    alignItems: 'center',
    paddingVertical: 30,
    paddingHorizontal: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#444',
  },
  listItemOdd: {
    borderRightWidth: 1,
    borderRightColor: '#444',
  },
  listItemName: {
    marginTop: 10,
  },
  listItemImg: {
    width: 100,
    height: 100,
    resizeMode: 'contain',
  },
});

export default PlacesScreen;
