import { useNavigation, useRoute } from '@react-navigation/native';
import React, { useContext } from 'react';
import { Dimensions, Linking, Platform, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import { SliderBox } from 'react-native-image-slider-box';
import {
  ActivityIndicator,
  Appbar,
  IconButton,
  Text,
  TouchableRipple,
  useTheme
} from 'react-native-paper';
import { TabBar, TabView } from 'react-native-tab-view';
import { useSelector } from 'react-redux';
import { getPlace } from '../api/places';
import { getUser } from '../auth/userSlice';
import { getImageUrl } from '../axios';
import EventListItem from '../events/EventListItem';
import { LocalizationContext } from '../helpers/contexts';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';


const EventsTab = ({ item }) => {
  const navigation = useNavigation();
  const openEvent = (id) => {
    navigation.navigate('EventDetails', { id });
  };

  return (
    <ScrollView>
      {item.events?.map((event) => (
        <EventListItem
          item={event}
          key={event.id}
          onPress={(id) => openEvent(id)}
        />
      ))}
    </ScrollView>
  );
};

const InformationTab = ({ item }) => {
  const { t } = useContext(LocalizationContext);
  const { colors } = useTheme();
  const socialNetworks = [];

  if (item.fb_url) {
    socialNetworks.push({ icon: 'facebook', link: item.fb_url });
  }
  if (item.ins_url) {
    socialNetworks.push({ icon: 'instagram', link: item.ins_url });
  }

  const openUrl = async (url) => {
    const supported = await Linking.canOpenURL(url);
    if (supported) {
      await Linking.openURL(url);
    }
  };

  return (
    <ScrollView style={styles.tab}>
      <Text style={styles.infoSubtitle}>{t('placeDetails.shortDesc')}</Text>
      <Text>{item?.description}</Text>

      {item.site_url && (
        <>
          <Text style={[styles.infoSubtitle, { marginTop: 16 }]}>Web sajt</Text>
          <TouchableRipple onPress={() => openUrl(item.site_url)}>
            <View style={styles.website}>
              <IconButton color={colors.primary} icon="web" />
              <Text>{item.site_url}</Text>
            </View>
          </TouchableRipple>
        </>
      )}

      {socialNetworks.length > 0 && (
        <>
          <Text style={[styles.infoSubtitle, { marginTop: 16 }]}>
            {t('placeDetails.socialNetworks')}
          </Text>
          <View style={styles.socialNetworks}>
            {socialNetworks.map((sn) => (
              <IconButton
                color={colors.primary}
                key={sn.icon}
                icon={sn.icon}
                onPress={() => openUrl(sn.link)}
              />
            ))}
          </View>
        </>
      )}
    </ScrollView>
  );
};

const LocationTab = ({ item }) => {
  const { t } = useContext(LocalizationContext);
  const { colors } = useTheme();
  const latLong = item.location.split(',');
  const lat = latLong[0];
  const lng = latLong[1];

  const openMap = () => {
    var scheme = Platform.OS === 'ios' ? 'maps:' : 'geo:';
    var url = scheme + `${lat},${lng}`;
    Linking.openURL(url);
  }

  return <View>
    <View style={{ padding: 16 }}>
      <View>
        <Text style={{ fontWeight: 'bold', fontSize: 16 }}>{t('placeDetails.address')}:</Text>
        <Text style={{}}>{item.address}</Text>
      </View>
    </View>
    <TouchableOpacity onPress={openMap} delayPressIn={0} activeOpacity={.6} style={{ padding: 16 }}>
      <Icon name="map-search-outline" size={50} color={colors.primary} />
      <Text>{t('placeDetails.openMap')}</Text>
    </TouchableOpacity>
  </View>;
};

const initialLayout = { width: Dimensions.get('window').width };

const PlaceDetailsScreen = () => {
  const { t } = useContext(LocalizationContext);
  const { params } = useRoute();
  const navigation = useNavigation();
  const { colors } = useTheme();
  const id = params?.id;
  const user = useSelector(getUser);
  const isManager = user?.role === 'admin' || user?.role === 'manager';
  const { isLoading, isError, data, error } = getPlace(id);

  const [index, setIndex] = React.useState(0);
  const [routes] = React.useState([
    { key: 'events', title: 'placeDetails.events' },
    { key: 'info', title: 'placeDetails.info' },
    { key: 'location', title: 'placeDetails.location' },
  ]);

  const renderScene = ({ route }) => {
    switch (route.key) {
      case 'events':
        return <EventsTab item={data} />;
      case 'info':
        return <InformationTab item={data} />;
      case 'location':
        return <LocationTab item={data} />;
      default:
        return null;
    }
  };

  const renderTabBar = (props) => (
    <TabBar
      {...props}
      indicatorStyle={{ backgroundColor: colors.primary }}
      activeColor={colors.primary}
      inactiveColor={colors.text}
      style={{ backgroundColor: '#222', elevation: 0 }}
      renderLabel={({ route, focused, color }) => (
        <Text style={{ color }}>{t(route.title)}</Text>
      )}
    />
  );

  const content = () => {
    if (isLoading) {
      return (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator />
        </View>
      );
    }
    if (isError) {
      return (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <Text>{t('common.unexpectedError')}</Text>
        </View>
      );
    }

    const images = data?.sliders?.map((item) => getImageUrl(item.image));

    return (
      <View style={{ flex: 1 }}>
        <SliderBox
          images={images}
          sliderBoxHeight={250}
          imageLoadingColor="#fff"
        />
        <TabView
          navigationState={{ index, routes }}
          renderScene={renderScene}
          onIndexChange={setIndex}
          initialLayout={initialLayout}
          renderTabBar={renderTabBar}
        />
      </View>
    );
  };

  return (
    <View style={{ flex: 1 }}>
      <Appbar>
        <Appbar.BackAction onPress={() => navigation.goBack()} />
        <Appbar.Content title={data?.name} />
        {isManager && id === data?.user_id &&
          <Appbar.Action icon="pencil" onPress={() => {
            navigation.navigate('ManagePlace', { id } )
          }} />
        }
      </Appbar>

      {content()}
    </View>
  );
};

const styles = StyleSheet.create({
  tab: {
    padding: 16,
  },
  infoSubtitle: {
    textTransform: 'uppercase',
    color: '#aaa',
    fontWeight: 'bold',
    marginBottom: 5,
  },
  socialNetworks: {
    flexDirection: 'row',
  },
  website: {
    flexDirection: 'row',
    alignItems: 'center',
  },
});

export default PlaceDetailsScreen;
