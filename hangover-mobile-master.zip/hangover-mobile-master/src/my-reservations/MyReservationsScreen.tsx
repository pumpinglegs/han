import {DrawerActions, useNavigation} from '@react-navigation/native';
import React, {useContext, useState} from 'react';
import {FlatList, Image, StyleSheet, View} from 'react-native';
import {
  ActivityIndicator,
  Appbar,
  Button,
  Card,
  IconButton,
  Paragraph,
  Text,
  Title,
} from 'react-native-paper';
import {getAllReservations} from '../api/reservation';
import {getImageUrl} from '../axios';
import { LocalizationContext } from '../helpers/contexts';
import ReservationListItem from './ReservationListItem';

const MyReservationsScreen = () => {
  const { t } = useContext(LocalizationContext);
  const navigation = useNavigation();
  const openDrawer = () => {
    navigation.dispatch(DrawerActions.openDrawer());
  };

  const [isRefreshing, setIsRefreshing] = useState(false);

  const {
    status,
    data,
    isFetching,
    isFetchingMore,
    fetchMore,
    canFetchMore,
    refetch,
  } = getAllReservations();

  const refresh = async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  };

  const resolvedData: any[] = [];

  data?.forEach((list) => resolvedData.push(...list));

  const renderItem = ({item}) => {
    return <ReservationListItem item={item} />;
  };

  return (
    <>
      <Appbar>
        <Appbar.Action icon="menu" onPress={() => openDrawer()} />
        <Appbar.Content title={t('myReservations.title')} />
      </Appbar>
      <View>
        {status == 'loading' ? (
          <ActivityIndicator />
        ) : status == 'error' ? (
          <Text>{t('common.unexpectedError')}</Text>
        ) : (
          <FlatList
            contentContainerStyle={styles.container}
            refreshing={isRefreshing}
            onRefresh={refresh}
            data={resolvedData}
            renderItem={renderItem}
            keyExtractor={(item) => item.id.toString()}
            onEndReached={() => fetchMore()}
            //ListFooterComponent={listFooter()}
            //ListHeaderComponent={listHeader()}
            ItemSeparatorComponent={() => <View style={{height: 16}}></View>}
          />
        )}
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingTop: 16,
  },
});

export default MyReservationsScreen;
