import {useNavigation} from '@react-navigation/native';
import React, {useContext, useState} from 'react';
import {Image, StyleSheet, View} from 'react-native';
import {Chip, Dialog, IconButton, Menu, Paragraph, Text, Title, Button, useTheme, Colors, Portal} from 'react-native-paper';
import { useQueryCache } from 'react-query';
import { useDispatch } from 'react-redux';
import { cancelReservation } from '../api/reservation';
import { showSnackbar } from '../appSlice';
import {getImageUrl} from '../axios';
import { LocalizationContext } from '../helpers/contexts';

const getStatusText = (status) => {
  const { t } = useContext(LocalizationContext);
  if (status === 'approved') {
    return t('manageReservationsEvent.approved');
  } else if (status === 'pending') {
    return t('manageReservationsEvent.pending');
  } else if (status === 'user-canceled') {
    return t('manageReservationsEvent.userCanceled');
  } else {
    return t('manageReservationsEvent.canceled');
  }
};

const ReservationListItem = ({item}) => {
  const { t } = useContext(LocalizationContext);
  const {navigate} = useNavigation();
  const [menuVisible, setMenuVisible] = useState(false);
  const [cancelDialogVisible, setCancelDialogVisible] = useState(false);
  const {colors} = useTheme();
  const dispatch = useDispatch();
  const queryCache = useQueryCache();

  const openMenu = () => setMenuVisible(true);

  const closeMenu = () => setMenuVisible(false);

  const getBgColorStatus = (status) => {
    switch (status) {
        case 'approved':
          return '#28a745';
        case 'canceled': 
          return '#dc3545';
        case 'user-canceled':
          return '#777777';
        default: 
          return colors.primary;
    }
  }

  const getChipIcon = (status) =>{
    switch (status) {
      case 'approved':
        return 'check';
      case 'canceled': 
      case 'user-canceled':
        return 'close';
      default: 
        return 'timer-sand';
    }
  };

  const onCancelConfirm = async () => {
    try {
      const result = await cancelReservation(item.id);
      if (result?.error) {
        dispatch(showSnackbar(t(result.error)));
      } else {
        dispatch(showSnackbar(t('reservationListItem.cancelSuccess')));
        setCancelDialogVisible(false);
        queryCache.invalidateQueries();
      }
    } catch (e) {
      dispatch(showSnackbar(t('common.tryAgain')));
    }
  }

  return (
    <View style={styles.cardView}>
      <Image
        source={{uri: getImageUrl(item.event.image)}}
        style={styles.listItemImg}
      />
      <View style={styles.cardText}>
        <View style={styles.statusWrapper}>
          <Chip icon={getChipIcon(item.status)} style={{backgroundColor: getBgColorStatus(item.status)}} textStyle={{fontWeight: 'bold'}}>{getStatusText(item.status)}</Chip>
          <Menu
            visible={menuVisible}
            onDismiss={closeMenu}
            anchor={
              <IconButton
                icon="dots-vertical"
                style={styles.moreButton}
                onPress={openMenu}
              />
            }>
            <Menu.Item
              onPress={() => {
                closeMenu();
                navigate('EventDetails', {id: item.event.id});
              }}
              title={t('reservationListItem.eventDetails')}
            />
            <Menu.Item onPress={() => {
              closeMenu();
              navigate('TableSchema', {place_id: item.event.place_id})
            }} title={t('reservationListItem.spotsSchema')} />
            { (item.status == 'pending' || item.status == 'approved') && (
              <Menu.Item onPress={() => {
                closeMenu();
                setCancelDialogVisible(true);
              }} title={t('reservationListItem.cancelReservation')} />
            ) }
          </Menu>
        </View>
        <Text style={styles.title}>{item.event.name}</Text>
        <Text>{item.event.event_date}</Text>
        <Paragraph lineBreakMode="head">
          {t('reservationListItem.paragraphOne')} {item.table.table_num} {t('common.for')} {item.person_num}{' '}
          {t('reservationListItem.persons')}.
        </Paragraph>
      </View>
      <Portal>
        <Dialog visible={cancelDialogVisible} onDismiss={() => { setCancelDialogVisible(false) }}>
          <Dialog.Title>{t('reservationListItem.cancelDialogTitle')}</Dialog.Title>
          <Dialog.Content>
            <Text>
              {t('reservationListItem.cancelDialogText')}
            </Text>
          </Dialog.Content>
          <Dialog.Actions>
            <Button
              color="rgba(255,255,255,0.7)"
              onPress={() => {
                setCancelDialogVisible(false);
              }}>
              {t('reservationListItem.cancelDialogNo')}
            </Button>
            <Button color={Colors.deepOrange400} onPress={onCancelConfirm}>
              {t('reservationListItem.cancelDialogYes')}
            </Button>
          </Dialog.Actions>
        </Dialog>  
      </Portal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {},
  listItemImg: {
    width: 100,
    height: 150,
    resizeMode: 'cover',
    borderTopLeftRadius: 20,
    borderBottomLeftRadius: 20,
  },
  cardView: {
    flexDirection: 'row',
    marginHorizontal: 10,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  cardText: {
    paddingHorizontal: 16,
    paddingBottom: 16,
    flex: 1,
  },
  moreButton: {
    marginRight: 0,
    position: 'relative',
    left: 10,
  },
  statusWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ReservationListItem;
