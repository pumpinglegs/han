import { useNavigation, useRoute } from '@react-navigation/native';
import React, { useContext } from 'react';
import { StyleSheet, View } from 'react-native';
import { ImageViewer } from 'react-native-image-zoom-viewer';
import { ActivityIndicator, Appbar } from 'react-native-paper';
import { getPlace } from '../api/places';
import { getImageUrl } from '../axios';
import { LocalizationContext } from '../helpers/contexts';

const TableSchemaScreen = () => {
  const { t } = useContext(LocalizationContext);
  const { goBack } = useNavigation();
  const { params } = useRoute();
  const { data } = getPlace(params?.place_id);
  const schemaImage = getImageUrl(data?.schema_image);
  
  return (
    <>
      <Appbar>
        <Appbar.BackAction onPress={() => goBack()} />
        <Appbar.Content title={t('manageSchema.schema')} />
      </Appbar>
      <View style={styles.schemaContainer}>
        <ImageViewer
          imageUrls={[{ url: schemaImage }]}
          renderIndicator={() => <View></View>}
          loadingRender={() => <ActivityIndicator />}
        />
      </View>
    </>
  )
};

const styles = StyleSheet.create({
  schemaContainer: {
    flex: 1,
  },
});

export default TableSchemaScreen;