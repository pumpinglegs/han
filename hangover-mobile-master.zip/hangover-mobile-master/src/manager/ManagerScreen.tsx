import {DrawerActions, useNavigation} from '@react-navigation/native';
import React, { useContext } from 'react';
import {ScrollView, StyleSheet, View} from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import {
  Appbar,
  Avatar,
  Button,
  Divider,
  IconButton,
  List,
  Text,
  Title,
  TouchableRipple,
} from 'react-native-paper';
import {getUserProfile} from '../api/user';
import {getImageUrl} from '../axios';
import { LocalizationContext } from '../helpers/contexts';

const ManagerScreen = () => {
  const { t } = useContext(LocalizationContext);
  const navigation = useNavigation();
  const openDrawer = () => {
    navigation.dispatch(DrawerActions.openDrawer());
  };

  const {data, status} = getUserProfile();

  const goTo = (route: string, args: any = null) => {
    if (args != null) {
      navigation.navigate(route, args);
    } else {
      navigation.navigate(route);
    }
  };

  if (status == 'success' && data.places.length === 0) {
    return (
      <>
        <Appbar>
          <Appbar.Action icon="menu" onPress={() => openDrawer()} />
          <Appbar.Content title={t('managerScreen.manager')} />
        </Appbar>
        <View style={{flex:1,alignItems:'center',flexDirection: 'column', justifyContent: 'center'}}>
          <View>
            <Title style={{textAlign: 'center', marginBottom: 10}}>{t('managerScreen.yourPlaceNotCreated')}</Title>
            <Button style={{textAlign: 'center'}} mode="contained" onPress={() => {
              navigation.navigate('Contact');
            }}>{t('managerScreen.contactAdmins')}</Button>
          </View>
        </View>
      </>  
    )
  }

  return (
    <>
      <Appbar>
        <Appbar.Action icon="menu" onPress={() => openDrawer()} />
        <Appbar.Content title={t('managerScreen.manager')} />
      </Appbar>
      <ScrollView>
        {status == 'success' && (
          <>
            <TouchableOpacity onPress={() => {
              navigation.navigate("PlaceDetails", {id: data.places[0].id})
            }}>
              <View style={styles.user}>
                {data.places[0].logo ? (
                  <Avatar.Image
                    source={{uri: getImageUrl(data.places[0].logo)}}
                    style={{backgroundColor: '#444'}}
                  />
                ) : (
                  <Avatar.Icon
                    icon="glass-cocktail"
                    style={{backgroundColor: '#444'}}
                  />
                )}
                <Title style={styles.title}>
                  {data.places ? data.places[0].name : ''}
                </Title>
              </View>
            </TouchableOpacity>
            <View style={{backgroundColor: '#333', height: 1, width: '100%'}} />
          </>
        )}
        <List.Item
          title={t('managerScreen.reservations')}
          left={() => <List.Icon icon="calendar" />}
          description={t('managerScreen.reservationsDesc')}
          onPress={() => goTo('ManageReservations', {id: data?.places?.[0]?.id})}
        />
        <List.Item
          title={t('managerScreen.events')}
          left={() => <List.Icon icon="calendar-check-outline" />}
          description={t('managerScreen.eventsDesc')}
          onPress={() =>
            goTo('ManageEvents', {id: data?.places?.[0]?.id})
          }
        />
        <List.Item
          title={t('managerScreen.places')}
          left={() => <List.Icon icon="table-furniture" />}
          description={t('managerScreen.placesDesc')}
          onPress={() => goTo('ManageTables', {id: data?.places?.[0]?.id})}
        />
        <List.Item
          title={t('managerScreen.schema')}
          left={() => <List.Icon icon="file-table-box-outline" />}
          description={t('managerScreen.schemaDesc')}
          onPress={() => goTo('ManageSchema', {id: data?.places?.[0]?.id})}
        />
        <List.Item
          title={t('managerScreen.cafe')}
          left={() => <List.Icon icon="glass-cocktail" />}
          description={t('managerScreen.cafeDesc')}
          onPress={() => goTo('ManagePlace', {id: data?.places?.[0]?.id})}
        />
        <List.Item
          title={t('managerScreen.images')}
          left={() => <List.Icon icon="image-multiple-outline" />}
          description={t('managerScreen.imagesDesc')}
          onPress={() => goTo('ManageSlider', {id: data?.places?.[0]?.id})}
        />
        <List.Item
          title={t('managerScreen.report')}
          left={() => <List.Icon icon="file-chart" />}
          description={t('managerScreen.reportDesc')}
          onPress={() => goTo('ManageReport')}
        />
      </ScrollView>
    </>
  );
};

const styles = StyleSheet.create({
  user: {
    paddingVertical: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    marginTop: 12,
  },
});

export default ManagerScreen;
