import {useNavigation, useRoute} from '@react-navigation/native';
import React, {useContext, useState} from 'react';
import {Dimensions, StyleSheet, View} from 'react-native';
import {ActivityIndicator, FAB, Text, useTheme} from 'react-native-paper';
import {TabBar, TabView} from 'react-native-tab-view';
import {getEvent} from '../../api/events';
import SimpleAppbar from '../../common/SimpleAppbar';
import { LocalizationContext } from '../../helpers/contexts';
import ManageReservationsTab from './ManageReservationsTab';
import { ManageReservationsWaitlist } from './ManageReservationsWaitlist';

const initialLayout = {width: Dimensions.get('window').width};

const ManageReservationsEvent = () => {
  const { t } = useContext(LocalizationContext);
  const params = useRoute();
  const {goBack, navigate} = useNavigation();
  const {colors} = useTheme();
  const eventId = params.params?.eventId;
  const placeId = params.params?.placeId;

  const {status, data, isLoading, isError} = getEvent(eventId);

  const goToAdd = () => {
    navigate('SelectTable', { eventId, placeId });
  };

  const [index, setIndex] = React.useState(0);
  const [routes] = React.useState([
    {key: 'pending', title: 'manageReservationsEvent.pending'},
    {key: 'approved', title: 'manageReservationsEvent.approved'},
    {key: 'canceled', title: 'manageReservationsEvent.canceled'},
    {key: 'user-canceled', title: 'manageReservationsEvent.userCanceled'},
    {key: 'waitlist', title: 'manageReservationsEvent.waitlist'}
  ]);

  const renderScene = ({route}) => {
    switch (route.key) {
      case 'pending':
        return <ManageReservationsTab status="pending" eventId={eventId} />;
      case 'approved':
        return <ManageReservationsTab status="approved" eventId={eventId} />;
      case 'canceled':
        return <ManageReservationsTab status="canceled" eventId={eventId} />;
      case 'user-canceled':
        return <ManageReservationsTab status="user-canceled" eventId={eventId} />;
      case 'waitlist':
        return <ManageReservationsWaitlist eventId={eventId} />;
      default:
        return null;
    }
  };

  const renderTabBar = (props) => (
    <TabBar
      {...props}
      scrollEnabled={true}
      indicatorStyle={{backgroundColor: colors.primary}}
      activeColor={colors.primary}
      inactiveColor={colors.text}
      pressColor="#444"
      style={{backgroundColor: '#282828', elevation: 0}}
      renderLabel={({route, focused, color}) => (
        <Text style={{color}}>{t(route.title)}</Text>
      )}
    />
  );

  const content = () => {
    if (isLoading) {
      return (
        <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
          <ActivityIndicator />
        </View>
      );
    }
    if (isError) {
      return (
        <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
          <Text>{t('common.unexpectedError')}</Text>
        </View>
      );
    }

    return (
      <View style={{flex: 1}}>
        <TabView
          navigationState={{index, routes}}
          renderScene={renderScene}
          onIndexChange={setIndex}
          initialLayout={initialLayout}
          renderTabBar={renderTabBar}
        />
        <FAB
          style={[styles.fab, {backgroundColor: colors.primary}]}
          icon="plus"
          onPress={() => goToAdd()}
        />
      </View>
    );
  };

  return (
    <>
      <SimpleAppbar title={t('manageReservationsEvent.reservations')} />
      {content()}
    </>
  );
};

const styles = StyleSheet.create({
  fab: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    margin: 16
  }
});

export default ManageReservationsEvent;
