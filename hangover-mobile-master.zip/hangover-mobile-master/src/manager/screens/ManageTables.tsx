import {useNavigation, useRoute} from '@react-navigation/native';
import React, { useContext } from 'react';
import {StyleSheet, View} from 'react-native';
import {ScrollView} from 'react-native-gesture-handler';
import {
  ActivityIndicator,
  Appbar,
  Divider,
  List,
  Text,
} from 'react-native-paper';
import {getPlaceTablesAll} from '../../api/places';
import {Table} from '../../api/types/Table';
import SimpleAppbar from '../../common/SimpleAppbar';
import { LocalizationContext } from '../../helpers/contexts';

const ManageTables = () => {
  const { t } = useContext(LocalizationContext);
  const params = useRoute();
  const {navigate} = useNavigation();
  const id = params.params?.id;

  const {data, status} = getPlaceTablesAll(id);

  const renderItem = (item: Table) => {
    let dotStyle: any = {
      borderRadius: 30,
      width: 8,
      height: 8,
      alignSelf: 'center',
      marginRight: 20,
    };

    if (item.status == 'active') {
      dotStyle = {
        ...dotStyle,
        backgroundColor: '#71ce3e',
      };
    } else {
      dotStyle = {
        ...dotStyle,
        backgroundColor: '#ff4848',
      };
    }

    return (
      <View key={item.id}>
        <List.Item
          title={item.name}
          left={() => <Text style={styles.tableNum}>{item.table_num}</Text>}
          right={() => <View style={dotStyle}></View>}
          onPress={() => {
            navigate('FormEditTable', {id: item.id, placeId: item.place_id});
          }}
        />
        <Divider />
      </View>
    );
  };

  return (
    <>
      <SimpleAppbar title={t('formEditTable.editTable')}>
        <Appbar.Action
          icon="plus"
          onPress={() => {
            navigate('FormAddTable', {placeId: id});
          }}
        />
      </SimpleAppbar>
      {status == 'loading' ? (
        <ActivityIndicator />
      ) : status == 'error' ? (
        <Text>{t('common.unexpectedError')}</Text>
      ) : (
        <ScrollView>{data.map(renderItem)}</ScrollView>
      )}
    </>
  );
};

const styles = StyleSheet.create({
  tableNum: {
    backgroundColor: '#03a9f4',
    borderRadius: 20,
    width: 24,
    height: 24,
    textAlign: 'center',
    textAlignVertical: 'center',
    alignSelf: 'center',
    marginLeft: 10,
  },
});
export default ManageTables;
