import React, { useContext, useEffect, useRef } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { editPlace, getPlace } from '../../api/places';
import { getUserProfile } from '../../api/user';
import SimpleAppbar from '../../common/SimpleAppbar';
import { useForm, Controller } from 'react-hook-form';
import { ActivityIndicator, Button, Text, TextInput } from 'react-native-paper';
import ImageInput from '../../common/ImageInput';
import { useNavigation, useRoute } from '@react-navigation/native';
import { getImageUrl } from '../../axios';
import { useDispatch } from 'react-redux';
import { showSnackbar } from '../../appSlice';
import { useQueryCache } from 'react-query';
import { LocalizationContext } from '../../helpers/contexts';

const ManagePlace = () => {
  const { t } = useContext(LocalizationContext);
  const params = useRoute();
  const navigation = useNavigation();
  const id = params.params?.id;

  const dispatch = useDispatch();
  const queryCache = useQueryCache();
  const { data, status } = getPlace(id);  

  const { control, handleSubmit, errors, formState, reset } = useForm({
    reValidateMode: 'onBlur',
  });

  const onSubmit = async (d: any) => {
    try {
      d.id = id;
      const result = await editPlace(d);

      if (result?.error) {
        dispatch(
          showSnackbar(t('common.connectionError')),
        );
      } else {
        dispatch(showSnackbar(t('managePlace.placeSavedSuccess')));
        queryCache.refetchQueries();
        navigation.goBack();
      }
    } catch (e) {
      dispatch(
        showSnackbar(t('common.connectionError')),
      );
    }
  };

  useEffect(() => {
    reset();
  }, [data]);

  return (
    <>
      <SimpleAppbar title={t('managePlace.editPlace')} />
      {status == 'loading' ? (
        <ActivityIndicator />
      ) : status == 'error' ? (
        <Text>{t('common.unexpectedError')}</Text>
      ) : (
            <ScrollView>
              <View style={styles.field}>
                <Controller
                  control={control}
                  name="name"
                  defaultValue={data.name}
                  rules={{ required: true }}
                  render={({ onChange, onBlur, value }) => (
                    <TextInput
                      label={t('managePlace.name')}
                      mode="outlined"
                      onBlur={onBlur}
                      onChangeText={(val) => onChange(val)}
                      value={value}
                    />
                  )}
                />
                {errors.name && <Text>{t('common.fieldRequired')}</Text>}
              </View>
              <View style={styles.field}>
                <Controller
                  control={control}
                  name="description"
                  defaultValue={data.description}
                  rules={{ required: true, minLength: 10 }}
                  render={({ onChange, onBlur, value }) => (
                    <TextInput
                      label={t('managePlace.description')}
                      mode="outlined"
                      multiline={true}
                      onBlur={onBlur}
                      onChangeText={(val) => onChange(val)}
                      value={value}
                    />
                  )}
                />
                {errors.description?.type == 'required' && (
                  <Text>{t('common.fieldRequired')}</Text>
                )}
                {errors.description?.type == 'minLength' && (
                  <Text>{t('formAddEvent.descLengthError')}</Text>
                )}
              </View>
              <View style={styles.field}>
                <Controller
                  control={control}
                  name="logo_image"
                  defaultValue={{
                    uri: getImageUrl(data.logo),
                    isDefault: true,
                    type: '',
                    name: '',
                  }}
                  rules={{ setValueAs: (value) => value }}
                  render={({ onChange, onBlur, value }) => (
                    <ImageInput
                      onBlur={onBlur}
                      onChange={onChange}
                      value={value}
                      label={t('managePlace.chooseLogo')}
                    />
                  )}
                />
              </View>
              <View style={styles.field}>
                <Controller
                  control={control}
                  name="address"
                  defaultValue={data.address}
                  render={({ onChange, onBlur, value }) => (
                    <TextInput
                      label={t('managePlace.address')}
                      mode="outlined"
                      onBlur={onBlur}
                      onChangeText={(val) => onChange(val)}
                      value={value}
                    />
                  )}
                />
              </View>
              <View style={styles.field}>
                <Controller
                  control={control}
                  name="site_url"
                  defaultValue={data.site_url}
                  rules={{
                    validate: {
                      url: validateUrl,
                    },
                  }}
                  render={({ onChange, onBlur, value }) => (
                    <TextInput
                      label={t('managePlace.website')}
                      mode="outlined"
                      onBlur={onBlur}
                      onChangeText={(val) => onChange(val)}
                      value={value}
                    />
                  )}
                />
                {errors.site_url && (
                  <Text>{t('managePlace.urlError')}</Text>
                )}
              </View>
              <View style={styles.field}>
                <Controller
                  control={control}
                  name="fb_url"
                  defaultValue={data.fb_url}
                  rules={{
                    validate: {
                      url: validateUrl,
                    },
                  }}
                  render={({ onChange, onBlur, value }) => (
                    <TextInput
                      label="Facebook url"
                      mode="outlined"
                      onBlur={onBlur}
                      onChangeText={(val) => onChange(val)}
                      value={value}
                    />
                  )}
                />
                {errors.fb_url && (
                  <Text>{t('managePlace.urlError')}</Text>
                )}
              </View>
              <View style={styles.field}>
                <Controller
                  control={control}
                  name="ins_url"
                  defaultValue={data.ins_url}
                  rules={{
                    validate: {
                      url: validateUrl,
                    },
                  }}
                  render={({ onChange, onBlur, value }) => (
                    <TextInput
                      label="Instagram url"
                      mode="outlined"
                      onBlur={onBlur}
                      onChangeText={(val) => onChange(val)}
                      value={value}
                    />
                  )}
                />
                {errors.ins_url && (
                  <Text></Text>
                )}
              </View>
              <View style={styles.field}>
                <Button
                  mode="contained"
                  onPress={handleSubmit(onSubmit)}
                  loading={formState.isSubmitting}
                  disabled={formState.isSubmitting}>
                  <Text>{formState.isSubmitting ? '' : t('common.save')}</Text>
                </Button>
              </View>
            </ScrollView>
          )}
    </>
  );
};

const validateUrl = (value: any) => {
  const valid =
    !value ||
    value.match(
      /^$|https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/,
    ) != null;
  return valid;
};

const styles = StyleSheet.create({
  field: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
});

export default ManagePlace;
