import { useNavigation, useRoute } from '@react-navigation/native';
import React, { useContext, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { StyleSheet, View } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import {
  Appbar,
  Button,
  Checkbox,
  Colors,
  Dialog,
  Text,
  TextInput,
  TouchableRipple
} from 'react-native-paper';
import { useQueryCache } from 'react-query';
import { useDispatch } from 'react-redux';
import { deletePlace, getPlaceTablesAll } from '../../api/places';
import { editTable } from '../../api/tables';
import { showSnackbar } from '../../appSlice';
import SimpleAppbar from '../../common/SimpleAppbar';
import { LocalizationContext } from '../../helpers/contexts';

const FormEditTable = () => {
  const { t } = useContext(LocalizationContext);
  const params = useRoute();
  const { goBack } = useNavigation();
  const id = params.params?.id;
  const placeId = params.params?.placeId;
  const [deleteDialogVisible, setDeleteDialogVisible] = useState(false);

  const { data, status } = getPlaceTablesAll(placeId);

  const table = status == 'success' ? data?.find((x) => x.id == id) : null;

  const dispatch = useDispatch();
  const queryCache = useQueryCache();

  const { control, handleSubmit, errors, formState } = useForm({
    reValidateMode: 'onBlur',
  });

  const onSubmit = async (d: any) => {
    try {
      if (!table) return;

      const tableData = {
        name: d.name,
        table_num: d.table_num,
        id: table.id,
        place_id: table.place_id,
        status: d.status ? 'active' : 'disabled',
      };
      const result = await editTable(tableData);

      if (result?.error) {
        dispatch(
          showSnackbar(t('common.connectionError')),
        );
      } else {
        dispatch(showSnackbar(t('formAddTable.spotDataSaved')));
        queryCache.refetchQueries();
        goBack();
      }
    } catch (e) {
      console.log(e);
      dispatch(
        showSnackbar(t('common.connectionError')),
      );
    }
  };

  const onDeleteConfirm = async () => {
    try {
      const result = await deletePlace(placeId, table?.id);

      if (result?.error) {
        dispatch(
          showSnackbar(t('common.connectionError')),
        );
      } else {
        dispatch(showSnackbar(t('formEditTable.tableRemoveSuccess')));
        queryCache.refetchQueries();
        goBack();
      }
    } catch (e) {
      dispatch(
        showSnackbar(t('common.connectionError')),
      );
    }
  };

  return (
    <>
      <SimpleAppbar
        title={
          table
            ? `${t('formEditTable.editTable')} #${table.table_num}`
            : t('formEditTable.editTable')
        }
      >
        <Appbar.Action icon="delete" onPress={() => setDeleteDialogVisible(true)} />
      </SimpleAppbar>
      {table && (
        <ScrollView>
          <View style={styles.field}>
            <Controller
              control={control}
              name="table_num"
              defaultValue={table.table_num.toString()}
              rules={{ required: true }}
              render={({ onChange, onBlur, value }) => (
                <TextInput
                  label={t('formAddTable.numOfSpots')}
                  mode="outlined"
                  keyboardType="numeric"
                  onBlur={onBlur}
                  onChangeText={(val) => onChange(val)}
                  value={value}
                />
              )}
            />
            {errors.table_num && <Text>{t('common.fieldRequired')}</Text>}
          </View>
          <View style={styles.field}>
            <Controller
              control={control}
              name="name"
              defaultValue={table.name}
              rules={{ required: true, minLength: 3 }}
              render={({ onChange, onBlur, value }) => (
                <TextInput
                  label={t('formAddTable.spotName')}
                  mode="outlined"
                  onBlur={onBlur}
                  onChangeText={(val) => onChange(val)}
                  value={value}
                />
              )}
            />
            {errors.name?.type == 'required' && <Text>{t('common.fieldRequired')}</Text>}
            {errors.name?.type == 'minLength' && (
              <Text>{t('formEditTable.tableNameLengthError')}</Text>
            )}
          </View>
          <View style={styles.field}>
            <Controller
              control={control}
              name="status"
              defaultValue={table.status == 'active'}
              render={({ onChange, onBlur, value }) => (
                <TouchableRipple
                  onPress={() => {
                    onChange(!value);
                  }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Checkbox status={value ? 'checked' : 'unchecked'} />
                    <Text>{t('formAddTable.spotAvailable')}</Text>
                  </View>
                </TouchableRipple>
              )}
            />
          </View>
          <View style={styles.field}>
            <Button
              mode="contained"
              onPress={handleSubmit(onSubmit)}
              loading={formState.isSubmitting}
              disabled={formState.isSubmitting}>
              <Text>{formState.isSubmitting ? '' : t('common.save')}</Text>
            </Button>
          </View>
        </ScrollView>
      )}
      <Dialog visible={deleteDialogVisible}>
        <Dialog.Title>{t('formEditTable.deleteTable')}</Dialog.Title>
        <Dialog.Content>
          <Text>
            {t('formEditTable.deleteTableCheck')} <Text style={{ fontWeight: 'bold' }}>{table?.name}</Text>?
          </Text>
        </Dialog.Content>
        <Dialog.Actions>
          <Button
            color="rgba(255,255,255,0.7)"
            onPress={() => {
              setDeleteDialogVisible(false);
            }}>
            {t('common.cancel')}
          </Button>
          <Button color={Colors.deepOrange400} onPress={onDeleteConfirm}>
            {t('common.delete')}
          </Button>
        </Dialog.Actions>
      </Dialog>
    </>
  );
};

const styles = StyleSheet.create({
  field: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
});

export default FormEditTable;
