import { useNavigation } from '@react-navigation/core';
import React, { useContext, useState } from 'react';
import { Linking, StyleSheet, TouchableHighlight, View } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { Avatar, Button, List, Menu, Modal, Portal, Text } from 'react-native-paper';
import { useQueryCache } from 'react-query';
import { useDispatch } from 'react-redux';
import { changeStatus } from '../../api/reservation';
import { showSnackbar } from '../../appSlice';
import { getImageUrl } from '../../axios';
import { LocalizationContext } from '../../helpers/contexts';

const ManageReservationsWaitlistItem = ({item}: any) => {
  const { t } = useContext(LocalizationContext);
  //const [menuOpen, setMenuOpen] = useState(false);
  const [userModalVisible, setUserModalVisible] = useState(false);
  const { navigate } = useNavigation();

  const callUser = () => {
    Linking.openURL(`tel:+${item.user.phone}`);
  }

  const openViber = () => {
    const url = `viber://chat?number=${item.user.phone}`;
    Linking.openURL(url);
  }

  const openInsta = () => {
    const url = `https://instagram.com/${item.user.ins_url}/`;
    Linking.openURL(url);
  }

  const reportUser = () => {
    setUserModalVisible(false);
    setTimeout(() => {
      navigate("ReportUser", { userId: item.user.id });
    }, 0)
  }

  return (
    <View style={styles.item}>
        <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'}}>
            <View style={{ justifyContent: 'flex-start', flexWrap: "wrap" }}>
                <TouchableHighlight onPress={() => setUserModalVisible(true)} style={{borderRadius:50}}>
                <View style={styles.itemUser}>
                    { item.is_manual ? (<>
                    <Text style={styles.itemUsername}>{item.customer_name}</Text>
                    </>) : (<>
                    <Avatar.Image source={{ uri: getImageUrl(item.user.image) }} size={42} style={{ backgroundColor: '#444'}} />
                    <Text style={styles.itemUsername}>{item.user.first_name} {item.user.last_name}</Text>
                    </>) }
                </View>
                </TouchableHighlight>
            </View>
            <View>
                { item.table ? (
                    <View>
                        <Text style={{color: '#999'}}>{t('manageReservationsEvent.tableName')} <Text style={{fontWeight: 'bold', color: '#fff'}}>{item.table.name}</Text></Text>
                    </View>
                ) : (
                    <View><Text style={{fontWeight: 'bold'}}>{t('manageReservationsEvent.anyTable')}</Text></View>
                ) }
            </View>
        </View>
      <Portal>
        <Modal visible={userModalVisible} onDismiss={() => setUserModalVisible(false)} contentContainerStyle={styles.modal}>
          <View style={styles.modalHeader}>
            { item.is_manual ? (<>
              <Text style={{marginBottom: 10, fontSize: 18}}>{item.customer_name}</Text>
              <Text style={{ backgroundColor: 'rgba(255,255,0,0.1)', paddingHorizontal: 8, paddingVertical: 2, borderRadius:12 }}>{t('manageReservationsEvent.thisReservationIsManual')}</Text>
            </>) : (<>
              <Avatar.Image source={{ uri: getImageUrl(item.user.image) }} size={140} style={{ backgroundColor: '#444'}} />
              <Text style={{marginTop: 10, fontSize: 18}}>{item.user.first_name} {item.user.last_name}</Text>
            </>)}
          </View>
          { !item.is_manual && (
            <View>
              <List.Item left={() => <List.Icon icon="phone" />} title={t('manageReservationsEvent.callUser')} description={'+'+item.user.phone} onPress={() => callUser()} />
              { item.user.has_viber && <List.Item left={() => <List.Icon icon={require('../../assets/viber.png')} />} title={t('manageReservationsEvent.openViber')} description={'+'+item.user.phone} onPress={() => openViber()} /> }
              { item.user.ins_url && <List.Item left={() => <List.Icon icon="instagram" />} title={t('manageReservationsEvent.openInsta')} description={item.user.ins_url} onPress={() => openInsta()} /> }
              { item.user.fb_url && <List.Item left={() => <List.Icon icon="facebook" />} title={t('manageReservationsEvent.openFacebook')} description={item.user.fb_url} onPress={() => Linking.openURL(item.user.fb_url)} /> }
              { !item.is_manual && <List.Item left={() => <List.Icon icon="cancel" />} title={t('manageReservationsEvent.reportUser')} onPress={() => reportUser()} /> } 
            </View>
          )}
        </Modal>
      </Portal>
    </View>
  );
}

const styles = StyleSheet.create({
  tableNum: {
    backgroundColor: '#03a9f4',
    borderRadius: 20,
    width: 24,
    height: 24,
    textAlign: 'center',
    textAlignVertical: 'center',
    marginLeft: 10,
  },
  item: {
    padding: 16,
  },
  itemUser: {
    flexDirection: 'row', 
    alignItems: 'center',
    borderColor: '#555',
    borderWidth: 1,
    borderRadius: 50
  },
  itemUsername: {
    padding: 12
  },
  modal: {
    marginHorizontal: 16,
    backgroundColor: '#333'
  },
  modalHeader: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomColor: '#555',
    borderBottomWidth: 1
  }
});

export default ManageReservationsWaitlistItem;