import { useNavigation, useRoute } from '@react-navigation/native';
import React, { useContext, useState } from 'react';
import { Dimensions, Image, StyleSheet, View } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import {
  ActivityIndicator,
  Appbar,
  Button,
  Colors,
  Dialog,
  IconButton,
  Paragraph,
  Portal,
  Text,
} from 'react-native-paper';
import { useQueryCache } from 'react-query';
import { useDispatch } from 'react-redux';
import { getPlace, removePlaceImage } from '../../api/places';
import { showSnackbar } from '../../appSlice';
import { getImageUrl } from '../../axios';
import SimpleAppbar from '../../common/SimpleAppbar';
import { LocalizationContext } from '../../helpers/contexts';

const ManageSlider = () => {
  const { t } = useContext(LocalizationContext);
  const params = useRoute();
  const { navigate } = useNavigation();
  const id = params.params?.id;

  const { data, status } = getPlace(id);

  const [itemToDelete, setItemToDelete] = useState(0);

  const dispatch = useDispatch();
  const queryCache = useQueryCache();

  const renderItem = (item: any) => {
    return (
      <View key={item.id} style={styles.itemContainer}>
        <View style={styles.actions}>
          <IconButton
            icon="delete"
            style={styles.iconButton}
            onPress={() => {
              setItemToDelete(item.id);
            }}
          />
        </View>
        <Image
          source={{ uri: getImageUrl(item.image) }}
          style={styles.imgStyle}
        />
      </View>
    );
  };

  const onDeleteConfirm = async () => {
    try {
      const result = await removePlaceImage(itemToDelete);

      if (result?.error) {
        dispatch(
          showSnackbar(t('common.connectionError')),
        );
      } else {
        setItemToDelete(0);
        dispatch(showSnackbar(t('manageSlider.imageRemoved')));
        queryCache.refetchQueries();
      }
    } catch (e) {
      console.log(e);
      dispatch(
        showSnackbar(t('common.connectionError')),
      );
    }
  };

  return (
    <>
      <SimpleAppbar title={t('manageSlider.images')}>
        <Appbar.Action
          icon="plus"
          onPress={() => {
            navigate('FormAddSlide', { placeId: id });
          }}
        />
      </SimpleAppbar>
      <ScrollView>
        {status == 'loading' ? (
          <ActivityIndicator />
        ) : status == 'error' ? (
          <Text>{t('common.unexpectedError')}</Text>
        ) : (
              <>{data.sliders.map((item) => renderItem(item))}</>
            )}
      </ScrollView>
      <Portal>
        <Dialog visible={itemToDelete != 0}>
          <Dialog.Title>{t('manageSlider.removeImage')}</Dialog.Title>
          <Dialog.Content>
            <Paragraph>
              {t('manageSlider.removeImageCheck')}
            </Paragraph>
          </Dialog.Content>
          <Dialog.Actions>
            <Button
              color="rgba(255,255,255,0.7)"
              onPress={() => {
                setItemToDelete(0);
              }}>
              {t('common.cancel')}
            </Button>
            <Button color={Colors.deepOrange400} onPress={onDeleteConfirm}>
              {t('common.delete')}
            </Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </>
  );
};

const wid = Dimensions.get('window').width;

const styles = StyleSheet.create({
  imgStyle: {
    width: wid - 32,
    height: wid * 0.8 - 32,
    resizeMode: 'contain',
  },
  itemContainer: {
    padding: 16,
  },
  actions: {
    position: 'absolute',
    top: 25,
    left: 0,
    right: 25,
    zIndex: 1,
    alignItems: 'flex-end',
  },
  iconButton: {
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
});

export default ManageSlider;
