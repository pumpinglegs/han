import {useNavigation, useRoute} from '@react-navigation/native';
import React, { useContext } from 'react';
import {Controller, useForm} from 'react-hook-form';
import {StyleSheet, View} from 'react-native';
import {ScrollView} from 'react-native-gesture-handler';
import {
  Button,
  Checkbox,
  Text,
  TextInput,
  TouchableRipple,
} from 'react-native-paper';
import {useQueryCache} from 'react-query';
import {useDispatch} from 'react-redux';
import {getPlaceTablesAll} from '../../api/places';
import {addTable} from '../../api/tables';
import {Table} from '../../api/types/Table';
import {showSnackbar} from '../../appSlice';
import SimpleAppbar from '../../common/SimpleAppbar';
import { LocalizationContext } from '../../helpers/contexts';

const FormAddTable = () => {
  const { t } = useContext(LocalizationContext);
  const params = useRoute();
  const {goBack} = useNavigation();
  const placeId = params.params?.placeId;

  const dispatch = useDispatch();
  const queryCache = useQueryCache();

  const {control, handleSubmit, errors, formState} = useForm({
    reValidateMode: 'onBlur',
  });

  const onSubmit = async (d: any) => {
    try {
      const tableData = {
        name: d.name,
        table_num: d.table_num,
        place_id: placeId,
        status: d.status ? 'active' : 'disabled',
      };
      const result = await addTable(tableData);

      if (result?.error) {
        dispatch(
          showSnackbar(t('common.connectionError')),
        );
      } else {
        dispatch(showSnackbar(t('formAddTable.spotDataSaved')));
        queryCache.refetchQueries();
        goBack();
      }
    } catch (e) {
      console.log(e);
      dispatch(
        showSnackbar(t('common.connectionError')),
      );
    }
  };
  return (
    <>
      <SimpleAppbar title={t('formAddTable.addPlace')} />
      <ScrollView>
        <View style={styles.field}>
          <Controller
            control={control}
            name="table_num"
            defaultValue=""
            rules={{required: true}}
            render={({onChange, onBlur, value}) => (
              <TextInput
                label={t('formAddTable.numOfSpots')}
                mode="outlined"
                keyboardType="numeric"
                onBlur={onBlur}
                onChangeText={(val) => onChange(val)}
                value={value}
              />
            )}
          />
          {errors.table_num && <Text>This is required.</Text>}
        </View>
        <View style={styles.field}>
          <Controller
            control={control}
            name="name"
            defaultValue=""
            rules={{required: true, minLength: 3}}
            render={({onChange, onBlur, value}) => (
              <TextInput
                label={t('formAddTable.spotName')}
                mode="outlined"
                onBlur={onBlur}
                onChangeText={(val) => onChange(val)}
                value={value}
              />
            )}
          />
          {errors.name?.type == 'required' && <Text>This is required.</Text>}
          {errors.name?.type == 'minLength' && (
            <Text>{t('formAddTable.spotNameLengthError')}</Text>
          )}
        </View>
        <View style={styles.field}>
          <Controller
            control={control}
            name="status"
            defaultValue={true}
            render={({onChange, onBlur, value}) => (
              <TouchableRipple
                onPress={() => {
                  onChange(!value);
                }}>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Checkbox status={value ? 'checked' : 'unchecked'} />
                  <Text>{t('formAddTable.spotAvailable')}</Text>
                </View>
              </TouchableRipple>
            )}
          />
        </View>
        <View style={styles.field}>
          <Button
            mode="contained"
            onPress={handleSubmit(onSubmit)}
            loading={formState.isSubmitting}
            disabled={formState.isSubmitting}>
            <Text>{formState.isSubmitting ? '' : t('common.save')}</Text>
          </Button>
        </View>
      </ScrollView>
    </>
  );
};

const styles = StyleSheet.create({
  field: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
});

export default FormAddTable;
