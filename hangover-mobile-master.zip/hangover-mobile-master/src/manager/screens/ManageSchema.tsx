import React, {useContext, useRef} from 'react';
import {ScrollView, StyleSheet, View} from 'react-native';
import {editPlace, getPlace} from '../../api/places';
import {getUserProfile} from '../../api/user';
import SimpleAppbar from '../../common/SimpleAppbar';
import {useForm, Controller} from 'react-hook-form';
import {ActivityIndicator, Button, Text, TextInput} from 'react-native-paper';
import ImageInput from '../../common/ImageInput';
import {useNavigation, useRoute} from '@react-navigation/native';
import {getImageUrl} from '../../axios';
import {useDispatch} from 'react-redux';
import {showSnackbar} from '../../appSlice';
import {useQueryCache} from 'react-query';
import { LocalizationContext } from '../../helpers/contexts';

const ManageSchema = () => {
  const { t } = useContext(LocalizationContext);
  const params = useRoute();
  const {goBack} = useNavigation();
  const id = params.params?.id;

  const dispatch = useDispatch();
  const queryCache = useQueryCache();
  const {data, status} = getPlace(id);

  const {control, handleSubmit, errors, formState} = useForm({
    reValidateMode: 'onBlur',
  });

  const onSubmit = async (d: any) => {
    try {
      const formData = {
        id: data.id,
        name: data.name,
        description: data.description,
        site_url: data.site_url,
        fb_url: data.fb_url,
        ins_url: data.ins_url,
        schema_place_image: d.schema_place_image,
      };
      const result = await editPlace(formData);

      if (result?.error) {
        dispatch(
          showSnackbar(t('common.connectionError')),
        );
      } else {
        dispatch(showSnackbar(t('managePlace.placeSavedSuccess')));
        queryCache.refetchQueries();
        goBack();
      }
    } catch (e) {
      console.log(e);
      dispatch(
        showSnackbar(t('common.connectionError')),
      );
    }
  };

  return (
    <>
      <SimpleAppbar title={t('manageSchema.schema')} />
      {status == 'loading' ? (
        <ActivityIndicator />
      ) : status == 'error' ? (
        <Text>{t('common.unexpectedError')}</Text>
      ) : (
        <ScrollView>
          <View style={styles.field}>
            <Controller
              control={control}
              name="schema_place_image"
              defaultValue={{
                uri: getImageUrl(data.schema_image),
                isDefault: true,
                type: '',
                name: '',
              }}
              rules={{setValueAs: (value) => value}}
              render={({onChange, onBlur, value}) => (
                <ImageInput
                  onBlur={onBlur}
                  onChange={onChange}
                  value={value}
                  label={t('manageSchema.chooseImage')}
                />
              )}
            />
          </View>
          <View style={styles.field}>
            <Button
              mode="contained"
              onPress={handleSubmit(onSubmit)}
              loading={formState.isSubmitting}
              disabled={formState.isSubmitting || !formState.isDirty}>
              <Text>{formState.isSubmitting ? '' : t('common.save')}</Text>
            </Button>
          </View>
        </ScrollView>
      )}
    </>
  );
};

const styles = StyleSheet.create({
  field: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
});

export default ManageSchema;
