import { useNavigation, useRoute } from '@react-navigation/native';
import React, { useContext, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { Dimensions, ScrollView, StyleSheet, View } from 'react-native';
import {
  ActivityIndicator,
  Appbar,
  Button,
  Checkbox,
  Colors,
  Dialog,
  Paragraph,
  Text,
  TextInput,
  TouchableRipple,
} from 'react-native-paper';
import { useQueryCache } from 'react-query';
import { useDispatch } from 'react-redux';
import { addPlaceImage } from '../../api/places';
import { showSnackbar } from '../../appSlice';
import { getImageUrl } from '../../axios';
import ImageInput from '../../common/ImageInput';
import SimpleAppbar from '../../common/SimpleAppbar';
import DatePicker from 'react-native-date-picker';
import moment from 'moment';
import { deleteEvent, editEvent, getEvent } from '../../api/events';
import { LocalizationContext } from '../../helpers/contexts';

const FormEditEvent = () => {
  const { t } = useContext(LocalizationContext);
  const params = useRoute();
  const { goBack } = useNavigation();
  const eventId = params.params?.eventId;

  const [dialogVisible, setDialogVisible] = useState(false);

  const { status, data } = getEvent(eventId);

  const dispatch = useDispatch();
  const queryCache = useQueryCache();

  const { control, handleSubmit, errors, formState } = useForm({
    reValidateMode: 'onBlur',
  });

  const onSubmit = async (d: any) => {   
    try {
      const formData = {
        id: eventId,
        place_id: data.place_id,
        event_image: d.event_image,
        event_date: moment(d.event_date).format('YYYY-MM-DD'),
        name: d.name,
        short_desc: d.description,
        status: d.status ? 'active' : 'disabled'
      };

      const result = await editEvent(formData);

      if (result?.error) {
        dispatch(
          showSnackbar(t('common.connectionError')),
        );
      } else {
        dispatch(showSnackbar(t('formEditEvent.eventChangedSuccess')));
        queryCache.refetchQueries();
        goBack();
      }
    } catch (e) {
      dispatch(
        showSnackbar(t('common.connectionError')),
      );
    }
  };

  const onDeleteConfirm = async () => {
    try {
      const result = await deleteEvent(eventId);

      if (result?.error) {
        dispatch(
          showSnackbar(t('common.connectionError')),
        );
      } else {
        dispatch(showSnackbar(t('formEditEvent.eventRemovedSuccess')));
        queryCache.refetchQueries();
        goBack();
      }
    } catch (e) {
      dispatch(
        showSnackbar(t('common.connectionError')),
      );
    }
  };

  return (
    <>
      <SimpleAppbar title={t('formEditEvent.editEvent')}>
        <Appbar.Action icon="delete" onPress={() => setDialogVisible(true)} />
      </SimpleAppbar>
      {status == 'loading' ? (
        <ActivityIndicator />
      ) : status == 'error' ? (
        <Text>{t('common.error')}</Text>
      ) : (
            <ScrollView>
              <View style={styles.field}>
                <Controller
                  control={control}
                  name="name"
                  defaultValue={data.name}
                  rules={{ required: true }}
                  render={({ onChange, onBlur, value }) => (
                    <TextInput
                      label={t('formEditEvent.eventName')}
                      mode="outlined"
                      onBlur={onBlur}
                      onChangeText={(val) => onChange(val)}
                      value={value}
                    />
                  )}
                />
                {errors.name && <Text>{t('common.fieldRequired')}</Text>}
              </View>
              <View style={styles.field}>
                <Controller
                  control={control}
                  name="description"
                  defaultValue={data.short_desc}
                  render={({ onChange, onBlur, value }) => (
                    <TextInput
                      label={t('formAddEvent.description')}
                      mode="outlined"
                      multiline={true}
                      onBlur={onBlur}
                      onChangeText={(val) => onChange(val)}
                      value={value}
                    />
                  )}
                />
              </View>
              <View style={styles.field}>
                <View style={styles.datePickerContainer}>
                  <Controller
                    control={control}
                    name="event_date"
                    defaultValue={moment(data.event_date).toDate()}
                    render={({ onChange, onBlur, value }) => (
                      <DatePicker
                        style={styles.datePicker}
                        fadeToColor="#191919"
                        textColor="#fff"
                        locale="sr-ME"
                        mode="date"
                        is24hourSource="locale"
                        onDateChange={(val) => {
                          onChange(val);
                          onBlur();
                        }}
                        date={value}
                      />
                    )}
                  />
                </View>
              </View>
              <View style={styles.field}>
                <Controller
                  control={control}
                  name="status"
                  defaultValue={data.status == 'active'}
                  render={({ onChange, onBlur, value }) => (
                    <TouchableRipple
                      onPress={() => {
                        onChange(!value);
                      }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Checkbox status={value ? 'checked' : 'unchecked'} />
                        <Text>{t('formEditEvent.reservationPossible')}</Text>
                      </View>
                    </TouchableRipple>
                  )}
                />
              </View>
              <View style={styles.field}>
                <Controller
                  control={control}
                  name="event_image"
                  defaultValue={{
                    uri: getImageUrl(data.image),
                    isDefault: true,
                    type: '',
                    name: '',
                  }}
                  rules={{ setValueAs: (value) => value }}
                  render={({ onChange, onBlur, value }) => (
                    <ImageInput
                      onBlur={onBlur}
                      onChange={onChange}
                      value={value}
                      label={t('formAddEvent.chooseImage')}
                    />
                  )}
                />
              </View>
              <View style={styles.field}>
                <Button
                  mode="contained"
                  onPress={handleSubmit(onSubmit)}
                  loading={formState.isSubmitting}
                  disabled={formState.isSubmitting || !formState.isDirty}>
                  <Text>{formState.isSubmitting ? '' : t('common.save')}</Text>
                </Button>
              </View>
            </ScrollView>
          )}
      <Dialog visible={dialogVisible}>
        <Dialog.Title>{t('formEditEvent.removeEvent')}</Dialog.Title>
        <Dialog.Content>
          <Paragraph>
            {t('formEditEvent.removeEventCheck')}
          </Paragraph>
        </Dialog.Content>
        <Dialog.Actions>
          <Button
            color="rgba(255,255,255,0.7)"
            onPress={() => {
              setDialogVisible(false);
            }}>
            {t('common.cancel')}
          </Button>
          <Button color={Colors.deepOrange400} onPress={onDeleteConfirm}>
            {t('common.delete')}
          </Button>
        </Dialog.Actions>
      </Dialog>
    </>
  );
};

const wid = Dimensions.get('window').width;

const styles = StyleSheet.create({
  field: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  datePickerContainer: {
    borderWidth: 1,
    borderColor: '#999',
    borderRadius: 3,
  },
  datePicker: {
    width: wid - 17 * 2,
  },
});

export default FormEditEvent;
