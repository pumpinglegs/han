import React, { useContext, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import {Dimensions, ScrollView, StyleSheet, View} from 'react-native';
import SimpleAppbar from '../../common/SimpleAppbar';
import { LocalizationContext } from '../../helpers/contexts';
import DatePicker from 'react-native-date-picker';
import { Button, Dialog, Paragraph, RadioButton, Text } from 'react-native-paper';
import moment from 'moment';
import axios from '../../axios';
import { useDispatch } from 'react-redux';
import { showSnackbar } from '../../appSlice';

const ManageReport = () => {
  const { t } = useContext(LocalizationContext);
  const dispatch = useDispatch();
  
  const [dialogVisible, setDialogVisible] = useState(false);
  const [resultCount, setResultCount] = useState(0);
  
  const { control, handleSubmit, errors, formState } = useForm({
    reValidateMode: 'onBlur',
  });

  const onSubmit = async (d: any) => {
    const data = {
      start_date: moment(d.start_date).format('YYYY-MM-DD'),
      end_date: moment(d.end_date).format('YYYY-MM-DD'),
      status: d.status
    };

    try {
      const result = await axios.get('/api/reservation/count', { params: data });
      const count = Number(result.data);

      setResultCount(count);
      setDialogVisible(true);
    } catch (err) {
      dispatch(showSnackbar(t('common.errorTryAgain')));
    }
  }
  
  return (
    <>
      <SimpleAppbar title={t('common.report')} />
      <ScrollView>
        <View style={styles.field}>
          <Text style={{marginBottom:5}}>{t('managerReport.startDate')}</Text>
          <View style={styles.datePickerContainer}>
            <Controller
              control={control}
              name="start_date"
              defaultValue={new Date()}
              render={({ onChange, onBlur, value }) => (
                <DatePicker
                  style={styles.datePicker}
                  fadeToColor="#191919"
                  textColor="#fff"
                  locale="sr-ME"
                  mode="date"
                  is24hourSource="locale"
                  onDateChange={(val) => {
                    onChange(val);
                    onBlur();
                  }}
                  date={value}
                />
              )}
            />
          </View>
        </View>
        <View style={styles.field}>
          <Text style={{marginBottom:5}}>{t('managerReport.endDate')}</Text>
          <View style={styles.datePickerContainer}>
            <Controller
              control={control}
              name="end_date"
              defaultValue={new Date()}
              render={({ onChange, onBlur, value }) => (
                <DatePicker
                  style={styles.datePicker}
                  fadeToColor="#191919"
                  textColor="#fff"
                  locale="sr-ME"
                  mode="date"
                  is24hourSource="locale"
                  onDateChange={(val) => {
                    onChange(val);
                    onBlur();
                  }}
                  date={value}
                />
              )}
            />
          </View>
        </View>
        <View style={styles.field}>
          <Text style={{marginBottom:5}}>{t('managerReport.status')}</Text>
          <Controller
            control={control}
            name="status"
            defaultValue="approved"
            render={({ onChange, onBlur, value }) => (
              <RadioButton.Group onValueChange={newValue => {onChange(newValue); onBlur();}} value={value}>
                <View>
                  <RadioButton.Item label={t('manageReservationsEvent.approved')} value="approved" />
                </View>
                <View>
                  <RadioButton.Item label={t('manageReservationsEvent.pending')} value="pending" />
                </View>
                <View>
                  <RadioButton.Item label={t('manageReservationsEvent.canceled')} value="canceled" />
                </View>
              </RadioButton.Group>
            )} 
          />
        </View>
        <View style={styles.field}>
          <Button
            mode="contained"
            onPress={handleSubmit(onSubmit)}
            loading={formState.isSubmitting}
            disabled={formState.isSubmitting}>
            <Text>{formState.isSubmitting ? '' : t('common.report')}</Text>
          </Button>
        </View>
      </ScrollView>
      <Dialog visible={dialogVisible}>
        <Dialog.Content>
          <Paragraph>
            {t('managerReport.result') + " " + resultCount.toString()}
          </Paragraph>
        </Dialog.Content>
        <Dialog.Actions>
          <Button
            color="rgba(255,255,255,0.7)"
            onPress={() => {
              setDialogVisible(false);
            }}>
            {t('common.cancel')}
          </Button>
        </Dialog.Actions>
      </Dialog>
    </>
  );
};

const wid = Dimensions.get('window').width;

const styles = StyleSheet.create({
  field: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  datePickerContainer: {
    borderWidth: 1,
    borderColor: '#999',
    borderRadius: 3,
  },
  datePicker: {
    width: wid - 17 * 2,
  },
});

export default ManageReport;
