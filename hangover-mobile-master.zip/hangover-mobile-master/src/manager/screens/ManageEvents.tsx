import {useNavigation, useRoute} from '@react-navigation/native';
import React, {useContext, useState} from 'react';
import {FlatList, View} from 'react-native';
import {ActivityIndicator, Appbar, Text} from 'react-native-paper';
import {getPlace} from '../../api/places';
import NoResults from '../../common/NoResults';
import SimpleAppbar from '../../common/SimpleAppbar';
import EventListItem from '../../events/EventListItem';
import { LocalizationContext } from '../../helpers/contexts';

const ManageEvents = () => {
  const { t } = useContext(LocalizationContext);
  const params = useRoute();
  const {navigate} = useNavigation();

  const id = params.params?.id;

  const {data, status, refetch} = getPlace(id);

  const [isRefreshing, setIsRefreshing] = useState(false);

  const refresh = async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  };

  const resolvedData: any[] = data?.events ?? [];

  const openEvent = (id) => {
    navigate('FormEditEvent', {eventId: id});
  };

  const renderItem = ({item, index}) => {
    return <EventListItem item={item} onPress={(id) => openEvent(id)} />;
  };

  return (
    <>
      <SimpleAppbar title={t('manageEvents.events')}>
        <Appbar.Action
          icon="plus"
          onPress={() => {
            navigate('FormAddEvent', {placeId: id});
          }}
        />
      </SimpleAppbar>
      <View>
        {status == 'loading' ? (
          <ActivityIndicator />
        ) : status == 'error' ? (
          <Text>{t('common.unexpectedError')}</Text>
        ) : (
          <FlatList
            refreshing={isRefreshing}
            onRefresh={refresh}
            data={resolvedData}
            renderItem={renderItem}
            keyExtractor={(item) => item.id.toString()}
            //ListFooterComponent={listFooter()}
            //ListHeaderComponent={listHeader()}
            ItemSeparatorComponent={() => <View style={{height: 16}}></View>}
            ListEmptyComponent={() => (
              <NoResults
                title={t('manageEvents.noEvents')}
                text={t('manageEvents.noEventsText')}
              />
            )}
          />
        )}
      </View>
    </>
  );
};

export default ManageEvents;
