import {useNavigation, useRoute} from '@react-navigation/native';
import React, { useContext } from 'react';
import {Controller, useForm} from 'react-hook-form';
import {ScrollView, StyleSheet, View} from 'react-native';
import {Button, Text} from 'react-native-paper';
import {useQueryCache} from 'react-query';
import {useDispatch} from 'react-redux';
import {addPlaceImage} from '../../api/places';
import {showSnackbar} from '../../appSlice';
import {getImageUrl} from '../../axios';
import ImageInput from '../../common/ImageInput';
import SimpleAppbar from '../../common/SimpleAppbar';
import { LocalizationContext } from '../../helpers/contexts';

const FormAddSlide = () => {
  const { t } = useContext(LocalizationContext);
  const params = useRoute();
  const {goBack} = useNavigation();
  const placeId = params.params?.placeId;

  const dispatch = useDispatch();
  const queryCache = useQueryCache();

  const {control, handleSubmit, errors, formState} = useForm({
    reValidateMode: 'onBlur',
  });

  const onSubmit = async (d: any) => {
    try {
      const data = {
        id: placeId,
        slide_image: d.slide_image,
      };

      const result = await addPlaceImage(data);

      if (result?.error) {
        dispatch(
          showSnackbar(t('common.connectionError')),
        );
      } else {
        dispatch(showSnackbar(t('common.imageSaved')));
        queryCache.refetchQueries();
        goBack();
      }
    } catch (e) {
      console.log(e);
      dispatch(
        showSnackbar(t('common.connectionError')),
      );
    }
  };

  return (
    <>
      <SimpleAppbar title={t('formAddSlide.addImage')} />
      <ScrollView>
        <View style={styles.field}>
          <Controller
            control={control}
            name="slide_image"
            defaultValue={null}
            rules={{setValueAs: (value) => value}}
            render={({onChange, onBlur, value}) => (
              <ImageInput
                onBlur={onBlur}
                onChange={onChange}
                value={value}
                label={t('formAddEvent.chooseImage')}
              />
            )}
          />
        </View>
        <View style={styles.field}>
          <Button
            mode="contained"
            onPress={handleSubmit(onSubmit)}
            loading={formState.isSubmitting}
            disabled={formState.isSubmitting || !formState.isDirty}>
            <Text>{formState.isSubmitting ? '' : t('common.save')}</Text>
          </Button>
        </View>
      </ScrollView>
    </>
  );
};

const styles = StyleSheet.create({
  field: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
});

export default FormAddSlide;
