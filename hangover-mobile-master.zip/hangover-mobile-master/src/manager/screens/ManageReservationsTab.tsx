import React, { useContext, useState } from 'react';
import {FlatList, StyleSheet, Text, View} from 'react-native';
import { ActivityIndicator, Avatar, Button, Divider } from 'react-native-paper';
import { getManagerReservations } from '../../api/reservation';
import { getImageUrl } from '../../axios';
import ManageReservationsEventItem from './ManageReservationsEventItem';

import { LocalizationContext } from '../../helpers/contexts';

interface ManageReservationsTabProps {
  status: string;
  eventId: any;
}

const ManageReservationsTab = ({status, eventId}: ManageReservationsTabProps) => {

  const { t } = useContext(LocalizationContext);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const {
    status: queryStatus,
    data,
    isFetching,
    isFetchingMore,
    fetchMore,
    canFetchMore,
    refetch,
  } = getManagerReservations(status, eventId);

  
  const refresh = async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  };

  const resolvedData: any[] = [];

  data?.forEach((list) => resolvedData.push(...list));

  const renderItem = ({item}) => {
    return <ManageReservationsEventItem item={item} onSetStatus={()=> refresh()}/>
  };
  
  return (
    <>
      {queryStatus == 'loading' ? (
        <ActivityIndicator />
      ) : queryStatus == 'error' ? (
        <Text>{t('common.unexpectedError')}</Text>
      ) : (
        <FlatList
          contentContainerStyle={styles.container}
          refreshing={isRefreshing}
          onRefresh={refresh}
          data={resolvedData}
          renderItem={renderItem}
          keyExtractor={(item) => item.id.toString()}
          onEndReached={() => fetchMore()}
          ListEmptyComponent={() => <View style={styles.listempty}><Text>{t('manageReservationsEvent.noReservations')}</Text></View>}
          ItemSeparatorComponent={() => <Divider style={{height:1}} />}
        />
      )}
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingTop: 16,
  },
  listempty: {justifyContent:'center', flexDirection: 'row', height: 150, alignItems:'center'}
});


export default ManageReservationsTab;
