import { useNavigation, useRoute } from '@react-navigation/native';
import React, { useContext } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { ScrollView, StyleSheet, View } from 'react-native';
import { Button, Text, TextInput } from 'react-native-paper';
import { useDispatch } from 'react-redux';
import { reportUser } from '../../api/user';
import { showSnackbar } from '../../appSlice';
import SimpleAppbar from '../../common/SimpleAppbar';
import { LocalizationContext } from '../../helpers/contexts';

const ReportUser = () => {
  const { t } = useContext(LocalizationContext);

  const params = useRoute();
  const userId = params.params?.userId;
  
  const {goBack} = useNavigation();
  const dispatch = useDispatch();
  
  const {control, handleSubmit, errors, formState} = useForm({
    reValidateMode: 'onBlur',
  });

  
  const onSubmit = async (d: any) => {
    try {
      const data = {
        userId,
        description: d.description
      };
      
      const result = await reportUser(data);

      if (result?.error) {
        dispatch(
          showSnackbar(t('common.connectionError')),
        );
      } else {
        dispatch(showSnackbar(t('reportUser.userReported')));
        goBack();
      }
    } catch (e) {
      dispatch(
        showSnackbar(t('common.connectionError')),
      );
    }
  };
  
  return (
    <>
      <SimpleAppbar title={t('reportUser.title')} />
      <ScrollView>
        <View style={styles.field}>
          <Controller
            control={control}
            name="description"
            defaultValue=""
            rules={{ required: true, minLength: 10 }}
            render={({ onChange, onBlur, value }) => (
              <TextInput
                label={t('reportUser.description')}
                mode="outlined"
                multiline={true}
                numberOfLines={8}
                onBlur={onBlur}
                onChangeText={(val) => onChange(val)}
                value={value}
              />
            )}
          />
          {errors.description?.type == 'required' && (
            <Text>{t('common.fieldRequired')}</Text>
          )}
        </View>
        <View style={styles.field}>
          <Button
            mode="contained"
            onPress={handleSubmit(onSubmit)}
            loading={formState.isSubmitting}
            disabled={formState.isSubmitting}>
            <Text>{formState.isSubmitting ? '' : t('reportUser.reportBtn')}</Text>
          </Button>
        </View>
      </ScrollView>
    </>
  );
};

const styles = StyleSheet.create({
  field: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
});

export default ReportUser;