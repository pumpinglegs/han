import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import ManagerScreen from './ManagerScreen';
import ManageReservations from './screens/ManageReservations';
import ManageEvents from './screens/ManageEvents';
import ManageTables from './screens/ManageTables';
import ManageSchema from './screens/ManageSchema';
import ManagePlace from './screens/ManagePlace';
import ManageSlider from './screens/ManageSlider';
import ManageReport from './screens/ManageReport';
import FormEditTable from './screens/FormEditTable';
import FormAddTable from './screens/FormAddTable';
import FormAddSlide from './screens/FormAddSlide';
import FormAddEvent from './screens/FormAddEvent';
import FormEditEvent from './screens/FormEditEvent';
import ManageReservationsEvent from './screens/ManageReservationsEvent';
import ReportUser from './screens/ReportUser';

const Stack = createStackNavigator();

const ManagerNavigation = () => {
  return (
    <Stack.Navigator initialRouteName="ManagerHome" headerMode="none">
      <Stack.Screen name="ManagerHome" component={ManagerScreen} />
      <Stack.Screen name="ManageReservations" component={ManageReservations} />
      <Stack.Screen name="ManageEvents" component={ManageEvents} />
      <Stack.Screen name="ManageTables" component={ManageTables} />
      <Stack.Screen name="ManageSchema" component={ManageSchema} />
      <Stack.Screen name="ManagePlace" component={ManagePlace} />
      <Stack.Screen name="ManageSlider" component={ManageSlider} />
      <Stack.Screen name="ManageReport" component={ManageReport} />
      <Stack.Screen name="FormEditTable" component={FormEditTable} />
      <Stack.Screen name="FormAddTable" component={FormAddTable} />
      <Stack.Screen name="FormAddSlide" component={FormAddSlide} />
      <Stack.Screen name="FormAddEvent" component={FormAddEvent} />
      <Stack.Screen name="FormEditEvent" component={FormEditEvent} />
      <Stack.Screen
        name="ManageReservationsEvent"
        component={ManageReservationsEvent}
      />
      <Stack.Screen
        name="ReportUser"
        component={ReportUser}
      />
    </Stack.Navigator>
  );
};

export default ManagerNavigation;
