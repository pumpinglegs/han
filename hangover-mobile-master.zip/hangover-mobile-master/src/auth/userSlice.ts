import { createSlice } from '@reduxjs/toolkit';

export const userSlice = createSlice({
    name: 'user',
    initialState: {
        isAuthenticated: false,
        language: 'cg',
        user: null,
        tempUser: null
    },
    reducers: {
        setIsAuthenticated: (state, action) => {
            state.isAuthenticated = action.payload;
        },
        setLanguage: (state, action) => {
            state.language = action.payload;
        },
        setUser: (state, action) => {
            state.user = action.payload;
        },
        setTempUser: (state, action) => {
            state.tempUser = action.payload;
        }
    }
});

export const { setIsAuthenticated, setLanguage, setUser, setTempUser } = userSlice.actions;

export const getIsAuthenticated = state => state.user.isAuthenticated;
export const getLanguage = state => state.user.language;
export const getUser = state => state.user.user;
export const getTempUser = state => state.user.tempUser;

export default userSlice.reducer;