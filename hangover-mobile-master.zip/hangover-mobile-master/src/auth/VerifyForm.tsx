import { useNavigation } from '@react-navigation/native';
import React, {useContext, useState} from 'react';
import {Controller, useForm} from 'react-hook-form';
import {ScrollView, StyleSheet, View} from 'react-native';
import {Appbar, Button, Text, TextInput} from 'react-native-paper';
import {useDispatch, useSelector} from 'react-redux';
import { showSnackbar } from '../appSlice';
import axios from '../axios';
import {LocalizationContext} from '../helpers/contexts';
import { handleSignInResponse } from './checkAuth';
import {getTempUser} from './userSlice';

var RESEND_COUNTER = 0;

setInterval(() => {
  if (RESEND_COUNTER > 0) {
    RESEND_COUNTER--;
  }
}, 1000);

const VerifyForm = () => {
  const {t} = useContext(LocalizationContext);

  const {navigate} = useNavigation();
  const dispatch = useDispatch();

  const tempUser = useSelector(getTempUser);
  // id, phone, username
  // const tempUser = {
  //   id: 10,
  //   phone: '38267123456',
  //   username: 'testtest'
  // };

  const {control, handleSubmit, errors, formState, getValues} = useForm({
    reValidateMode: 'onBlur',
  });
  
  const onSubmit = async (d: any) => {
    const data = {
      key_code: d.key_code,
      user_id: tempUser.id,
      password: d.password,
      repeat_password: d.password_confirm
    };
    
    try {
      var response = await axios.post("/api/user/verify", data);
      if (response.status == 200) {
        handleSignInResponse(response.data);
        navigate("Home");
      } else {
        dispatch(showSnackbar(t('verification.wrongCode')));
      }
    } catch (e) {
      dispatch(showSnackbar(t('common.errorTryAgain')));
    }
  };

  const resendSms = async () => {
    if (RESEND_COUNTER > 0) {
      dispatch(showSnackbar(`${t('verification.errorRepeat')}${RESEND_COUNTER}${t('verification.errorRepeatS')}`));
      return;
    }

    RESEND_COUNTER = 120;
    
    const data = {
      user_id: tempUser.id,
    };

    try {
      var response = await axios.post("/api/user/sendagain", data);
      if (response.status == 200) {
        dispatch(showSnackbar(t('verification.resend') + tempUser.phone));
      } else {
        dispatch(showSnackbar(t('common.errorTryAgain')));
      }
    } catch (e) {
      dispatch(showSnackbar(t('common.errorTryAgain')));
    }
  };
 
  return (
    <>
      <Appbar>
        <Appbar.Content title={t('common.verification')} />
      </Appbar>
      <ScrollView>
        <View style={styles.info}>
          <Text style={styles.infoText}>{t('verification.description')}{tempUser.phone}</Text>
          <View style={styles.infoActions}>
            <Button mode="text" style={styles.infoActionBtn} onPress={resendSms}>{t('verification.resendBtn')}</Button>
          </View>
        </View>
        <View style={styles.field}>
          <Controller
            control={control}
            name="key_code"
            defaultValue=""
            rules={{required: true}}
            render={({onChange, onBlur, value}) => (
              <TextInput
                label={t('verification.keyCodeLabel')}
                mode="outlined"
                onBlur={onBlur}
                onChangeText={(val) => onChange(val)}
                value={value}
              />
            )}
          />
          {errors.key_code && <Text>{t('common.fieldRequired')}</Text>}
        </View>
        <View style={styles.field}>
          <Controller
            control={control}
            name="password"
            defaultValue=""
            rules={{required: true}}
            render={({onChange, onBlur, value}) => (
              <TextInput
                secureTextEntry={true}
                label={t('loginForm.password')}
                textContentType="password"
                mode="outlined"
                onBlur={onBlur}
                onChangeText={(val) => onChange(val)}
                value={value}
              />
            )}
          />
          {errors.password && <Text>{t('common.fieldRequired')}</Text>}
        </View>
        <View style={styles.field}>
          <Controller
            control={control}
            name="password_confirm"
            defaultValue=""
            rules={{validate: (val) => {
              return getValues('password') == val;
            }}}
            render={({onChange, onBlur, value}) => (
              <TextInput
                secureTextEntry={true}
                label={t('verification.repeatPassword')}
                textContentType="password"
                mode="outlined"
                onBlur={onBlur}
                onChangeText={(val) => onChange(val)}
                value={value}
              />
            )}
          />
          {errors.password_confirm && <Text>{t('verification.repeatPasswordError')}</Text>}
        </View>
        <View style={styles.field}>
          <Button
            mode="contained"
            onPress={handleSubmit(onSubmit)}
            loading={formState.isSubmitting}
            disabled={formState.isSubmitting || !formState.isDirty}>
            <Text>{formState.isSubmitting ? '' : t('verification.confirmBtn')}</Text>
          </Button>
        </View>
      </ScrollView>
    </>
  );
};

const styles = StyleSheet.create({
  field: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  info: {
    margin: 16,
    backgroundColor: '#282828',
    borderRadius: 6,
    padding: 12,
    paddingBottom: 6
  },
  infoText: {
    lineHeight: 20,
    marginBottom: 4
  },
  infoActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end'
  },
  infoActionBtn: {
    marginBottom: 0
  }
});

export default VerifyForm;