import React from "react";
import { Text, View } from "react-native";


const AppLoading: React.FC = () => {
    return (
        <View>
            <Text>Loading...</Text>
        </View>
    );
}

export default AppLoading;