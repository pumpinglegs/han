import { useNavigation, useRoute } from '@react-navigation/native';
import React, {useContext, useState} from 'react';
import {Controller, useForm} from 'react-hook-form';
import {ScrollView, StyleSheet, View} from 'react-native';
import {Appbar, Button, Text, TextInput} from 'react-native-paper';
import { useQueryCache } from 'react-query';
import {useDispatch, useSelector} from 'react-redux';
import { showSnackbar } from '../appSlice';
import axios from '../axios';
import {LocalizationContext} from '../helpers/contexts';
import { handleSignInResponse } from './checkAuth';

const ResetConfirmForm = () => {
  const {t} = useContext(LocalizationContext);

  const {navigate} = useNavigation();
  const dispatch = useDispatch();
  const {params} = useRoute();
  const queryCache = useQueryCache();

  const tempUser = params?.user;
  // id, phone, username
  // const tempUser = {
  //   id: 10,
  //   phone: '38267123456',
  //   username: 'testtest'
  // };

  const {control, handleSubmit, errors, formState, getValues} = useForm({
    reValidateMode: 'onBlur',
  });
  
  const onSubmit = async (d: any) => {
    const data = {
      key_code: d.key_code,
      user_id: tempUser.id,
      password: d.password,
      repeat_password: d.password_confirm
    };
    
    try {
      var response = await axios.post("/api/user/confirmPassword", data);
      if (response.status == 200) {
        handleSignInResponse(response.data);
        queryCache.invalidateQueries();
        navigate("Home");
      } else {
        dispatch(showSnackbar(t('verification.wrongCode')));
      }
    } catch (e) {
      dispatch(showSnackbar(t('common.errorTryAgain')));
    }
  };

  return (
    <>
      <Appbar>
        <Appbar.Content title={t('resetForm.confirmTitle')} />
      </Appbar>
      <ScrollView>
        <View style={styles.field}>
          <Controller
            control={control}
            name="key_code"
            defaultValue=""
            rules={{required: true}}
            render={({onChange, onBlur, value}) => (
              <TextInput
                label={t('verification.keyCodeLabel')}
                mode="outlined"
                onBlur={onBlur}
                onChangeText={(val) => onChange(val)}
                value={value}
              />
            )}
          />
          {errors.key_code && <Text>{t('common.fieldRequired')}</Text>}
        </View>
        <View style={styles.field}>
          <Controller
            control={control}
            name="password"
            defaultValue=""
            rules={{required: true}}
            render={({onChange, onBlur, value}) => (
              <TextInput
                secureTextEntry={true}
                label={t('loginForm.password')}
                textContentType="password"
                mode="outlined"
                onBlur={onBlur}
                onChangeText={(val) => onChange(val)}
                value={value}
              />
            )}
          />
          {errors.password && <Text>{t('common.fieldRequired')}</Text>}
        </View>
        <View style={styles.field}>
          <Controller
            control={control}
            name="password_confirm"
            defaultValue=""
            rules={{validate: (val) => {
              return getValues('password') == val;
            }}}
            render={({onChange, onBlur, value}) => (
              <TextInput
                secureTextEntry={true}
                label={t('verification.repeatPassword')}
                textContentType="password"
                mode="outlined"
                onBlur={onBlur}
                onChangeText={(val) => onChange(val)}
                value={value}
              />
            )}
          />
          {errors.password_confirm && <Text>{t('verification.repeatPasswordError')}</Text>}
        </View>
        <View style={styles.field}>
          <Button
            mode="contained"
            onPress={handleSubmit(onSubmit)}
            loading={formState.isSubmitting}
            disabled={formState.isSubmitting || !formState.isDirty}>
            <Text>{formState.isSubmitting ? '' : t('resetForm.confirmPassBtn')}</Text>
          </Button>
        </View>
      </ScrollView>
    </>
  );
};

const styles = StyleSheet.create({
  field: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  info: {
    margin: 16,
    backgroundColor: '#282828',
    borderRadius: 6,
    padding: 12,
    paddingBottom: 6
  },
  infoText: {
    lineHeight: 20,
    marginBottom: 4
  },
  infoActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end'
  },
  infoActionBtn: {
    marginBottom: 0
  }
});

export default ResetConfirmForm;