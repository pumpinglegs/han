import { useNavigation } from '@react-navigation/native';
import React, { useContext, useState } from 'react';
import { StyleSheet, TouchableWithoutFeedback, View } from 'react-native';
import { Appbar, Button, HelperText, Menu, Text, TextInput } from 'react-native-paper';
import { useDispatch } from 'react-redux';
import { showSnackbar } from '../appSlice';
import axios from '../axios';
import { LocalizationContext } from '../helpers/contexts';
import { setTempUser } from './userSlice';

const ResetPassForm = () => {
    const { t } = useContext(LocalizationContext);
    const { navigate, goBack } = useNavigation();
    const dispatch = useDispatch();

    const [showValidation, setShowValidation] = useState(false);
    
    const [phone, setPhone] = useState('');
    
    const errors = {
        phone: ''
    };
    if (phone.length == 0) {
        errors.phone = t('common.fieldRequired');
    }
    
    const valid = !errors.phone;

    const submit = () => {
        if (!valid) {
            setShowValidation(true);
            return;
        }

        axios.post("/api/user/resetPassword", {phone}).then(response => {
            const user = response.data;
            navigate('ResetConfirm', {user});
        }).catch(reason => {
            dispatch(showSnackbar(t('loginForm.user_not_existing')));
        });
    };

    return (
        <>
            <Appbar>
                <Appbar.BackAction onPress={() => goBack() } />
                <Appbar.Content title={t('resetForm.title')} />
            </Appbar>
            <View style={styles.container}>
                <TextInput 
                    style={{ marginBottom: 16 }}
                    label={t('loginForm.username')}
                    value={phone}
                    onChangeText={text => setPhone(text)}
                    mode="outlined"
                />
                <HelperText type="error" visible={showValidation && errors.phone.length > 0}>{errors.phone}</HelperText>
                <Button mode="contained" style={styles.submit} onPress={() => submit()}>{t('resetForm.resetBtn')}</Button>
            </View>
        </>
    );
};

const styles = StyleSheet.create({
    container: {
        padding: 16
    },
    fieldRow: {
        flexDirection: "row",
        marginTop: 16
    },
    openMenuBtn: {
        marginTop: 6
    },
    openMenuBtnContent: {
        height: 58,
    },
    submit: {
        marginTop: 24
    }
});

export default ResetPassForm;