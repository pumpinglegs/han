import { useNavigation } from '@react-navigation/native';
import React, { useContext, useState } from 'react';
import { StyleSheet, TouchableWithoutFeedback, View } from 'react-native';
import { Appbar, Button, HelperText, Menu, Text, TextInput } from 'react-native-paper';
import { useDispatch } from 'react-redux';
import { showSnackbar } from '../appSlice';
import axios from '../axios';
import { LocalizationContext } from '../helpers/contexts';
import { setTempUser } from './userSlice';

const RegisterForm = () => {
    const { t } = useContext(LocalizationContext);
    const { navigate, goBack } = useNavigation();
    const dispatch = useDispatch();

    const [showValidation, setShowValidation] = useState(false);
    
    const [username, setUsername] = useState('');
    const [phone, setPhone] = useState('');

    const [menuVisible, setMenuVisible] = useState(false);
    const [selectedItem, setSelectedItem] = useState("382");

    const closeMenu = () => setMenuVisible(false);
    const openMenu = () => setMenuVisible(true);

    const selectOption = (item: string) => {
        setSelectedItem(item);
        closeMenu();
    }

    const availableOptions = [
        { title: "+382", value: "382" },
        { title: "+381", value: "381" },
        { title: "+387", value: "387" },
        { title: "+385", value: "385" },
        { title: "+389", value: "389" },
        { title: "+386", value: "386" },
        { title: "+383", value: "383" },
        { title: "+355", value: "355" }
    ];
    
    const selectedItemTitle = availableOptions.find(x => x.value == selectedItem)?.title;

    const errors = {
        username: '',
        phone: ''
    };
    if (/(?=^.{3,20}$)^[a-zA-Z][a-zA-Z0-9]*[._-]?[a-zA-Z0-9]+$/.test(username) == false) {
        errors.username = t('registrationForm.usernameError');
    }
    if (username.length == 0) {
        errors.username = t('common.fieldRequired');
    }
    if (phone.length == 0) {
        errors.phone = t('common.fieldRequired');
    }
    
    const valid = !errors.username && !errors.phone;

    const submit = () => {
        if (!valid) {
            setShowValidation(true);
            return;
        }

        const postData = {
            username, 
            phone: selectedItem + "" + Number(phone)
        };

        axios.post("/api/user/register", postData).then(response => {
            dispatch(setTempUser(response.data));
            navigate("Verify");
        }).catch(error => {
            let errorDisplayed = false;
            if (error.response) {
                const errors = error.response.data?.error || [];
                if (errors.some((x: string) => x == "The phone has already been taken.")) {
                    dispatch(showSnackbar(t('registrationForm.phoneNumberTaken')));
                    errorDisplayed = true;
                }
                if (errors.some((x: string) => x == "The username has already been taken.")) {
                    dispatch(showSnackbar(t('registrationForm.usernameTaken')));
                    errorDisplayed = true;
                }
            }
            if (!errorDisplayed) {
                dispatch(showSnackbar(t('common.errorTryAgain')));
            }
        }); 
    };

    return (
        <>
            <Appbar>
                <Appbar.BackAction onPress={() => goBack() } />
                <Appbar.Content title={t('registrationForm.title')} />
            </Appbar>
            <View style={styles.container}>
                <TextInput 
                    autoCapitalize="none"
                    label={t('registrationForm.username')}
                    value={username}
                    onChangeText={text => setUsername(text)}
                    mode="outlined"
                />
                <HelperText type="error" visible={showValidation && errors.username.length > 0}>{errors.username}</HelperText>

                <View style={styles.fieldRow}>
                    <Menu visible={menuVisible} 
                        onDismiss={closeMenu} 
                        anchor={<Button style={styles.openMenuBtn} contentStyle={styles.openMenuBtnContent} mode="outlined" onPress={openMenu}>{selectedItemTitle}</Button>}>
                        {
                            availableOptions.map(({ title, value }) => <Menu.Item key={value} title={title} onPress={() => selectOption(value)} />)
                        }
                    </Menu>

                    <TextInput 
                        style={{ flex: 1, marginLeft: 16 }}
                        label={t('registrationForm.phoneNumber')}
                        value={phone}
                        onChangeText={text => setPhone(text)}
                        mode="outlined"
                        keyboardType="phone-pad"
                    />
                </View>
                <HelperText type="error" visible={showValidation && errors.phone.length > 0}>{errors.phone}</HelperText>
                <Button mode="contained" style={styles.submit} onPress={() => submit()}>{t('registrationForm.register')}</Button>
            </View>
        </>
    );
};

const styles = StyleSheet.create({
    container: {
        padding: 16
    },
    fieldRow: {
        flexDirection: "row",
    },
    openMenuBtn: {
        marginTop: 6
    },
    openMenuBtnContent: {
        height: 58,
    },
    submit: {
        marginTop: 24
    }
});

export default RegisterForm;