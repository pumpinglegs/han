import SInfo from 'react-native-sensitive-info';
import { User } from '../api/types/User';

const sInfoSettings = {
    sharedPreferencesName: "hangoverUserSharedPrefs",
    keychainService: "hangoverUserKeychain"
};

const STORAGE_KEYS = {
    ACCESS_TOKEN: 'access_token',
    USER: 'user'
    // ACCESS_TOKEN_EXPIRATION_DATE: 'access_token_expiration_date',
    // REFRESH_TOKEN: 'refresh_token'
}

export const getStoredUser = async () => {
    const accessToken = await SInfo.getItem(STORAGE_KEYS.ACCESS_TOKEN, sInfoSettings);
    const user = JSON.parse(await SInfo.getItem(STORAGE_KEYS.USER, sInfoSettings));
    // const accessTokenExpirationDate = await SInfo.getItem(STORAGE_KEYS.ACCESS_TOKEN_EXPIRATION_DATE, sInfoSettings);
    // const refreshToken = await SInfo.getItem(STORAGE_KEYS.REFRESH_TOKEN, sInfoSettings);
    return { accessToken, user };
};

export const setStoredUser = async (accessToken: string, user: User | null) => {
    await SInfo.setItem(STORAGE_KEYS.ACCESS_TOKEN, accessToken, sInfoSettings);
    await SInfo.setItem(STORAGE_KEYS.USER, JSON.stringify(user), sInfoSettings);

    // await SInfo.setItem(STORAGE_KEYS.ACCESS_TOKEN_EXPIRATION_DATE, accessTokenExpirationDate, sInfoSettings);
    // await SInfo.setItem(STORAGE_KEYS.REFRESH_TOKEN, refreshToken, sInfoSettings);
};

export const removeStoredUser = async () => {
    await setStoredUser("", null);
};