import { useNavigation } from "@react-navigation/native";
import React, { useContext, useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import { Appbar, Button, Divider, TextInput } from "react-native-paper";
import { useQueryCache } from "react-query";
import { useDispatch } from "react-redux";
import { showSnackbar } from "../appSlice";
import { LocalizationContext } from "../helpers/contexts";
import { signIn } from "./checkAuth";


const LoginForm: React.FC = () => {
    const { t } = useContext(LocalizationContext);
    const { navigate, goBack } = useNavigation();
    const dispatch = useDispatch();
    const queryCache = useQueryCache();

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const logIn = async () => {
        const result = await signIn(email, password);
        if (result == 'ok') {
            queryCache.invalidateQueries();
            navigate("Home");
        } else {
            dispatch(showSnackbar(t(result)));
        }
    };

    const openReset = () => {
        navigate("ResetPass");
    }

    return (
        <>
            <Appbar>
                <Appbar.BackAction onPress={() => goBack() } />
                <Appbar.Content title={t('loginForm.title')} />
            </Appbar>
            <View style={styles.container}>
                <TextInput 
                    style={{ marginBottom: 16 }}
                    label={t('loginForm.username')}
                    value={email}
                    onChangeText={text => setEmail(text)}
                    mode="outlined"
                />
                <TextInput 
                    style={{ marginBottom: 24 }}
                    label={t('loginForm.password')}
                    value={password}
                    onChangeText={text => setPassword(text)}
                    mode="outlined"
                    secureTextEntry={true} 
                />
                <Button mode="contained" onPress={logIn}>{t('loginForm.logIn')}</Button>
                <Divider style={{ height: 1, marginTop: 32, marginBottom: 16, backgroundColor: '#444' }} />
                <Button mode="text" onPress={openReset} uppercase={false}>{t('loginForm.forgotPassword')}</Button>
            </View>
        </>
    );
}


const styles = StyleSheet.create({
    container: {
        padding: 16
    }
});

export default LoginForm;