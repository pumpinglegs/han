import { setIsLoading, showSnackbar } from "../appSlice";
import store from "../store";
import { getStoredUser, removeStoredUser, setStoredUser } from "./tokenStorage";
import { setIsAuthenticated, setUser } from "./userSlice";
import axios from "../axios";
import { AuthResponse } from "../api/types/AuthResponse";


export const checkAuth = async () => {
    const userToken = await getUserToken();
    const user = await getUser();

    if (userToken != null && userToken != "") {
        axios.get(`/api/user/profile`).then((response) => {
            if (response.data?.active) {
                store.dispatch(setIsAuthenticated(true));
                store.dispatch(setUser(user));
            }
            store.dispatch(setIsLoading(false));
        });
    } else {
        store.dispatch(setIsLoading(false));
    }
};

const getUser = async () => {
    let user = await getStoredUser();
    return user.user;
}

export const getUserToken = async () => {
    let user = await getStoredUser();
    
    return user.accessToken;
}

// const refreshAndGetToken = async (refreshToken: string): Promise<string> => {
//     try {
//         const { accessToken, accessTokenExpirationDate } = await refresh(identityConfig, { refreshToken });
//         await setStoredUser(accessToken, accessTokenExpirationDate, refreshToken);
//         return accessToken;
//     } catch (error) {
//         console.log(error);
//     }
//     return "";
// };

export const signIn = async (username: string, password: string) => {
    try {
        const result = await axios.post("/api/user/authenticate", { username, password });
        
        if (result.status == 200) {
            handleSignInResponse(result.data)
            return 'ok';
        } else if (result.status == 404) {
            return 'loginForm.user_not_existing';
        } else if (result.status == 401) {
            return 'loginForm.user_not_existing';
        } else {
            return 'common.errorTryAgain';
        }
    } catch (error) {
        return 'common.errorTryAgain';
    } 
};

export const handleSignInResponse = async (result: any) => {
    await setStoredUser(result.token, result.user);
    store.dispatch(setUser(result.user));
    store.dispatch(setIsAuthenticated(true));
}
  
export const signOut = async () => {
    //const user = await getStoredUser();
    await removeStoredUser();
    store.dispatch(setIsAuthenticated(false));
    store.dispatch(setUser(null));
}