import React, { useContext } from "react";
import { Dimensions, Image, ImageBackground, StyleSheet, TouchableOpacity, View } from "react-native";
import { Button, Text, useTheme } from "react-native-paper";

import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from "../../navigation/RootNavigator";
import { useNavigation } from "@react-navigation/native";
import { theme } from "@storybook/react-native/dist/preview/components/Shared/theme";
import { LocalizationContext } from "../helpers/contexts";
import { useDispatch } from "react-redux";
import { setLangModalVisible } from "../translation/LanguageModalSlice";


const Login: React.FC = () => {
    const { t, locale } = useContext(LocalizationContext);
    const navigation = useNavigation();
    const { colors } = useTheme();
    const dispatch = useDispatch();

    const buttonStyle = {
        width: '50%',
        paddingVertical: 16,
        backgroundColor: colors.primary
    };

    const changeLanguage = () => {
        dispatch(setLangModalVisible(true));
    };

    const LangImage = () => {
        return (
            <>
                {locale === 'cg' ?
                    <Image style={styles.langImage} source={require('../assets/cg-flag.png')} />
                    :
                    <Image style={styles.langImage} source={require('../assets/en-flag.png')} />
                }
            </>
        )
    };

    return (
        <View style={{ flex: 1, justifyContent: "flex-end" }}>
            <View style={styles.bgContainer}>
                <Image style={styles.bgImage} source={require('../assets/welcome-bg.jpg')} />
            </View>
            <Image style={styles.logoImage} source={require('../assets/logo.png')} />
            <View style={styles.languageContainer}>
                <Text style={{ fontSize: 15, marginRight: 10 }}>{t('login.selectLanguage')}:</Text>
                <TouchableOpacity onPress={changeLanguage} delayPressIn={0} activeOpacity={.6}>
                    <LangImage />
                </TouchableOpacity>
            </View>
            <View style={{ flexDirection: 'row' }}>
                <Button onPress={() => navigation.navigate('LoginForm')} style={buttonStyle} theme={{ roundness: 0 }}><Text>{t('login.login')}</Text></Button>
                <View style={{
                    backgroundColor: '#4fc3f7',
                    width: 1
                }}></View>
                <Button onPress={() => navigation.navigate('RegisterForm')} style={buttonStyle} theme={{ roundness: 0 }}><Text>{t('login.registration')}</Text></Button>
            </View>
        </View>
    );
}



const styles = StyleSheet.create({
    bgContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: "#ccc"
    },
    bgImage: {
        width: Dimensions.get('screen').width,
        height: Dimensions.get('screen').height,
        resizeMode: "cover"
    },
    logoImage: {
        position: "absolute",
        top: 0,
        alignSelf: "center",
        width: "90%",
        height: "40%",
        resizeMode: "contain"
    },
    langImage: {
        width: 37,
        height: 37,
    },
    languageContainer: {
        flexDirection: 'row',
        position: 'absolute',
        justifyContent: 'flex-end',
        left: 0,
        bottom: 150,
        width: '100%',
        alignItems: 'center',
        paddingRight: 20
    }
});


export default Login;