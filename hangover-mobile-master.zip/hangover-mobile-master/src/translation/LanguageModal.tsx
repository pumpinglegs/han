import React, { useContext, useEffect, useRef, useState } from 'react';
import { Modal, StyleSheet, Text, TouchableWithoutFeedback, View } from 'react-native';
import { Button, RadioButton } from 'react-native-paper';
import { useDispatch, useSelector } from 'react-redux';
import { getLanguage, setLanguage } from '../auth/userSlice';
import { setStorageItem } from '../helpers/asyncStorage';
import { LocalizationContext } from '../helpers/contexts';
import { getLangModalVisible, setLangModalVisible } from './LanguageModalSlice';
import { showSnackbar } from '../appSlice';

const LanguageModal = ({language}:any) => {
  const { t, locale, setLocale } = useContext(LocalizationContext);
  const dispatch = useDispatch();
  const visible = useSelector(getLangModalVisible);
  const [selectedLanguage, setSelectedLanguage] = useState(language);

  const firstUpdate = useRef(true);

  const hideModal = () => {
    dispatch(setLangModalVisible(false));
  };

  const onSave = async () => {
    setStorageItem('APP_LANGUAGE', selectedLanguage);
    setLocale(selectedLanguage);
    dispatch(setLanguage(selectedLanguage));
    hideModal();
  };
 
  useEffect(() => {
    setSelectedLanguage(language);
    if (firstUpdate.current) {
      firstUpdate.current = false;
      return;
    }
  }, [language]);

  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={visible}
      statusBarTranslucent={true}
      onDismiss={hideModal}
      onRequestClose={hideModal}
    >
      <TouchableWithoutFeedback onPress={hideModal}>
        <View style={styles.overlay} />
      </TouchableWithoutFeedback>

      <View style={styles.container}>
        <View style={styles.modal}>
          <Text style={styles.title}>{t('languageModal.chooseYourLanguage')}</Text>
          <RadioButton.Group onValueChange={value => setSelectedLanguage(value)} value={selectedLanguage}>
            <RadioButton.Item label={t('languageModal.montenegrian')} value="cg" />
            <RadioButton.Item label={t('languageModal.english')} value="en" />
          </RadioButton.Group>
          <View style={styles.actions}>
            <View style={[styles.button, styles.outlinedButton]}>
              <Button mode="outlined" onPress={hideModal}>
                {t('common.cancel')}
              </Button>
            </View>
            <View style={styles.button}>
              <Button mode="contained" onPress={onSave}>
                {t('common.save')}
              </Button>
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(10,10,10,0.83)'
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modal: {
    backgroundColor: '#414141',
    width: '85%',
    alignSelf: 'center',
    padding: 15,
    borderRadius: 6
  },
  title: {
    fontFamily: 'Roboto-Medium',
    fontSize: 22,
    marginBottom: 25
  },
  actions: {
    flexDirection: 'row',
    marginTop: 30,
    maxWidth: 500,
    justifyContent: 'flex-end'
  },
  button: {
    width: '47%'
  },
  outlinedButton: {
    marginRight: '6%'
  },
});

export default LanguageModal;