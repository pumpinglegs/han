import { createSlice } from '@reduxjs/toolkit';

export const languageModalSlice = createSlice({
    name: 'languageModal',
    initialState: { visible: false },
    reducers: {
        setLangModalVisible: (state, action) => {
            state.visible = action.payload;
        }
    },
});

export const { setLangModalVisible } = languageModalSlice.actions;

export const getLangModalVisible = state => state.languageModal.visible;

export default languageModalSlice.reducer;
