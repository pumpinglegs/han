import {DrawerActions, useNavigation} from '@react-navigation/native';
import moment from 'moment';
import React, {useContext, useEffect, useState} from 'react';
import {FlatList, Image, StyleSheet, TouchableHighlight, useWindowDimensions, View} from 'react-native';
import {
  ActivityIndicator,
  Appbar,
  Avatar,
  Button,
  Card,
  IconButton,
  Paragraph,
  Text,
  Title,
  useTheme,
} from 'react-native-paper';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQueryCache } from 'react-query';
import { useDispatch } from 'react-redux';
import {getAllNotifications, updateReadAt} from '../api/notification';
import { setUnreadNotifications } from '../appSlice';
import {getImageUrl} from '../axios';
import StatusChip from '../common/StatusChip';
import UserProfileModal from '../common/UserProfileModal';
import { LocalizationContext } from '../helpers/contexts';

const NotificationsScreen = () => {
  const { t } = useContext(LocalizationContext);
  const navigation = useNavigation();
  const openDrawer = () => {
    navigation.dispatch(DrawerActions.openDrawer());
  };
  const dispatch = useDispatch();
  const {colors} = useTheme();
  const width = useWindowDimensions().width - 32;
  const insets = useSafeAreaInsets();

  const [isRefreshing, setIsRefreshing] = useState(false);

  const {
    status,
    data,
    isFetching,
    isFetchingMore,
    fetchMore,
    canFetchMore,
    refetch,
  } = getAllNotifications();

  const refresh = async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  };

  useEffect(() => {
    updateReadAt();
    dispatch(setUnreadNotifications(0));
  }, [])

  const resolvedData: any[] = [];

  data?.forEach((list) => resolvedData.push(...list));

  const renderAnnouncementItem = (item) => {

    const time = moment(item.created_at);
    
    const timeStr = time.isBefore(moment().startOf('day')) ?
      time.format("DD.MM.YYYY") :
      time.format("HH:mm");
      
    return (
      <View style={{padding: 16, borderColor: '#222', borderBottomWidth: 5, borderTopWidth: 5}}>
        { item.read_at == null && <View style={styles.unreadDot}></View> }
        { item.read_at == null && <Text style={{ color: colors.primary, marginBottom: 2, textTransform: 'uppercase', fontSize: 12 }}>{t('notifications.new')}</Text> }
        <Text style={{color: '#aaa'}}>{timeStr}</Text>
        <Text style={{fontSize: 18}}>{item.data.title}</Text>
        { item.data.image && (
          <Image source={{ uri: getImageUrl(item.data.image) }} height={250} width={width} style={{resizeMode: 'contain', height: 250, width: width, marginVertical: 12}} />
        ) }
        <Text style={{marginTop: 4}}>{item.data.body}</Text>
      </View>
    );
  };

  const renderItem = ({item}) => {
    if (item.data.notification_id == "announcement_created") {
      return renderAnnouncementItem(item);
    }

    const time = moment(item.created_at);
    
    const timeStr = time.isBefore(moment().startOf('day')) ?
      time.format("DD.MM.YYYY") :
      time.format("HH:mm");
      
    return (
      <View style={{padding: 16, borderColor: '#222', borderBottomWidth: 5, borderTopWidth: 5}}>
        { item.read_at == null && <View style={styles.unreadDot}></View> }
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <View>
            { item.read_at == null && <Text style={{ color: colors.primary, marginBottom: 2, textTransform: 'uppercase', fontSize: 12 }}>{t('notifications.new')}</Text> }
            <Text style={{color: '#aaa'}}>{timeStr}</Text>
          </View>
          <View>
            { item.data.user_id && item.data.user_full_name && (
              <UserProfileModal reservationid={item.data.reservation_id} userFullName={item.data.user_full_name} userImage={item.data.user_image} />
            ) }
            { item.data.status && <StatusChip status={item.data.status} /> }
          </View>
        </View>
        <Text style={{fontSize: 16, marginVertical: 4}}>{item.data.text}</Text>
        <View style={{ flexDirection: 'row', justifyContent: 'flex-start', paddingTop: 10 }}>
          <Button color="#aaa" mode="outlined" style={{marginRight: 8}} uppercase={false} onPress={() => {
            navigation.navigate("EventDetails", {id: item.data.event_id});
          }}>{t('notifications.openEvent')}</Button>
          
          { item.data.notification_id == 'reservation_processed' && (
            <Button color="#aaa" mode="outlined" uppercase={false} onPress={() => {
              navigation.navigate("MyReservations");
            }}>{t('notifications.openReservations')}</Button> 
          )}
          
          { (item.data.notification_id == 'reservation_requested' || item.data.notification_id == 'reservation_user_canceled') && (
            <Button color="#aaa" mode="outlined" uppercase={false} onPress={() => {
              navigation.navigate("Manager", {screen: 'ManageReservationsEvent', params: {placeId: item.data.place_id, eventId: item.data.event_id}});
            }}>{t('notifications.openReservations')}</Button> 
          )}
        </View>
      </View>
    );
  };

  return (
    <>
      <Appbar>
        <Appbar.Action icon="menu" onPress={() => openDrawer()} />
        <Appbar.Content title={t('notifications.title')} />
      </Appbar>
      <View style={{ paddingBottom: insets.bottom }}>
        {status == 'loading' ? (
          <ActivityIndicator />
        ) : status == 'error' ? (
          <Text>{t('common.unexpectedError')}</Text>
        ) : (
          <FlatList
            contentContainerStyle={styles.container}
            refreshing={isRefreshing}
            onRefresh={refresh}
            data={resolvedData}
            renderItem={renderItem}
            keyExtractor={(item) => item.id.toString()}
            onEndReached={() => fetchMore()}
            //ListFooterComponent={listFooter()}
            //ListHeaderComponent={listHeader()}
          />
        )}
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
  },
  unreadDot: {
    position: "absolute",
    left: 0,
    top: 0,
    width: 2,
    bottom: 0,
    backgroundColor: '#03a9f4'
  },
  itemUser: {
    flexDirection: 'row', 
    alignItems: 'center',
    borderColor: '#555',
    borderWidth: 1,
    borderRadius: 50
  },
  itemUsername: {
    padding: 6,
    paddingRight: 12
  }
});

export default NotificationsScreen;
