/**
 * @format
 */

import {AppRegistry, LogBox} from 'react-native';
import App from './App';
import {name as appName} from './app.json';

// https://github.com/facebook/react-native/issues/12981
LogBox.ignoreLogs([
    'Setting a timer'
]);

AppRegistry.registerComponent(appName, () => App);
