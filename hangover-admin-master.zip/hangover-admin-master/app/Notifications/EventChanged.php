<?php

namespace App\Notifications;

use App\User;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Notification;
use NotificationChannels\Fcm\FcmChannel;
use NotificationChannels\Fcm\FcmMessage;
use NotificationChannels\Fcm\Resources\AndroidConfig;
use NotificationChannels\Fcm\Resources\AndroidMessagePriority;
use NotificationChannels\Fcm\Resources\FcmOptions;

class EventChanged extends Notification implements ShouldQueue
{
    use Queueable;

    const ID = "event_changed";

    private $event;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($event)
    {
        $this->event = $event;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database', FcmChannel::class];
    }

    private function getText($notifiable) {
        $cg = $notifiable->lang == User::LANG_CG;
        $date = Carbon::parse($this->event->event_date)->format("d.m.Y");
        $text = $cg ?
            "Događaj " . $this->event->name . " je pomjeren za " . $date :
            "Event " . $this->event->name . " was moved to " . $date;

        return $text;
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'notification_id' => self::ID,
            'event_id' => (string)$this->event->id,
            'text' => $this->getText($notifiable)
        ];
    }

    public function toFcm($notifiable)
    { 
        return FcmMessage::create()
            ->setAndroid(
                AndroidConfig::create()
                    ->setPriority(AndroidMessagePriority::HIGH())
            )
            ->setData($this->toArray($notifiable))
            ->setNotification(
                \NotificationChannels\Fcm\Resources\Notification::create()
                    ->setTitle($this->getText($notifiable))
                    ->setImage(config('app.url') . '/storage/' . $this->event->image)
            );
    }
}
