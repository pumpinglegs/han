<?php

namespace App\Notifications;

use App\Event;
use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Notification;
use NotificationChannels\Fcm\FcmChannel;
use NotificationChannels\Fcm\FcmMessage;
use NotificationChannels\Fcm\Resources\AndroidConfig;
use NotificationChannels\Fcm\Resources\AndroidMessagePriority;

class ReservationUserCanceled extends Notification implements ShouldQueue
{
    use Queueable;

    const ID = "reservation_user_canceled";

    private $user;
    private $event;
    private $reservationId;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($user, $event, $reservationId)
    {
        $this->user = $user;
        $this->event = $event;
        $this->reservationId = $reservationId;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database', FcmChannel::class];
    }

    private function getText() {
        return "Korisnik " . $this->user->first_name . " " . $this->user->last_name . " je otkazao rezervaciju za događaj " . $this->event->name;
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'notification_id' => self::ID,
            'reservation_id' => (string)$this->reservationId,
            'event_id' => (string)$this->event->id,
            'place_id' => (string)$this->event->place_id,
            'user_id' => (string)$this->user->id,
            'user_image' => (string)$this->user->image,
            'user_full_name' => $this->user->first_name . " " . $this->user->last_name,
            'text' => $this->getText()
        ];
    }

    public function toFcm($notifiable)
    {
        return FcmMessage::create()
            ->setAndroid(
                AndroidConfig::create()
                    ->setPriority(AndroidMessagePriority::HIGH())
            )
            ->setData($this->toArray($notifiable))
            ->setNotification(
                \NotificationChannels\Fcm\Resources\Notification::create()
                    ->setTitle('Rezervacija otkazana')
                    ->setBody($this->getText())
                    ->setImage(config('app.url') . '/storage/' . $this->event->image)
            );
    }
}
