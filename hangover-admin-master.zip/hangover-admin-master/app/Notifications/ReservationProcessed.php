<?php

namespace App\Notifications;

use App\Event;
use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Notification;
use NotificationChannels\Fcm\FcmChannel;
use NotificationChannels\Fcm\FcmMessage;
use NotificationChannels\Fcm\Resources\AndroidConfig;
use NotificationChannels\Fcm\Resources\AndroidMessagePriority;

class ReservationProcessed extends Notification implements ShouldQueue
{
    use Queueable;

    const ID = "reservation_processed";

    private $reservation;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($reservation)
    {
        $this->reservation = $reservation;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database', FcmChannel::class];
    }

    private function getText($notifiable) {
        $cg = $notifiable->lang == User::LANG_CG;
        $text = $cg ?
            "Rezervacija za " . $this->reservation->event->name . " je " :
            "Your reservation for " . $this->reservation->event->name . " is ";

        switch ($this->reservation->status) {
            case 'approved':
                $text .= $cg ? 'potvrđena' : 'accepted';
                break;
            case 'pending':
                $text .= $cg ? 'na čekanju' : 'now pending';
                break;
            case 'canceled':
                $text .= $cg ? 'odbijena' : 'canceled';
                break;
        }

        return $text;
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'notification_id' => self::ID,
            'event_id' => (string)$this->reservation->event->id,
            'status' => (string)$this->reservation->status,
            'text' => $this->getText($notifiable)
        ];
    }

    public function toFcm($notifiable)
    {
        return FcmMessage::create()
            ->setAndroid(
                AndroidConfig::create()
                    ->setPriority(AndroidMessagePriority::HIGH())
            )
            ->setData($this->toArray($notifiable))
            ->setNotification(
                \NotificationChannels\Fcm\Resources\Notification::create()
                    ->setTitle($this->getText($notifiable))
                    ->setImage(config('app.url') . '/storage/' . $this->reservation->event->image)
            );
    }
}
