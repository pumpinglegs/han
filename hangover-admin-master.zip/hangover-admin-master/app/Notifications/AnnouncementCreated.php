<?php

namespace App\Notifications;

use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Notification;
use NotificationChannels\Fcm\FcmChannel;
use NotificationChannels\Fcm\FcmMessage;
use NotificationChannels\Fcm\Resources\AndroidConfig;
use NotificationChannels\Fcm\Resources\AndroidMessagePriority;

class AnnouncementCreated extends Notification implements ShouldQueue
{
    use Queueable;

    const ID = "announcement_created";

    private $announcement;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($announcement)
    {
        $this->announcement = $announcement;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        if ($this->announcement->is_push) {
            return ['database', FcmChannel::class];
        }

        return ['database'];
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        $cg = $notifiable->lang == User::LANG_CG;
        return [
            'notification_id' => self::ID,
            'title' => $this->getTitle($notifiable),
            'body' => $this->getBody($notifiable),
            'image' => $this->announcement->image,
            'created_at' => $this->announcement->created_at->format('d.m.Y')
        ];
    }

    private function getTitle($notifiable) {
        $cg = $notifiable->lang == User::LANG_CG;
        return $cg ? $this->announcement->title_cg : $this->announcement->title_en;
    }

    private function getBody($notifiable) {
        $cg = $notifiable->lang == User::LANG_CG;
        return $cg ? $this->announcement->body_cg : $this->announcement->body_en;
    }

    private function getImageUrl() {
        return config('app.url') . '/storage/' . $this->announcement->image;
    }

    public function toFcm($notifiable)
    {
        $notification = \NotificationChannels\Fcm\Resources\Notification::create()
            ->setTitle($this->getTitle($notifiable))
            ->setBody($this->getBody($notifiable));

        if ($this->announcement->image) {
            $notification->setImage($this->getImageUrl());
        }

        return FcmMessage::create()
            ->setAndroid(
                AndroidConfig::create()
                    ->setPriority(AndroidMessagePriority::HIGH())
            )
            ->setData($this->toArray($notifiable))
            ->setNotification($notification);
    }
}
