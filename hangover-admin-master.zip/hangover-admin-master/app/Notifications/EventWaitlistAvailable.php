<?php

namespace App\Notifications;

use App\Event;
use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Notification;
use NotificationChannels\Fcm\FcmChannel;
use NotificationChannels\Fcm\FcmMessage;
use NotificationChannels\Fcm\Resources\AndroidConfig;
use NotificationChannels\Fcm\Resources\AndroidMessagePriority;

class EventWaitlistAvailable extends Notification implements ShouldQueue
{
    use Queueable;

    const ID = "event_waitlist_available";

    private $event;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($event)
    {
        $this->event = $event;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database', FcmChannel::class];
    }

    private function getText($notifiable) {
        $cg = $notifiable->lang == User::LANG_CG;

        if ($cg) {
            return "Oslobođeno je mjesto na događaju " . $this->event->name;
        } else {
            return "Tables are now available for " . $this->event->name;
        }
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'notification_id' => self::ID,
            'event_id' => (string)$this->event->id,
            'place_id' => (string)$this->event->place_id,
            'text' => $this->getText($notifiable)
        ];
    }

    public function toFcm($notifiable)
    {
        return FcmMessage::create()
            ->setAndroid(
                AndroidConfig::create()
                    ->setPriority(AndroidMessagePriority::HIGH())
            )
            ->setData($this->toArray($notifiable))
            ->setNotification(
                \NotificationChannels\Fcm\Resources\Notification::create()
                    ->setTitle($notifiable->lang == User::LANG_CG ? "Mjesto dostupno" : "Tables available")
                    ->setBody($this->getText($notifiable))
                    ->setImage(config('app.url') . '/storage/' . $this->event->image)
            );
    }
}
