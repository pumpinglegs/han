<?php

namespace App\Notifications;

use App\Event;
use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Notification;
use NotificationChannels\Fcm\FcmChannel;
use NotificationChannels\Fcm\FcmMessage;
use NotificationChannels\Fcm\Resources\AndroidConfig;
use NotificationChannels\Fcm\Resources\AndroidMessagePriority;

class EventWaitListAdded extends Notification implements ShouldQueue
{
    use Queueable;

    const ID = "event_waitlist_aded";

    private $event;
    private $user;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($event, $user)
    {
        $this->event = $event;
        $this->user = $user;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database', FcmChannel::class];
    }

    private function getText($notifiable) {
        $cg = $notifiable->lang == User::LANG_CG;

        if ($cg) {
            return "Korisnik " . $this->user->first_name . " " . $this->user->last_name . " se prijavio na listu čekanja za događaj " . $this->event->name;
        } else {
            return "User " . $this->user->first_name . " " . $this->user->last_name . " signed on waitlist for event " . $this->event->name;
        }
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'notification_id' => self::ID,
            'event_id' => (string)$this->event->id,
            'place_id' => (string)$this->event->place_id,
            'text' => $this->getText($notifiable)
        ];
    }

    public function toFcm($notifiable)
    {
        return FcmMessage::create()
            ->setAndroid(
                AndroidConfig::create()
                    ->setPriority(AndroidMessagePriority::HIGH())
            )
            ->setData($this->toArray($notifiable))
            ->setNotification(
                \NotificationChannels\Fcm\Resources\Notification::create()
                    ->setTitle($notifiable->lang == User::LANG_CG ? "Lista čekanja" : "Waitlist")
                    ->setBody($this->getText($notifiable))
                    ->setImage(config('app.url') . '/storage/' . $this->event->image)
            );
    }
}
