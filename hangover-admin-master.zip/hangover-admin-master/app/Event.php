<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    protected $fillable = ['name', 'short_desc', 'image', 'event_date', 'status', "place_id", 'priority'];

    public function place()
    {
        return $this->belongsTo("App\\Place", "place_id");
    }
}
