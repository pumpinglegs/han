<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $fillable = [
        'key', 'name', 'description', 'value', 'field', 'active'
    ];

    static function getByKey($key) {
        return Setting::where('key', '=', $key)->get('value')->first()->value;
    }
}
