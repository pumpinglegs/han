<?php

namespace App;

use App\Notifications\AnnouncementCreated;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Notification;


class Announcement extends Model
{
    //
    protected $fillable = ['title_cg', 'title_en', 'image', 'body_cg', 'body_en', 'is_push'];

    protected static function booted()
    {
        static::created(function ($announcement) {
            try {
                $users = User::all();
                Notification::send($users, new AnnouncementCreated($announcement));
            } catch (\Exception $e) {
                //
            }
        });
    }
}
