<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Tymon\JWTAuth\Contracts\JWTSubject;

class User extends Authenticatable implements JWTSubject
{
    use Notifiable;

    const LANG_CG = 0;
    const LANG_EN = 1;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'username', 'email', 'password', 'first_name', 'last_name', 'phone', 'image', 'active', 'fcm_token', 'lang', 'ins_url', 'fb_url', 'has_viber', 'gender', 'date_of_birth', 'city_id'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token'
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'has_viber' => 'boolean'
    ];

    /**
     * Specifies the user's FCM token
     *
     * @return string|array
     */
    public function routeNotificationForFcm()
    {
        return $this->fcm_token;
    }

    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    public function getJWTCustomClaims()
    {
        return [];
    }


    public function reservations()
    {
        return $this->hasMany("App\\Reservation");
    }

    public function city()
    {
        return $this->belongsTo("App\\Location", "city_id");
    }

    public function places()
    {
        return $this->hasMany("App\\Place");
    }

    public function getManagers()
    {
        return $this::where('role', '=', 'manager')->get();
    }

    public function countReservationsForDate($date, $status)
    {
        $user_reservation = self::reservations()
            ->where("status", "=", $status)
            ->where("event_date", "=", $date);

        return $user_reservation->get()->count();
    }

    public function countReservationsForEvent($eventId, $status)
    {
        $user_reservation = self::reservations()
            ->where("status", "=", $status)
            ->where("event_id", "=", $eventId);

        return $user_reservation->get()->count();
    }
//
//    public function checkTodayReservation($date = false)
//    {
//        $user_reservation = self::reservations()
//            ->where("status", "=", "approved")
//            ->where("event_date", "=", $date);
//        //$sql = $user_reservation->toSql();
//        //$bindings = $user_reservation->getBindings();
//
//        $count = $user_reservation->get()->count();
//        if ($count > 0) return true;
//
//        return false;
//    }
//
//    //RETURN true if number of event is smaller than in settings
//    public function checkNumberOfEvents($date = false)
//    {
//        $user_reservation = self::reservations()
//            ->where("event_date", "=", $date)
//            ->where("status", "=", "pending");
//
//        $tmp = [];
//        foreach ($user_reservation->get() as $reservation) {
//            $event_id = $reservation->event_id;
//            $table_id = $reservation->table_id;
//
//            $tmp[$event_id] = isset($tmp[$event_id]) ? $tmp[$event_id] : array();
//            $tmp[$event_id]["tables"][$table_id] = "true";
//        }
//        return $tmp;
//    }

    public function setUsernameAttribute($value) {
        if ( empty($value) ) { // will check for empty string
            $this->attributes['username'] = NULL;
        } else {
            $this->attributes['username'] = $value;
        }
    }

    public function getFullnameAttribute()
    {
        return $this->first_name . ' ' . $this->last_name;
    }
//
//    public function setPasswordAttribute($value)
//    {
//        $this->attributes['password'] = bcrypt($value);
//    }

    public function hasRole($name)
    {
        return $this->role == $name;
    }
}
