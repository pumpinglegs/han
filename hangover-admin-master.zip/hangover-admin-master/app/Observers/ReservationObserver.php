<?php


namespace App\Observers;


use App\Reservation;

class ReservationObserver
{
    public function creating(Reservation $reservation) {
        $reservation->event_date = $reservation->event()->first()->event_date;
    }
}
