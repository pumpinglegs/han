<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Slider extends Model
{
    protected $fillable = [
        'image', 'title'
    ];

    public function place()
    {
        return $this->belongsTo("App\\Place", "place_id");
    }
}
