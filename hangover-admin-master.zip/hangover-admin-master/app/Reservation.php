<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Reservation extends Model
{
    protected $fillable = ["person_num", "status", "manager_id", "is_manual", "customer_name"];

    public function user()
    {
        return $this->belongsTo("App\\User", "user_id");
    }

    public function event()
    {
        return $this->belongsTo("App\\Event", "event_id");
    }

    public function manager()
    {
        return $this->belongsTo("App\\User", "manager_id");
    }

    public function table()
    {
        return $this->belongsTo("App\\Table", "table_id");
    }

}
