<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Table extends Model
{
    protected $fillable = ["name", "table_num", "status", "place_id"];

    public function place()
    {
        return $this->belongsTo("App\\Place", "place_id");
    }

    public function reservations()
    {
        return $this->hasMany("App\\Reservation", "table_id");
    }

    public function getFullnameAttribute()
    {
        return $this->table_num . ' - ' . $this->name;
    }
}
