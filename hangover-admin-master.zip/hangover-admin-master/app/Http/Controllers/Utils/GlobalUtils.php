<?php
/**
 * Created by PhpStorm.
 * User: Armin
 * Date: 6/10/2017
 * Time: 11:30 PM
 */

namespace App\Http\Controllers\Utils;


use App\Notification;
use App\Reservation;
use Illuminate\Support\Facades\Config;

class GlobalUtils
{

    public function cancelOtherUsers($event_id, $table_id, $user_id, $event_name = "")
    {
        $reservatiosns = Reservation::where("event_id", "=", $event_id)
            ->where("table_id", "=", $table_id)
            ->where("user_id", "!=", $user_id)
            ->where("status", "!=", "approved");
        $reservatiosns->update(['status' => 'canceled']);

        $users = $reservatiosns->pluck("user_id")->toArray();
        $text = "Zahtjev za {$event_name} je odbijen";
        //Notification::notifyUsers("Odgovor", $text, "danger", $users);

        return true;
    }

    public function getMaxBanPoint()
    {
        $maxBanpoints = intval(Config::get('settings.max_ban_points'));

        if ($maxBanpoints < 2) $maxBanpoints = 3;
        return $maxBanpoints;
    }

    public function scaleImage($width, $height, $max)
    {
        $ratio = $width / $height;
        if ($ratio > 1) {
            $width = $max;
            $height = $max / $ratio;
        } else {
            $width = $max * $ratio;
            $height = $max;
        }

        return array(intval($width), intval($height));
    }
}
