<?php


namespace App\Http\Controllers\Utils;


use App\Setting;
//use GuzzleHttp\Client;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Twilio\Rest\Client;

class SmsUtils
{
// Setting::where('key', '=', 'allowed_num_event')->get('value')->first()->value;
// https://3vdpqn.api.infobip.com

    private $sid = 'AC087883cb123798efc14b447c972b90b0';
    private $token = 'a866df3c541ceb0dd6d1ffb6320b8e6e';
    private $sender = "Hangover";


    /**
     * SmsUtils constructor.
     * @param string $url
     */
    public function __construct()
    {
        //$this->token = Setting::getByKey('sms_token');
        //$this->sender = Setting::getByKey('sender');
    }


    public function sendSMS($number, $text = "")
    {
        try {

            $client = new Client($this->sid, $this->token);
            $number = "+" . $number;
            $message = $client->messages->create(
                $number,
                [
                    'from' => $this->sender,
                    'body' => $text
                ]
            );
            return $message->errorCode == 0;

        } catch (\Exception $e) {
            Log::emergency("Error sending message!");
            report($e);
        }

        return false;
//        $client = new Client();
//        $response = false;
//
//        $number = "+" . $number;
//
//        $body = array("messages" =>
//            array(array(
//                "from" => $this->sender,
//                "destinations" => array(
//                    array(
//                        "to" => $number
//                    )
//                ),
//                "text" => $text
//            ))
//        );
//
//        $body = json_encode($body);
//
//        try {
//            $response = $client->post($this->url, [
//                'headers' => ['Authorization' => $this->token, 'Content-Type' => "application/json"],
//                'body' => $body,
//            ]);
//           Log::emergency("Status code for SMS sending: " . $response->getStatusCode());
//
//        } catch (\Exception $e) {
//            Log::emergency("Error sending message!");
//            report($e);
//        }
//        return $response;
    }
}
