<?php

namespace App\Http\Controllers\Api;

use App\Event;
use App\Http\Controllers\Utils\GlobalUtils;
use App\Place;
use App\Slider;
use Illuminate\Http\File;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Config;


class PlaceController extends Controller
{
    /**
     *
     * @SWG\Get(
     * tags={"Places"},
     * path="/place",
     * description="Returns all places from the system that the user has access to",
     * produces={"application/json"},
     * summary="List of places",
     * operationId="listPlaces",
     *
     *
     * @SWG\Parameter(
     * name="city_id",
     * in="query",
     * description="City id where place is located",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="page",
     * in="query",
     * description="Page of view",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="s",
     * in="query",
     * description="Search name of place",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function index(Request $request)
    {
        $search = $request->input('s');
        $city_id = intval($request->input('city_id'));
        $places = [];

        if ($city_id) {
            $places = Place::where("name", "LIKE", "%" . $search . "%")
				->where("status", "=", "published")
                ->where("city_id", "=", $city_id)
                ->orderBy('priority', 'desc')
                ->orderBy("id", "DESC")
                ->paginate(1000);
        }

        return response()->json($places);
    }

    /**
     * @SWG\Get(
     * tags={"Places"},
     * path="/place/{id}",
     * description="Returns one place for specific id",
     * produces={"application/json"},
     * summary="Place by id",
     * operationId="getPlace",
     *
     * @SWG\Parameter(
     * name="id",
     * in="path",
     * description="Id of place",
     * required=true,
     * type="integer"
     * ),
     *
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function place($id)
    {
        $user = auth('api')->user();

        $place = Place::findOrFail($id);
        return response()->json(Place::with(['events' => function ($q) use ($user, $place) {

            $date = date("Y-m-d");

            // Ova linija koda je ostavljala menadzerima da vide dogadjaje u njihov lokal koji su zavrseni u zadnja 2 dana
            //if (intval($user->id) == intval($place->user_id)) {
            //    $date = date('Y-m-d', mktime(0, 0, 0, date('m'), date('d') - 2, date('Y')));
            //}

            $q->where('event_date', '>=', $date);
            $q->orderBy("event_date", "ASC");
        }])->with("sliders")->findOrFail($id));
    }

    /**
     * @SWG\Post(
     * tags={"Places"},
     * path="/place/slider/add",
     * description="Add image for slider",
     * produces={"application/json"},
     * summary="Add image by id",
     * operationId="addImage",
     *
     * @SWG\Parameter(
     * name="id",
     * in="query",
     * description="Id of place",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="title",
     * in="query",
     * description="Title in slider",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="slide_image",
     * in="formData",
     * description="Place slider picture",
     * required=true,
     * type="file"
     * ),
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function addImage(Request $request)
    {
        $rules = array(
            //'slide_image' => Config::get('settings.image_validator'),
        );
        $user = auth('api')->user();

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json(["error" => $validator->errors()->all()], 500);
        }

        $data = $request->only('id', 'slide_image', 'title');

        $place = Place::findOrFail($data['id']);

        $link = "";
        $image = $request->file('slide_image');
        if ($image != null) {
            $link = time() . '.' . $image->getClientOriginalExtension();

            $img = Image::make($image->getRealPath())->fit(500, 400);

            if (Storage::disk('public')->exists($link)) {
                Storage::disk('public')->delete($link);
            }

            Storage::disk('public')->put($link, (string) $img->encode());
        }

        $slide = new Slider();
        $slide->title = $data['title'];
        $slide->image = $link;

        if ($place->sliders()->save($slide)) {
            return response()->json($slide);
        }
        return response()->json(["error" => "cant insert image profile"], 500);
    }

    /**
     * @SWG\Delete(
     * tags={"Places"},
     * path="/place/slider/remove",
     * description="Remove image from slider in place",
     * produces={"application/json"},
     * summary="Remove image",
     * operationId="addImage",
     *
     *
     * @SWG\Parameter(
     * name="image_id",
     * in="query",
     * description="Id of image",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=404, description="cant find image"),
     * @SWG\Response(response=500, description="something went wrong")
     * )
     */
    public function removeImage(Request $request)
    {
        $id = $request->get("image_id", 0);
        $image = Slider::with("place")->findOrFail($id);

        $user = auth('api')->user();
        if ($image->place->user_id != $user->id) {
            return response()->json(["error" => "you cant delete this image"], 500);
        }
        if ($image->delete()) {
            return response()->json(["status" => "ok"], 200);
        }

        return response()->json(["error" => "cant delete slide image"], 500);
    }

    /**
     * @SWG\post(
     * tags={"Places"},
     * path="/place/edit/{id}",
     * description="Remove image from slider in place",
     * produces={"application/json"},
     * summary="Remove image",
     * operationId="edit",
     *
     *
     * @SWG\Parameter(
     * name="id",
     * in="path",
     * description="Id of place",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="name",
     * in="query",
     * description="Place name",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="description",
     * in="query",
     * description="Place description",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="phone",
     * in="query",
     * description="Place phone",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="location",
     * in="query",
     * description="Map coordinate",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="address",
     * in="query",
     * description="Place address",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="site_url",
     * in="query",
     * description="Site url",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="fb_url",
     * in="query",
     * description="Facebook url",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="ins_url",
     * in="query",
     * description="instagram url",
     * required=false,
     * type="string"
     * ),
     *
     *
     * @SWG\Parameter(
     * name="logo_image",
     * in="formData",
     * description="Place logo",
     * required=false,
     * type="file"
     * ),
     *
     * @SWG\Parameter(
     * name="schema_place_image",
     * in="formData",
     * description="Place shcema image ",
     * required=false,
     * type="file"
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=404, description="cant find image"),
     * @SWG\Response(response=500, description="something went wrong")
     * )
     */
    public function editPlace(Request $request)
    {
        $rules = array(
            //'schema_place_image' => Config::get('settings.image_validator'),
            //'logo_image' => Config::get('settings.image_validator'),
            'name' => "min:2",
            'description' => "min:10",
            'phone' => "nullable|min:9",
            'site_url' => "nullable|url",
            'fb_url' => "nullable|url",
            'ins_url' => "nullable|url",
        );

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json(["error" => $validator->errors()->all()], 500);
        }

        $place = Place::findOrFail($request->id);

        $user = auth('api')->user();
        if ($place->user_id != $user->id) {
            return response()->json(["error" => "unauthorized"], 401);
        }


        $logo = $request->file('logo_image');
        if ($logo != null) {
            $logo_name = $place->id . '.png';
            $link = time() . '.' . $logo->getClientOriginalExtension();

            $image = Image::make($logo->getRealPath())->fit(100, 100);

            if (Storage::disk('public')->exists($link)) {
                Storage::disk('public')->delete($link);
            }

            Storage::disk('public')->put($link, (string) $image->encode());

            $request->request->set('logo', $link);
        }

        $schema = $request->file('schema_place_image');
        if ($schema != null) {
            $link = time() . '.' . $schema->getClientOriginalExtension();

            $global = new GlobalUtils();
            $img = Image::make($schema->getRealPath());

            $width = $img->width();
            $height = $img->height();

            list($width, $height) = $global->scaleImage($width, $height, 2048);

            $img->resize($width, $height);

            if (Storage::disk('public')->exists($link)) {
                Storage::disk('public')->delete($link);
            }

            Storage::disk('public')->put($link, (string) $img->encode());

            $request->request->set('schema_image', $link);
        }

        $fields = $request->only([
            'site_url',
            'fb_url',
            'ins_url',
        ]);

        $fields = array_merge($request->all(), $fields);

        if ($place->update($fields)) {
            return response()->json($place);
        }
        return response()->json(["error" => "something went wrong"], 500);
    }
}
