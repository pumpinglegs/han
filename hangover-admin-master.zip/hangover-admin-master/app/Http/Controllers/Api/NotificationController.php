<?php

namespace App\Http\Controllers\Api;


//use App\Notification;
//use App\NotifyStatus;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Tymon\JWTAuth\Facades\JWTAuth;

class NotificationController extends Controller
{


    /**
     *
     * @SWG\Get(
     * tags={"Notification"},
     * path="/notification",
     * description="Returns all notification from the system for user",
     * produces={"application/json"},
     * summary="List notification",
     * operationId="allNotify",
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function index()
    {
        $user = auth('api')->user();
        return response()->json($user->notifications()->paginate(10));
//
//        $user_id = $user->id;
//        $notifications = Notification::with(
//            ['notify' => function ($q) use ($user_id) {
//                //  $q->select('status', "id", "user_id");
//                $q->where('user_id', '=', $user_id);
//            }]
//        )
//            ->where(function ($query) use ($user_id) {
//                $query->where("to_whom", "=", 0);
//                $query->orwhere("to_whom", "=", $user_id);
//            })
//            ->where("created_at", ">", $user->created_at)
//            ->orderBy('id', 'DESC')
//            ->limit(60)
//            ->paginate(15);
//        //->toSql();
//        return response()->json($notifications);
    }

    public function updateReadAt()
    {
        $user = auth('api')->user();
        $user->unreadNotifications()->update(['read_at' => now()]);
        return response()->json(['result'=>'ok']);
    }

    public function count()
    {
        $user = auth('api')->user();
        $count = $user->unreadNotifications->count();
        return response()->json(['count' => $count]);
    }

    public function unreadAnnouncements()
    {
        $user = auth('api')->user();
        $announcements = $user->unreadNotifications()->where('type', 'App\Notifications\AnnouncementCreated')->get('data');
        return response()->json($announcements);
    }

    /**
     *
     * @SWG\Get(
     * tags={"Notification"},
     * path="/notification/count",
     * description="Returns number of unread notifications",
     * produces={"application/json"},
     * summary="List notification",
     * operationId="count",
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function notifyCount()
    {
        $count = 0;
        $user = JWTAuth::parseToken()->authenticate();
        $user_id = $user->id;
        $notifications = Notification::with(
            ['notify' => function ($q) use ($user_id) {
                $q->where('user_id', '=', $user_id);
            }]
        )
            ->where(function ($query) use ($user_id) {
                $query->where("to_whom", "=", 0);
                $query->orwhere("to_whom", "=", $user_id);
            })
            ->where("created_at", ">", $user->created_at)
            ->orderBy('id', 'DESC')
            ->limit(60)->get();

        foreach ($notifications as $n) {
            if (count($n->notify) > 0) {
                if ($n->notify->first()->status != "read") {
                    $count++;
                }
            } else {
                $count++;
            }
        }
        return response()->json(['count' => $count]);
    }

    /**
     *
     * @SWG\Post(
     * tags={"Notification"},
     * path="/notification/read/{id}",
     * description="Set status for this user that he read notification",
     * produces={"application/json"},
     * summary="List notification",
     * operationId="read",
     *
     * @SWG\Parameter(
     * name="id",
     * in="path",
     * description="Id of place",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="status",
     * in="query",
     * description="Status of reservation",
     * required=false,
     * type="string",
     * @SWG\Items(
     *    type="string",
     *    enum={"read", "not_read"},
     *    default="not_read"
     * ),
     *
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function readOne(Request $request)
    {
        $user = JWTAuth::parseToken()->authenticate();
        $user_id = $user->id;
        $notification = Notification::with(['notify' => function ($q) use ($user_id) {
            $q->where('user_id', '=', $user_id);
        }])->findOrFail($request->id);

        $notify = new NotifyStatus();

        if (count($notification->notify) > 0) {
            $notify = NotifyStatus::findOrFail($notification->notify);
        }

        $notify->user_id = $user_id;
        $notify->notification_id = $notification->id;
        $notify->status = $request->get("status", "read");

        if ($notify->save()) {
            return response()->json($notify);
        }

        return response()->json(['error' => 'something_went_wrong'], 500);
    }

    /**
     *
     * @SWG\Post(
     * tags={"Notification"},
     * path="/notification/read/all",
     * description="Set status for this user that he read notification",
     * produces={"application/json"},
     * summary="List notification",
     * operationId="readAll",
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function readAll()
    {
        $user = JWTAuth::parseToken()->authenticate();
        $user_id = $user->id;
        $notifications = Notification::with(
            ['notify' => function ($q) use ($user_id) {
                $q->where('user_id', '=', $user_id);
            }]
        )
            ->where(function ($query) use ($user_id) {
                $query->where("to_whom", "=", 0);
                $query->orwhere("to_whom", "=", $user_id);
            })
            ->where("created_at", ">", $user->created_at)
            ->orderBy('id', 'DESC')
            ->limit(60)->get();

        $data = array();
        foreach ($notifications as $notify) {
            $isRead = $notify->notify;

            if ($isRead->isEmpty()) {
                $data[] = array(
                    "user_id" => $user_id,
                    "notification_id" => $notify->id,
                    "status" => "read",
                    "created_at" => date("Y-m-d H:i:s"),
                    "updated_at" => date("Y-m-d H:i:s")
                );
            } else {
                $isRead = json_decode(json_encode($isRead), true);

                if (is_array($isRead)) {
                    foreach ($isRead as $not) {
                        $status = isset($not['status']) ? $not['status'] : "read";

                        if ($status != "read") {
                            $data[] = array(
                                "user_id" => $user_id,
                                "notification_id" => $notify->id,
                                "status" => "read",
                                "created_at" => date("Y-m-d H:i:s"),
                                "updated_at" => date("Y-m-d H:i:s")
                            );
                            NotifyStatus::destroy($not['id']);
                        }
                    }
                }
            }
        }
        return response()->json(NotifyStatus::insert($data));
    }

}
