<?php

namespace App\Http\Controllers\Api;

use App\Location;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class LocationController extends Controller
{


    /**
     *
     * @SWG\Get(
     * tags={"Locations"},
     * path="/location",
     * description="Returns all countries from the system that the user has access to",
     * produces={"application/json"},
     * summary="List countries",
     * operationId="listCountries",
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function index()
    {
        $countries = Location::whereNull("parent_id")->get();
        return response()->json($countries);
    }

    /**
     *
     * @SWG\Get(
     * tags={"Locations"},
     * path="/location/{country_id}",
     * description="Returns all cities from the system for specific country",
     * produces={"application/json"},
     * summary="List cities for country",
     * operationId="listCities",
     *
     * @SWG\Parameter(
     * name="country_id",
     * in="path",
     * description="Country id",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=404, description="Not found"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function cities($country_id)
    {
        $country = Location::findOrFail($country_id);
        $cities = Location::where("parent_id", $country->id)->get();
        return response()->json($cities);
    }

    /**
     *
     * @SWG\Get(
     * tags={"Locations"},
     * path="/location/search",
     * description="Returns all cities from the system for specific country that have name like in param",
     * produces={"application/json"},
     * summary="Search cities",
     * operationId="searchCities",
     *
     *
     * @SWG\Parameter(
     * name="s",
     * in="query",
     * description="Search name of city",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function search(Request $request)
    {
        if(!$request->has("s")) {
            return response()->json(["error"=>"No params"], 500);
        }
        $search = $request->input('s');
        return response()->json(Location::where("name", "LIKE", $search . "%")->get());
    }

}
