<?php

namespace App\Http\Controllers\Api;

use App\Event;
use App\EventWaitlist;
use App\Http\Controllers\Utils\GlobalUtils;
use App\Location;
use App\Notifications\EventChanged;
use App\Notifications\EventWaitlistAvailable;
use App\Notifications\ReservationProcessed;
use App\Notifications\EventWaitListAdded;
use App\Place;
use App\Table;
use App\Reservation;
use App\User;
use Carbon\Carbon;
//use Dompdf\Exception;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Config;

class EventController extends Controller
{
    /**
     * @SWG\Get(
     * tags={"Events"},
     * path="/event/{id}",
     * description="Returns one event for specific id",
     * produces={"application/json"},
     * summary="Event by id",
     * operationId="getEvent",
     *
     * @SWG\Parameter(
     * name="id",
     * in="path",
     * description="Id of event",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function index($id)
    {
        return response()->json(Event::with('place')->findOrFail($id));
    }

    /**
     * @SWG\Get(
     * tags={"Events"},
     * path="/event/next",
     * description="Returns events in next month",
     * produces={"application/json"},
     * summary="Next events",
     * operationId="events",
     *
     * @SWG\Parameter(
     * name="city_id",
     * in="query",
     * description="Id of city",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function events(Request $request)
    {
        $city_id = $request->get('city_id');
        $places = Place::where('city_id', $city_id)->pluck('id')->toArray();

        return response()->json(
            Event::whereIn('place_id', $places)
                ->with('place')
                ->where('event_date', '>=', date("Y-m-d"))
                ->orderBy('priority', 'desc')
                ->orderBy('event_date', 'asc')
                ->limit(60)
                ->paginate(100)
        );
    }


    /**
     * @SWG\Post(
     * tags={"Events"},
     * path="/event/add",
     * description="Add new event to place",
     * produces={"application/json"},
     * summary="Add Event",
     * operationId="add",
     *
     * @SWG\Parameter(
     * name="name",
     * in="query",
     * description="Event name",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="place_id",
     * in="query",
     * description="Place id",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="short_desc",
     * in="query",
     * description="Description of event",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="event_date",
     * in="query",
     * description="Event date format Y-m-d",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="event_image",
     * in="formData",
     * description="Event image",
     * required=false,
     * type="file"
     * ),
     *
     * @SWG\Response(response=201, description="successful operation"),
     * @SWG\Response(response=404, description="successful operation"),
     * @SWG\Response(response=500, description="no params or error")
     * )
     */

    public function addEvent(Request $request)
    {

        $rules = array(
            'name' => 'required',
            'short_desc' => 'required',
            //'event_image' => Config::get('settings.image_validator'),
            'event_date' => 'required|date|after:yesterday'
        );

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json(["error" => $validator->errors()->all()], 500);
        }

        $data = $request->only("place_id", "name", "short_desc", "event_date");
        $place = Place::findOrFail($data['place_id']);

        $link = "";
        $event_image = $request->file('event_image');
        if ($event_image != null) {
            $event_name = $place->id . "_" . time() . '.jpg';

            $link = time() . '.' . $event_image->getClientOriginalExtension();

            $path = public_path('uploads/place/');

            $global = new GlobalUtils();
            $img = Image::make($event_image->getRealPath());

            $width = $img->width();
            $height = $img->height();

            list($width, $height) = $global->scaleImage($width, $height, 800);

            $image = $img->resize($width, $height);

            Storage::disk('public')->put($link, (string) $image->encode());
        }

        $request->request->set('image', $link);
        $request->request->set('place_id', $place->id);

        $user = auth('api')->user();
        if ($place->user_id == $user->id) {

            $event = new Event();
            $event->name = $data['name'];
            $event->short_desc = $data['short_desc'];
            $event->event_date = $data['event_date'];
            $event->image = $link;
            $event->status = "active";

            $event->place()->associate($place);

            if ($event->save()) {
                return response()->json($event);
            }
        }

        return response()->json(["error" => "something went wrong"], 500);
    }

    /**
     * @SWG\Post(
     * tags={"Events"},
     * path="/event/edit/{id}",
     * description="Edit event",
     * produces={"application/json"},
     * summary="Edit event",
     * operationId="edit",
     *
     *
     * @SWG\Parameter(
     * name="id",
     * in="path",
     * description="Place id",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="name",
     * in="query",
     * description="Event name",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="short_desc",
     * in="query",
     * description="Description of event",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="event_date",
     * in="query",
     * description="Event date format Y-m-d",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="event_image",
     * in="formData",
     * description="Event image",
     * required=false,
     * type="file"
     * ),
     *
     * @SWG\Parameter(
     * name="status",
     * in="query",
     * description="Status of event",
     * required=false,
     * type="string",
     * @SWG\Items(
     *    type="string",
     *    enum={"active", "disabled"},
     *    default="active"
     * )
     * ),
     *
     * @SWG\Response(response=201, description="successful operation"),
     * @SWG\Response(response=404, description="successful operation"),
     * @SWG\Response(response=500, description="no params or error")
     * )
     */
    //TODO: FIX PROMJENA DATUMA
    public function editEvent(Request $request)
    {
        $rules = array(
            //'event_image' => Config::get('settings.image_validator'),
            'event_date' => 'date|after:now',
        );

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json(["error" => $validator->errors()->all()], 500);
        }

        $event = Event::with("place")->findOrFail($request->id);

        $event_image = $request->file('event_image');
        if ($event_image != null) {
            $link = time() . '.' . $event_image->getClientOriginalExtension();

            $global = new GlobalUtils();
            $img = Image::make($event_image->getRealPath());

            $width = $img->width();
            $height = $img->height();

            list($width, $height) = $global->scaleImage($width, $height, 800);

            $image = $img->resize($width, $height);

            Storage::disk('public')->put($link, (string) $image->encode());
            $request->request->set('image', $link);
        }


        $eventDate = Carbon::parse($event->event_date);
        $newDate = Carbon::parse($request->post('event_date'));
        $isDateChange = $newDate->diffInDays($eventDate) > 0;

        $user = auth('api')->user();

        if ($event->place->user_id == $user->id) {

            if ($event->update($request->all())) {

                /** Ovdje ubaciti da sve sa tog eventa stavi na pending */

                if ($isDateChange) {
                    $user_to_notify = Reservation::where("event_id", "=", $event->id)->pluck('user_id')->toArray();
                    $user_to_notify = array_unique($user_to_notify);

                    $users = User::whereIn("id", $user_to_notify)->get();

                    Notification::send($users, new EventChanged($event));
                }

                return response()->json($event);
            }
        }

        return response()->json(["error" => "something went wrong"], 500);
    }


    /**
     * @SWG\Delete(
     * tags={"Events"},
     * path="/event/delete/{id}",
     * description="Delete event",
     * produces={"application/json"},
     * summary="Delete event",
     * operationId="delete",
     *
     *
     * @SWG\Parameter(
     * name="id",
     * in="path",
     * description="Place id",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Response(response=201, description="successful operation"),
     * @SWG\Response(response=404, description="successful operation"),
     * @SWG\Response(response=500, description="no params or error")
     * )
     */
    public function deleteEvent(Request $request)
    {

        $event = Event::with("place")->findOrFail($request->id);
        $user = JWTAuth::parseToken()->authenticate();

        if ($event->place->user_id == $user->id) {
            if ($event->delete()) return response()->json(["status" => "ok"]);
        } else {
            return response()->json(["error" => "unauthorized"], 500);
        }

        return response()->json(["error" => "something went wrong"], 500);
    }

    // Za administratora da vidi listu cekanja
    public function manageWaitlist(Request $request) {
        $user = auth('api')->user();
        $eventId = $request->post('event_id');
        $event = Event::findOrFail($eventId);

        $waitlist = EventWaitlist::where([
            ['event_id', '=', $eventId],
        ])->with(['user', 'table', 'event'])->get();

        return response()->json($waitlist);
    }

    public function waitlist(Request $request)
    {
        $user = auth('api')->user();
        $eventId = $request->post('id');
        $event = Event::with('place')->findOrFail($eventId);
        
        $tableId = $request->post('table_id');
        $table = null;
        if (!empty($tableId)){
            $table = Table::find($tableId);

            $notNullTableWaitlist = EventWaitlist::where([
                ['event_id', '=', $eventId],
                ['user_id', '=', $user->id]
            ])->whereNotNull('table_id')->get()->count();
            if ($notNullTableWaitlist >= 3){
                return response()->json(['error' => 'user_is_already_on_waitlist_for_event_and_table'], 500);
            }
        } else {
            $nullTableWaitlist = EventWaitlist::where([
                ['event_id', '=', $eventId],
                ['user_id', '=', $user->id]
            ])->whereNull('table_id')->get()->count();
            if ($nullTableWaitlist >= 1){
                return response()->json(['error' => 'user_is_already_on_waitlist_for_event_and_table'], 500);
            }
        }

        // check existing waitlist
        $waitListExistsExists = EventWaitlist::where([
            ['event_id', '=', $eventId],
            ['table_id', '=', $tableId],
            ['user_id', '=', $user->id]
        ])->first();
        if ($waitListExistsExists) {
            return response()->json(['error' => 'user_is_already_on_waitlist_for_event_and_table'], 500);
        }

        $model = new EventWaitlist();
        $model->user_id = $user->getAuthIdentifier();
        $model->event_id = $eventId;
        if ($table) {
            $model->table_id = $tableId;
        }

        $manager = User::findOrFail($event->place->user_id);

        if ($model->save()){
            //todo: send notification to manager
            $manager->notify(new EventWaitListAdded($event, $user));
            // Notification::send($manager, new EventWaitListAdded($event));

            return response()->json(['success' => true]);
        } else {
            return response()->json(['error' => 'error_saving'], 500);
        }
    }

    public function approveFromWaitlist(Request $request){
        $manager = auth('api')->user();
        $eventId = $request->post('event_id');
        $tableId = $request->post('table_id');
        $userId = $request->post('user_id');

        $event = Event::with("place")->findOrFail($eventId);
        $user = User::findOrFail($userId);
        $place = Place::findOrFail($event->place_id);
        // TODO:
        // Pronaci sve stolove za taj place dje je event
        $allTablesQuery = Table::where([
            ['place_id', '=', $place->id]
        ])->get('id');
        $allTables = array();
        foreach($allTablesQuery as $table1){
            $allTables[] = $table1->id;
        };
        sort($allTables);

        // Pronaci sve stolove aktivnih rezervacija za taj place za taj event
        $approvedTablesQuery = Reservation::where([
            ['event_id', '=', $eventId],
            ['status', '=', 'approved']
        ])->get('table_id');
        $approvedTables = array();
        foreach($approvedTablesQuery as $table2){
            $approvedTables[] = $table2->table_id;
        };
        sort($approvedTables);

        // Ako su svi stolovi zauzeti vrati error 
        if ($allTables == $approvedTables){
            return response()->json(['error' => 'no_free_tables'], 500);
        };

        // Slobodni stolovi
        $freeTables = array_values(array_diff($allTables, $approvedTables));

        if (!empty($tableId)){
            $table = Table::findOrFail($tableId);

            // da li ovaj user vec ima rezervaciju za ovaj event
            $userReservationExists = Reservation::where([
                ['event_id', '=', $eventId],
                ['user_id', '=', $userId],
                ['status', '=', 'approved']
            ])->first();

            if ($userReservationExists){
                return response()->json(['error' => 'reservation_already_exist_for_this_user_this_event'], 500);
            }

            // da li vec postoji prihvacena rezervacija za ovaj sto za ovaj event
            $reservationExists = Reservation::where([
                ['event_id', '=', $eventId],
                ['table_id', '=', $tableId]
            ])->first();

            if ($reservationExists){
                if ($reservationExists->status == 'approved'){
                    return response()->json(['error' => 'reservation_already_exist_for_this_table_this_event'], 500);
                } else {

                    if ($reservationExists->user_id == $userId){
                        $reservationExists->status = 'approved';
                        if ($reservationExists->save()) {
                            $user->notify(new ReservationProcessed($reservationExists));
                        }
                        return response()->json($reservationExists);
                    } else {
                        // Kreiraj novu i odobri
                        $res = new Reservation();
                        $res->person_num = 0;
                        $res->event_date = $event->event_date;
                        $res->is_manual = 1;
                        $res->status = 'approved';
                        $res->customer_name = NULL;
                        $res->user()->associate($user);
                        $res->event()->associate($event);
                        $res->table()->associate($table);

                        $manager = User::findOrFail($event->place->user_id);
                        $res->manager()->associate($manager);

                        if ($res->save()) {
                            // todo: delete user request from waitlist if exists
                            $waitlist = EventWaitlist::where([
                                ['event_id', '=', $event->id],
                                ['user_id', '=', $user->id],
                                ['table_id', '=', $tableId]
                            ])->first();
                            if ($waitlist){
                                $waitlist->delete();
                            }
                            $user->notify(new ReservationProcessed($res));

                            return response()->json($res);
                            // return response()->json(['success' => true]);
                        } else {
                            return response()->json(['error' => 'error'], 500);
                        }
                    }    
                }                
            } else {
                $res = new Reservation();
                $res->person_num = 0;
                $res->event_date = $event->event_date;
                $res->is_manual = 1;
                $res->status = 'approved';
                $res->customer_name = NULL;
                $res->user()->associate($user);
                $res->event()->associate($event);
                $res->table()->associate($table);

                $manager = User::findOrFail($event->place->user_id);
                $res->manager()->associate($manager);

                if ($res->save()) {
                    // todo: delete user request from waitlist if exists
                    $waitlist = EventWaitlist::where([
                        ['event_id', '=', $event->id],
                        ['user_id', '=', $user->id],
                        ['table_id', '=', $tableId]
                    ])->first();
                    if ($waitlist){
                        $waitlist->delete();
                    }
                    $user->notify(new ReservationProcessed($res));

                    return response()->json($res);
                    // return response()->json(['success' => true]);
                } else {
                    return response()->json(['error' => 'error'], 500);
                }
            }
        } else {
            $newTable = Table::findOrFail($freeTables[0]);

            $res = new Reservation();
            $res->person_num = 0;
            $res->event_date = $event->event_date;
            $res->is_manual = 1;
            $res->status = 'approved';
            $res->customer_name = NULL;
            $res->user()->associate($user);
            $res->event()->associate($event);
            $res->table()->associate($newTable);

            $manager = User::findOrFail($event->place->user_id);
            $res->manager()->associate($manager);

            if ($res->save()) {
                // todo: delete user request from waitlist if exists
                $waitlist = EventWaitlist::where([
                    ['event_id', '=', $event->id],
                    ['user_id', '=', $user->id],
                    ['table_id', '=', $tableId]
                ])->first();
                if ($waitlist){
                    $waitlist->delete();
                }
                $user->notify(new ReservationProcessed($res));

                return response()->json($res);
                // return response()->json(['success' => true]);
            } else {
                return response()->json(['error' => 'error'], 500);
            }
        } 
    }

    public function isOnWaitlist(Request $request)
    {
        $user = auth('api')->user();
        $eventId = $request->id;

        $waitlist = EventWaitlist::where([
            ['event_id', '=', $eventId],
            ['user_id', '=', $user->getAuthIdentifier()]
        ])->get();

        return response()->json($waitlist);
    }
}
