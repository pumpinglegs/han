<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Utils\GlobalUtils;
use App\Setting;
use App\User;
use App\UserReport;
use App\Verification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Http\Controllers\Utils\SmsUtils;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{

    /**
     *
     * @SWG\Post(
     * tags={"User"},
     * path="/user/authenticate",
     * description="Returns all pets from the system that the user has access to",
     * produces={"application/json"},
     * summary="List customer rates",
     * operationId="authenticate",
     *
     * @SWG\Parameter(
     * name="username",
     * in="query",
     * description="Email of user",
     * description="User Email",
     * required=true,
     * type="string"
     * ),
     *
     *  @SWG\Parameter(
     * name="password",
     * in="query",
     * description="Password of user",
     * description="User password",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=401, description="banned user credentials"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function authenticate(Request $request)
    {
        $credentials = $request->only('username', 'password');

        $replacedPhone = intval(str_replace("+", "", $credentials['username']));
        if ($replacedPhone) {
            $userWithPhone = User::where('phone', 'LIKE', '%'.$replacedPhone.'%')->first();
            if ($userWithPhone) {
                $credentials['username'] = $userWithPhone->username;
            }
        }

        if (!$token = auth('api')->attempt($credentials)) {
            return response()->json(['error' => 'invalid_credentials'], 404);
        }

        $user = auth('api')->user();

        if ($user->active) {
            return response()->json(array_merge(['user' => $user], compact('token')));
        }

        return response()->json(['error' => 'user_is_not_activated'], 401);
    }

    /**
     * @SWG\Get(
     * tags={"User"},
     * path="/user/profile",
     * description="Returns current user",
     * produces={"application/json"},
     * summary="Returns current user",
     * operationId="profile",
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="no params or error")
     * )
     */
    public function profile()
    {
        $user = auth('api')->user();
        $new = User::with("places")->findOrFail($user->id);
        return response()->json($new);
    }

    public function deleteProfile()
    {
        $user = auth('api')->user();
        $user->active = 0;
        return response()->json(['status' => 1]);
    }

    /**
     * @SWG\Get(
     * tags={"User"},
     * path="/user/logout",
     * description="Logout from system",
     * produces={"application/json"},
     * summary="Logout from system",
     * operationId="logout",
     *
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="no params or error")
     * )
     */
    public function logout()
    {
        auth('api')->logout();

        return response()->json(['status' => 1]);
    }

    /**
     * @SWG\Post(
     * tags={"User"},
     * path="/user/register",
     * description="register on system",
     * produces={"application/json"},
     * summary="register on system",
     * operationId="register",
     *
     * @SWG\Parameter(
     * name="username",
     * in="query",
     * description="Username",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="phone",
     * in="query",
     * description="Phone number without +",
     * required=true,
     * type="string"
     * ),
     * @SWG\Response(response=201, description="successful operation"),
     * @SWG\Response(response=500, description="no params or error")
     * )
     */
    public function register(Request $request)
    {
        $pin = mt_rand(100000, 999999);

        $rules = array(
            'phone' => 'required|unique:users',
            'username' => 'required|unique:users|max:60'
        );

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json(["error" => $validator->errors()->all()], 500);
        }

        $request->request->add([
            'password' => '1234',
            'fcm_token' => '',
            'lang' => User::LANG_CG,
            'has_viber' => false,
            'city_id' => 1
        ]);

        DB::beginTransaction();
        $user = User::create($request->all());

        if (!$user) {
            DB::rollback();
            return response()->json(["error" => "User creation error"], 500);
        }

        $verification = new Verification();
        $verification->user_id = $user->id;
        $verification->keycode = $pin;

        if ($verification->save()) {
            DB::commit();

            // TODO: Set up SMS service
            $sms = new SmsUtils();
            $text = str_replace("{{key}}", $pin, Setting::getByKey('sms_body'));
            $sms->sendSMS($user->phone, $text);

            return response()->json($user, 200);
        }
        DB::rollback();
        return response()->json(["error" => "Database Error"], 500);
    }


    /**
     * @SWG\Post(
     * tags={"User"},
     * path="/user/sendagain",
     * description="Send SMS again to user ",
     * produces={"application/json"},
     * summary="Send SMS again",
     * operationId="sendagain",
     *
     * @SWG\Parameter(
     * name="user_id",
     * in="query",
     * description="User id",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Response(response=201, description="successful operation"),
     * @SWG\Response(response=500, description="no params or error")
     * )
     */
    public function sendAgain(Request $request)
    {
        $user_id = $request->get("user_id");

        $user = User::findOrFail($user_id);
        $verification = Verification::where("user_id", "=", $user_id)->orderBy("created_at", "DESC")->first();

        $sms = new SmsUtils();
        $text = str_replace("{{key}}", $verification->keycode, Setting::getByKey('sms_body'));

        $result = $sms->sendSMS($user->phone, $text );

        return response()->json(["status" => "ok"], 200);
    }

    /**
     * @SWG\Post(
     * tags={"User"},
     * path="/user/verify",
     * description="verify user with sms code",
     * produces={"application/json"},
     * summary="verify user",
     * operationId="verify",
     *
     * @SWG\Parameter(
     * name="key_code",
     * in="query",
     * description="Key code from sms message",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="user_id",
     * in="query",
     * description="User id for verification",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="password",
     * in="query",
     * description="Password for this user",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="repeat_password",
     * in="query",
     * description="Password repeat for this user",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Response(response=201, description="successful operation"),
     * @SWG\Response(response=500, description="no params or error")
     * )
     */
    public function verifyAccount(Request $request)
    {
        $user_id = $request->get('user_id');
        $key = $request->get('key_code');

        $password = $request->get('password');
        $rpassword = $request->get('repeat_password');

        if ($password != $rpassword) {
            return response()->json(["error" => "Password must be same"], 500);
        }

        $user = User::findOrFail($user_id);
        if ($user) {
            $verification = Verification::where('user_id', $user->id)->orderBy("created_at", "DESC")->get()->first();

            if ($verification) {
                if ($verification->keycode == $key) {
                    $user->active = 1;
                    $user->password = Hash::make($password);
                    $user->save();

                    $credentials = array("username" => $user->username, "password" => $password);

                    try {
                        if (!$token = auth('api')->attempt($credentials)) {
                            return response()->json(['error' => 'invalid_credentials'], 404);
                        }
                    } catch (JWTException $e) {
                        return response()->json(['error' => 'could_not_create_token'], 500);
                    }

                    $user = auth('api')->user();
                    return response()->json(array_merge(['user' => $user], compact('token')));

                }
            } else {
                return response()->json(["error" => "Can't find key"], 500);
            }
        }

        return response()->json(["error" => "Incorrect key"], 500);
    }

    /**
     * @SWG\Post(
     * tags={"User"},
     * path="/user/update",
     * description="Update user profil",
     * produces={"application/json"},
     * summary="Update user",
     * operationId="update",
     *
     * @SWG\Parameter(
     * name="first_name",
     * in="query",
     * description="User first name",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="last_name",
     * in="query",
     * description="User last name",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="email",
     * in="query",
     * description="User email",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="profile_image",
     * in="formData",
     * description="User profile picture",
     * required=false,
     * type="file"
     * ),
     *
     * @SWG\Response(response=201, description="successful operation"),
     * @SWG\Response(response=500, description="no params or error")
     * )
     */
    public function updateProfil(Request $request)
    {
        $rules = array(
            'first_name' => 'required',
            'last_name' => 'required',

            //'profile_image' => Config::get('settings.image_validator'),
        );

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json(["error" => $validator->errors()->all()], 500);
        }

        $user = auth('api')->user();

        $profile_image = $request->file('profile_image');
        if ($profile_image != null) {
            $link = time() . '.' . $profile_image->getClientOriginalExtension();

            //$profile_name = $user->id . '.png';
            //$link = "/uploads/profile/" . $profile_name;
            //$path = public_path('uploads/profile/');
            //Image::make($profile_image->getRealPath())->fit(200, 200)->save($path . $profile_name);

            $img = Image::make($profile_image->getRealPath())->fit(200, 200);

            if (Storage::disk('public')->exists($link)) {
                Storage::disk('public')->delete($link);
            }

            Storage::disk('public')->put($link, (string) $img->encode());

            $request->merge(array("image" => $link));
        }

        // Transform bool to int value
        $request->merge([
            'has_viber' => $request->boolean('has_viber') ? 1 : 0
        ]);

        if ($user->update($request->all())) {
            return response()->json($user);
        }
        return response()->json(["error" => "cant update profile"], 500);
    }


    /**
     * @SWG\Post(
     * tags={"User"},
     * path="/user/resetPassword",
     * description="Reset password to user with number",
     * produces={"application/json"},
     * summary="Restart password",
     * operationId="reserPassword",
     *
     * @SWG\Parameter(
     * name="phone",
     * in="query",
     * description="User phone",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Response(response=201, description="successful operation"),
     * @SWG\Response(response=500, description="no params or error")
     * )
     */
    public function resetPassword(Request $request)
    {
        $phone = $request->get("phone", false);

        $user = User::where("username", "=", $phone)->first();

        if (!$user) {
            $replacedPhone = intval(str_replace("+", "", $phone));
            $userWithPhone = User::where('phone', 'LIKE', '%'.$replacedPhone.'%')->first();
            if ($userWithPhone) {
                $user = $userWithPhone;
            }
        }

        if ($user) {
            $pin = mt_rand(100000, 999999);

            $verification = new Verification();
            $verification->user_id = $user->id;
            $verification->keycode = $pin;

            if ($verification->save()) {
                $sms = new SmsUtils();
                $text = str_replace("{{key}}", $pin, Setting::getByKey('sms_body'));
                $sms->sendSMS($user->phone, $text);
                return response()->json($user, 200);
            }
        }
        return response()->json(["error" => "Can't find user"], 500);
    }

    /**
     * @SWG\Post(
     * tags={"User"},
     * path="/user/confirmPassword",
     * description="Confirm user password reset",
     * produces={"application/json"},
     * summary="Confirm password reset",
     * operationId="passwordReset",
     *
     * @SWG\Parameter(
     * name="key_code",
     * in="query",
     * description="Key code from sms message",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="user_id",
     * in="query",
     * description="User id for verification",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="password",
     * in="query",
     * description="Password for this user",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="repeat_password",
     * in="query",
     * description="Password repeat for this user",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Response(response=201, description="successful operation"),
     * @SWG\Response(response=500, description="no params or error")
     * )
     */
    public function confirmPassword(Request $request)
    {
        $user_id = $request->get('user_id');
        $key = $request->get('key_code');

        $password = $request->get('password');
        $rpassword = $request->get('repeat_password');

        if ($password != $rpassword) {
            return response()->json(["error" => "Password must be same"], 500);
        }

        $user = User::findOrFail($user_id);
        if ($user) {
            $verification = Verification::where('user_id', $user->id)->orderBy("created_at", "DESC")->get()->first();

            if ($verification) {
                if ($verification->keycode == $key) {
                    $user->password = Hash::make($password);
                    $user->save();

                    $credentials = array("username" => $user->username, "password" => $password);

                    try {
                        if (!$token = auth('api')->attempt($credentials)) {
                            return response()->json(['error' => 'invalid_credentials'], 404);
                        }
                    } catch (JWTException $e) {
                        return response()->json(['error' => 'could_not_create_token'], 500);
                    }

                    $user = auth('api')->user();
                    return response()->json(array_merge(['user' => $user], compact('token')));
                }
            } else {
                return response()->json(["error" => "Can't find key"], 500);
            }
        }

        return response()->json(["error" => "Incorrect key"], 500);
    }


    /**
     * @SWG\Post(
     * tags={"User"},
     * path="/user/addBan",
     * description="Add ban point to user with id",
     * produces={"application/json"},
     * summary="Add ban point",
     * operationId="banPoint",
     *
     * @SWG\Parameter(
     * name="user_id",
     * in="query",
     * description="User phone",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Response(response=201, description="successful operation"),
     * @SWG\Response(response=500, description="no params or error")
     * )
     */
    public function addBanPoint(Request $request)
    {
        $user_id = $request->get("user_id", 0);
        $user = User::findOrFail($user_id);

        $globals = new GlobalUtils();
        $maxBanpoints = $globals->getMaxBanPoint();
        $user->ban_count = intval($user->ban_count) + 1;

        if ($maxBanpoints <= $user->ban_count) $user->active = 0;

        if ($user->save()) {
            return response()->json($user, 200);
        }
        return response()->json(["error" => "Can't update point for ban"], 500);
    }

    public function updateFcmToken(Request $request)
    {
        $user = auth('api')->user();
        $user->fcm_token = $request->post('token');
        $user->save();
    }

    public function report(Request $request)
    {
        $data = $request->only('userId', 'description');

        $user = auth('api')->user();
        $report = new UserReport();
        $report->user_id = $request['userId'];
        $report->manager_id = $user->id;
        $report->description = $data['description'];
        $report->save();

        //todo: Trebalo bi nekako obavjestiti administratora/administratorE da ima nova prijava.
        // A onda admin da kontaktira korisnika da mu kaze banovacu te ako nastavis tako da koristis aplikaciju.
        // Notify admin by email

        return response()->json(["success" => true]);
    }
}
