<?php

namespace App\Http\Controllers\Api;

use App\Event;
use App\EventWaitlist;
use App\Http\Controllers\Utils\GlobalUtils;
use App\Notifications\EventWaitlistAvailable;
use App\Notifications\ReservationProcessed;
use App\Notifications\ReservationRequested;
use App\Notifications\ReservationUserCanceled;
use App\Place;
use App\Setting;
use App\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Reservation;
use App\Table;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Notification;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Config;


class ReservationController extends Controller
{
    /**
     *
     * @SWG\Get(
     * tags={"Reservation"},
     * path="/reservation",
     * description="Returns all reservation for user",
     * produces={"application/json"},
     * summary="List of reservation",
     * operationId="listReservation",
     *
     *
     * @SWG\Parameter(
     * name="page",
     * in="query",
     * description="Page of view",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function index(Request $request)
    {
        $user = auth('api')->user();
        $reservations = [];
        if ($user) {
            $reservations = Reservation::with("event", "table", "user")
                ->where([
                    ["user_id", "=", $user->id],
                    ["is_manual", "=", false]
                ])
                ->orderBy('created_at', 'desc')
                ->paginate(10);
        }
        return response()->json($reservations);
    }

    /**
     *
     * @SWG\Get(
     * tags={"Reservation"},
     * path="/reservation/manager",
     * description="Returns all reservation for manager",
     * produces={"application/json"},
     * summary="List of reservation",
     * operationId="listReservationManager",
     *
     * @SWG\Parameter(
     * name="page",
     * in="query",
     * description="Page of view",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="event_id",
     * in="query",
     * description="Event id",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="status",
     * in="query",
     * description="Reservation status",
     * required=true,
     * type="string",
     * @SWG\Items(
     *    type="string",
     *    enum={"approved", "pending", "canceled"},
     *    default="approved"
     * )
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function indexManager(Request $request)
    {
        $user = auth('api')->user();;

        $data = $request->only("event_id", "status");

        $places = Place::where("user_id", "=", $user->id)->pluck('id')->toArray();
        $ids = Event::whereIn("place_id", $places)
            ->where("id", "=", $data['event_id'])
            ->pluck('id')
            ->toArray();

        $reservations = Reservation::with("event", "table", "user")
            ->where("event_id", $ids)
            ->where("status", "=", $data['status'])
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return response()->json($reservations);
    }

    /**
     *
     * @SWG\Get(
     * tags={"Reservation"},
     * path="/reservation/{id}",
     * description="Returns reservation by id",
     * produces={"application/json"},
     * summary="List of places",
     * operationId="listPlaces",
     *
     * @SWG\Parameter(
     * name="id",
     * in="path",
     * description="Reservation id",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function getReservationById($id)
    {
        $user = auth('api')->user();
        $reservations = Reservation::with("event", "table", "user")->findOrFail($id);

        if ($user && $reservations) {
            if ($user->id == $reservations->user_id) {
                return response()->json($reservations);
            }
            if ($user->id == $reservations->manager_id) {
                return response()->json($reservations);
            }
        }

        return response()->json([]);
    }


    /**
     *
     * @SWG\Post(
     * tags={"Reservation"},
     * path="/reservation/save",
     * description="Make reservation as authenticated user",
     * produces={"application/json"},
     * summary="Make reservation",
     * operationId="reserve",
     *
     * @SWG\Parameter(
     * name="event_id",
     * in="query",
     * description="Event id",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="table_id",
     * in="query",
     * description="Table id",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="person_num",
     * in="query",
     * description="Person number",
     * required=false,
     * type="integer"
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function reserve(Request $request)
    {
        $data = $request->only('event_id', 'table_id', 'person_num', 'is_manual', 'customer_name');
        $user = auth('api')->user();

        $event = Event::with("place")->findOrFail($data['event_id']);
        $isManager = $event->place->user_id == $user->id && ($user->role == 'manager' || $user->role == 'admin');

        $table = Table::findOrFail($data['table_id']);

        if ($isManager) {
            // ako vec postoji prihvacena rezervacija za ovaj sto za ovaj event, otkazi je
            $reservationExists = Reservation::where([
                ['event_id', '=', $data['event_id']],
                ['table_id', '=', $data['table_id']],
                ['status', '=', 'approved']
            ])->first();
            if ($reservationExists) {
                $this->setStatusInternal('canceled', $reservationExists->reservation_id);
            }
        } else {
            // ako vec ima odobrenu rezervaciju za ovaj event
            if ($user->countReservationsForEvent($data['event_id'], 'approved') > 0) {
                return response()->json(['error' => 'user_has_been_approved_for_one_of_events'], 500);
            }

            // ako vec ima 2 pending rezervacije za ovaj datum
            if ($user->countReservationsForDate($event->event_date, 'pending') > 2) {
                return response()->json(['error' => 'to_many_reservation_on_this_day'], 500);
            }

            // ako vec ima 2 odobrene rezervacije za ovaj datum
            if ($user->countReservationsForDate($event->event_date, 'approved') > 2) {
                return response()->json(['error' => 'to_many_reservation_on_this_day'], 500);
            }

            // ako je vec odbijen preko 2 put za ovaj event
            if ($user->countReservationsForEvent($data['event_id'], 'canceled') > 2) {
                return response()->json(['error' => 'to_many_table_reservation_for_event'], 500);
            }
        }

        $pernson_num = isset($data['person_num']) ? $data['person_num'] : 0;
        $pernson_num = ($pernson_num < 1) ? 1 : $pernson_num;

        $res = new Reservation();
        $res->person_num = $pernson_num;
        $res->event_date = $event->event_date;
        $res->is_manual = $data['is_manual'];
        $res->status = $data['is_manual'] ? 'approved' : 'pending';
        $res->customer_name = $data['customer_name'];
        $res->user()->associate($user);
        $res->event()->associate($event);
        $res->table()->associate($table);

        $manager = User::findOrFail($event->place->user_id);
        $res->manager()->associate($manager);

        if ($res->save()) {
            // todo: delete user request from waitlist if exists
            $waitlists = EventWaitlist::where([
                ['event_id', '=', $event->id],
                ['user_id', '=', $user->id],
                ['table_id', '=', $table->id]
            ])->with(['user', 'table', 'event'])->get();
            if ($waitlists->isNotEmpty()){
                // iterate through the Collection
                foreach ($waitlists as $waitlist) {
                    $waitlist->delete();
                }
            }
            if (!$isManager) {
                $manager->notify(new ReservationRequested($user, $event, $res->id));
            }

            return response()->json($res);
        }

        return response()->json(['error' => 'could_not_create_reservation'], 500);
    }


    /**
     *
     * @SWG\Get(
     * tags={"Reservation"},
     * path="/reservation/count",
     * description="Count approved reservation",
     * produces={"application/json"},
     * summary="Count approved reservation",
     * operationId="count",
     *
     *
     * @SWG\Parameter(
     * name="start_date",
     * in="query",
     * description="Start date format YYYY-mm-dd",
     * required=false,
     * type="string",
     * format="date",
     *
     * ),
     *
     * @SWG\Parameter(
     * name="end_date",
     * in="query",
     * description="End date format YYYY-mm-dd",
     * required=false,
     * type="string",
     * format="date",
     *
     * ),
     *
     * @SWG\Parameter(
     * name="status",
     * in="query",
     * description="Status of reservation",
     * required=false,
     * type="string",
     * @SWG\Items(
     *    type="string",
     *    enum={"approved", "pending", "canceled"},
     *    default="approved"
     * ),
     *
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function count(Request $request)
    {
        $result = 0;
        $data = $request->only('start_date', 'end_date', 'status');
        $user = auth('api')->user();
        if ($user) {

            $places = Place::where('user_id', '=', $user->id)->pluck('id')->toArray();
            $ids = Event::whereIn('place_id', $places)->pluck('id')->toArray();

            $dateS = new Carbon($data['start_date']);
            if ($data['start_date'] == null) $dateS->subMonth(1);
            $dateE = new Carbon($data['end_date']);

            $status = isset($data['status']) ? $data['status'] : "approved";

            $result = Reservation::whereIn('event_id', $ids)
                ->whereBetween("event_date", [$dateS->format("Y-m-d"), $dateE->format("Y-m-d")])
                ->where("status", "=", $status)
                ->get()
                ->count();
        }

        return response()->json($result);
    }

    /**
     *
     * @SWG\Post(
     * tags={"Reservation"},
     * path="/reservation/status",
     * description="Set status to reservation",
     * produces={"application/json"},
     * summary="Set status to reservation",
     * operationId="status",
     *
     * @SWG\Parameter(
     * name="reservation_id",
     * in="query",
     * description="Reservation id",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="status",
     * in="query",
     * description="New status",
     * required=true,
     * type="string",
     * @SWG\Items(
     *    type="string",
     *    enum={"approved", "pending", "canceled"},
     *    default="approved"
     * )
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function setStatus(Request $request)
    {
        $data = $request->only('status', 'reservation_id');

        $result = $this->setStatusInternal($data['status'], $data['reservation_id']);

        if ($result->status) {
            return response()->json(["status" => $result->message]);
        } else {
            return response()->json(['error' => $result->message], 500);
        }
    }

    private function setStatusInternal($status, $reservation_id) {
        $result = new \stdClass();
        $user_manager = auth('api')->user();
        $reservation = Reservation::with('event', 'table')->findOrFail(intval($reservation_id));
        $user = User::findOrFail($reservation->user_id);

        $manager_place = $user_manager->places()->get()->pluck("id")->toArray();
        $reservation_event = $reservation->event()->get()->first();
        $reservation_table = $reservation->table()->get()->first();

        if (in_array($reservation_event->place_id, (array)$manager_place)) {
//            if ($data['status'] == "approved") {
//                if ($user->checkTodayReservation($reservation->event_date)) {
//                    return response()->json(['error' => 'reservation_exist_on_this_event'], 500);
//                }
//            }

            // TODO
            // Ako korisnik vec ima approved rezervaciju za ovaj event
            // vrati error


            if ($status == 'approved'){
                $reservationExists = Reservation::where([
                    ['event_id', '=', $reservation_event->id],
                    ['user_id', '=', $user->id],
                    ['status', '=', 'approved']
                ])->first();
    
                if ($reservationExists){
                    $result->status = false;
                    $result->message  =  'reservation_already_exist_for_this_user_this_event';
                    return $result;
                }
            }

            $reservation->status = $status;
            if ($reservation->save()) {
                // todo: delete user request from waitlist if exists
                $waitlists = EventWaitlist::where([
                    ['event_id', '=', $reservation_event->id],
                    ['user_id', '=', $user->id],
                    ['table_id', '=', $reservation_table->id]
                ])->with(['user', 'table', 'event'])->get();
                if ($waitlists->isNotEmpty()){
                    // iterate through the Collection
                    foreach ($waitlists as $waitlist) {
                        $waitlist->delete();
                    }
                }
                if (!$reservation->is_manual) {
                    $user->notify(new ReservationProcessed($reservation));
                }
                $result->status = true;
                $result->message  =  "true";
                return $result;
            }

        }

        $result->status = false;
        $result->message  =  'you_cant_edit_status';
        return $result;
    }

    public function cancel(Request $request) {
        $data = $request->only('reservation_id');
        $user = auth('api')->user();

        $reservation = Reservation::with('manager', 'user', 'event')->findOrFail($data['reservation_id']);

        if ($reservation->user_id != $user->id) {
            abort(500);
        }

        $shouldNotify = $reservation->status == 'approved';

        $reservation->status = 'user-canceled';
        $reservation->save();

        if ($shouldNotify) {
            $reservation->manager()->first()->notify(new ReservationUserCanceled($reservation->user()->first(), $reservation->event()->first(), $reservation->id));

//            $waitlist = EventWaitlist::where('event_id', '=', $reservation->event_id)->get();
//
//            $notifiedUsers = array();
//            foreach ($waitlist as $item) {
//                $tableSelected = $item->table_id != null;
//                $isCurrentTable = $item->table_id == $reservation->table_id;
//
//                if (($tableSelected && $isCurrentTable) || !$tableSelected) {
//                    if (!in_array($item->user_id, $notifiedUsers)) {
//                        $waitlistUser = User::find($item->user_id);
//                        Notification::send($waitlistUser, new EventWaitlistAvailable($reservation->event()->first()));
//                        $notifiedUsers[] = $item->user_id;
//                    }
//                }
//            }
        }

        return response()->json(['result' => true]);
    }
}
