<?php

namespace App\Http\Controllers\Api;

use App\Place;
use App\Table;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;

class TableController extends Controller
{
    /**
     * @SWG\Get(
     * tags={"Tables"},
     * path="/place/{id}/tables/{event_id}",
     * description="Returns active tables for specific place id",
     * produces={"application/json"},
     * summary="All active tables by place id",
     * operationId="tables",
     *
     * @SWG\Parameter(
     * name="id",
     * in="path",
     * description="Id of place",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="event_id",
     * in="path",
     * description="Id of Event",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function index($id, $event_id)
    {
        $result = Table::with(['reservations' => function ($q) use ($event_id) {
            $q->with('user')->where("status", "=", "approved")->where("event_id", "=", $event_id);
        }])
            ->where("place_id", "=", $id)
            ->where("status", "=", "active")
            ->get();

        return response()->json($result);
    }


    /**
     * @SWG\Get(
     * tags={"Tables"},
     * path="/place/{id}/tables/all",
     * description="Returns tables for specific place id",
     * produces={"application/json"},
     * summary="All place tables by place id",
     * operationId="tables",
     *
     * @SWG\Parameter(
     * name="id",
     * in="path",
     * description="Id of place",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function managerTables($id)
    {
        return response()->json(Table::where("place_id", "=", $id)->get());
    }

    /**
     * @SWG\Get(
     * tags={"Tables"},
     * path="/place/tables/{id}",
     * description="Returns table for specific id",
     * produces={"application/json"},
     * summary="Returns table for specific id",
     * operationId="tablesById",
     *
     * @SWG\Parameter(
     * name="id",
     * in="path",
     * description="Id of place",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function getTableByID($id)
    {
        return response()->json(Table::with('place')->findOrFail($id));
    }


    /**
     * @SWG\Post(
     * tags={"Tables"},
     * path="/place/{id}/tables/add",
     * description="Add table to specific place id",
     * produces={"application/json"},
     * summary="Add table to specific place id",
     * operationId="tablesAdd",
     *
     * @SWG\Parameter(
     * name="id",
     * in="path",
     * description="Id of place",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="table_num",
     * in="query",
     * description="Number of this table",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="name",
     * in="query",
     * description="Name of this table",
     * required=true,
     * type="string"
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function addTable(Request $request)
    {
        $rules = array(
            'table_num' => 'required|numeric',
            'name' => "required|min:3",
        );

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json(["error" => $validator->errors()->all()], 500);
        }

        $place = Place::findOrFail($request->id);

        $user = auth('api')->user();
        if ($place->user_id != $user->id) {
            return response()->json(["error" => "unauthorized"], 401);
        }

        $tableNum = $request->get("table_num");
        $name = $request->get("name");

        // Check if table_num is same for this place
        $tableExists = Table::where([
            ['place_id', '=', $place->id],
            ['table_num', '=', $tableNum]
        ])->first();

        if ($tableExists){
            return response()->json(['error' => 'table_with_same_num_already_exists'], 500);
        }

        $request->request->set('status', "active");

        $table = new Table();
        $table->place()->associate($place);
        $table->table_num = $request->get("table_num");
        $table->status = "active";
        $table->name = $request->get("name");

        if ($table->save()) {
            return response()->json($table);
        }

        return response()->json(["error" => "something went wrong"], 500);
    }

    /**
     * @SWG\Post(
     * tags={"Tables"},
     * path="/place/{id}/tables/edit/{table_id}",
     * description="Edit table to specific place id",
     * produces={"application/json"},
     * summary="Edit table to specific place id",
     * operationId="tablesEdit",
     *
     * @SWG\Parameter(
     * name="id",
     * in="path",
     * description="Id of place",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="table_id",
     * in="path",
     * description="Id of table",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="table_num",
     * in="query",
     * description="Number of this table",
     * required=false,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="name",
     * in="query",
     * description="Name of this table",
     * required=false,
     * type="string"
     * ),
     *
     * @SWG\Parameter(
     * name="status",
     * in="query",
     * description="Status of table",
     * required=false,
     * type="string",
     * @SWG\Items(
     *    type="string",
     *    enum={"active", "disabled"},
     *    default="active"
     * )
     * ),
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function editTable(Request $request)
    {
        $rules = array(
            'table_num' => 'numeric',
            'name' => "min:3",
        );

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json(["error" => $validator->errors()->all()], 500);
        }

        $table = Table::with("place")->findOrFail($request->table_id);

        $user = auth('api')->user();
        if ($table->place->user_id != $user->id) {
            return response()->json(["error" => "unauthorized"], 401);
        }

        if($table->update($request->all())) {
            return response()->json($table);
        }

        return response()->json(["error" => "something went wrong"], 500);
    }


    /**
     * @SWG\Delete(
     * tags={"Tables"},
     * path="/place/{id}/tables/delete/{table_id}",
     * description="Delete table to specific place id",
     * produces={"application/json"},
     * summary="Delete table to specific place id",
     * operationId="tablesDelete",
     *
     * @SWG\Parameter(
     * name="id",
     * in="path",
     * description="Id of place",
     * required=true,
     * type="integer"
     * ),
     *
     * @SWG\Parameter(
     * name="table_id",
     * in="path",
     * description="Id of table",
     * required=true,
     * type="integer"
     * ),
     *
     *
     * @SWG\Response(response=200, description="successful operation"),
     * @SWG\Response(response=500, description="could not create token")
     * )
     */
    public function deleteTable(Request $request)
    {

        $table = Table::with("place")->findOrFail($request->table_id);

        $user = JWTAuth::parseToken()->authenticate();
        if ($table->place->user_id != $user->id) {
            return response()->json(["error" => "unauthorized"], 401);
        }

        if($table->delete()) {
            return response()->json(["status"=>"ok"]);
        }

        return response()->json(["error" => "something went wrong"], 500);
    }
}
