<?php

namespace App\Http\Middleware;

use App\User;
use Closure;

class UserLanguage
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if ($user = auth('api')->user()) {
            if ($lang = $request->header('AppLanguage')) {
                if ($lang == 'cg') {
                    $user->lang = User::LANG_CG;
                    $user->save();
                }
                if ($lang == 'en') {
                    $user->lang = User::LANG_EN;
                    $user->save();
                }
            }
        }
        return $next($request);
    }
}
