<?php
/**
 * Created by PhpStorm.
 * User: Armin
 * Date: 18-Apr-2017
 * Time: 10:14
 */

namespace App\Http\Middleware;

use Closure;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;
use Tymon\JWTAuth\Facades\JWTAuth;

class UserApiPermission
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next, $role)
    {
        $action = $action = $request->route()->getAction();

        if (!$user = auth('api')->user()) {
            return response()->json(['user_not_found'], 404);
        }

        $roles = explode('|', $role);
        foreach ($roles as $r) {
            if($user->hasRole($r)) {
                return $next($request);
            }
        }

        return response()->json(['Unauthorized'], 401);
    }

}
