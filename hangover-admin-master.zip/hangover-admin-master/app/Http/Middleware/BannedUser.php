<?php

namespace App\Http\Middleware;

use App\User;
use Closure;

class BannedUser
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if ($user = auth('api')->user()) {
            if ($user->active) {
                return $next($request);
            } else {
                return response('Not allowed', 418);
            }
        }
        return $next($request);
    }
}
