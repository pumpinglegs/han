<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EventWaitlist extends Model
{
    protected $table = 'event_waitlist';

    protected $fillable = ['user_id', 'event_id', 'table_id'];
    
    public function user()
    {
        return $this->belongsTo("App\\User", "user_id");
    }
    
    public function event()
    {
        return $this->belongsTo("App\\Event", "event_id");
    }
    
    public function table()
    {
        return $this->belongsTo("App\\Table", "table_id");
    }
}
