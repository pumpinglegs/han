<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserReport extends Model
{
    protected $fillable = ['description', 'user_id', 'manager_id'];

    public function user()
    {
        return $this->belongsTo("App\\User", "user_id");
    }

    public function manager()
    {
        return $this->belongsTo("App\\User", "manager_id");
    }
}
