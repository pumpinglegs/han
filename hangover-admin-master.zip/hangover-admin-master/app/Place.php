<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Place extends Model
{
    protected $fillable = ["name", "description", "phone", "location", "address", "user_id", "city_id", "address", 'site_url', 'fb_url', 'ins_url', 'logo', 'schema_image', 'priority'];

    public function city()
    {
        return $this->belongsTo("App\\Location", "city_id");
    }

    public function user()
    {
        return $this->belongsTo("App\\User", "user_id");
    }

    public function events()
    {
        return $this->hasMany("App\\Event");
    }

    public function sliders()
    {
        return $this->hasMany("App\\Slider");
    }

    public function tables()
    {
        return $this->hasMany("App\\Table");
    }
}
