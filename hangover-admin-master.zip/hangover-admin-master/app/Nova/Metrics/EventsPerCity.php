<?php

namespace App\Nova\Metrics;

use Illuminate\Support\Facades\DB;
use Laravel\Nova\Http\Requests\NovaRequest;
use Laravel\Nova\Metrics\Partition;

class EventsPerCity extends Partition
{
    /**
     * Calculate the value of the metric.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return mixed
     */
    public function calculate(NovaRequest $request)
    {
        //return $this->count($request, Model::class, 'groupByColumn');

        $eventsCount = DB::select("SELECT count(e.id) as total, p.city_id, l.name FROM events e INNER JOIN places p ON p.id = e.place_id INNER JOIN locations l ON p.city_id = l.id GROUP BY p.city_id, l.name");

        $result = [];
        foreach ($eventsCount as $item) {
            $result[$item->name] = $item->total;
        }

        return $this->result($result);
    }

    /**
     * Determine for how many minutes the metric should be cached.
     *
     * @return  \DateTimeInterface|\DateInterval|float|int
     */
    public function cacheFor()
    {
        // return now()->addMinutes(5);
    }

    /**
     * Get the URI key for the metric.
     *
     * @return string
     */
    public function uriKey()
    {
        return 'events-per-city';
    }
}
