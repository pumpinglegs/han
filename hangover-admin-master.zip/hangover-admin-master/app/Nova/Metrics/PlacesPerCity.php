<?php

namespace App\Nova\Metrics;

use App\Location;
use App\Place;
use Illuminate\Support\Facades\DB;
use Laravel\Nova\Http\Requests\NovaRequest;
use Laravel\Nova\Metrics\Partition;

class PlacesPerCity extends Partition
{
    /**
     * Calculate the value of the metric.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return mixed
     */
    public function calculate(NovaRequest $request)
    {
        $locations = Location::all()->mapToDictionary(function ($item, $key) {
            return [$item['id'] => $item['name']];
        })->toArray();

        $result = DB::table('places')
            ->select(DB::raw('count(id) as total'), DB::raw('city_id'))
            ->groupBy(DB::raw('city_id') )
            ->get();

        $mapped = [];
        foreach ($result as $res) {
            $mapped[$locations[$res->city_id][0]] = $res->total;
        }

        return $this->result($mapped);
    }

    /**
     * Determine for how many minutes the metric should be cached.
     *
     * @return  \DateTimeInterface|\DateInterval|float|int
     */
    public function cacheFor()
    {
        // return now()->addMinutes(5);
    }

    /**
     * Get the URI key for the metric.
     *
     * @return string
     */
    public function uriKey()
    {
        return 'places-per-city';
    }
}
