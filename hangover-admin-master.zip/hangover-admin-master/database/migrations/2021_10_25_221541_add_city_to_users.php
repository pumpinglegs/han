<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddCityToUsers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
//
//        Schema::table('users', function (Blueprint $table) {
//            $table->date('date_of_birth')->nullable()->default(null);
//            $table->enum('gender', ['male', 'female']);
//            $table->unsignedBigInteger('city_id')->nullable()->default(null);
//            $table->foreign('city_id')->references('id')->on('locations');
//        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('date_of_birth');
            $table->dropColumn('gender');
            $table->dropColumn('city_id');
        });
    }
}
