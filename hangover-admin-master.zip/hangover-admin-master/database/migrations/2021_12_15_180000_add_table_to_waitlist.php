<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddTableToWaitlist extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
       Schema::table('event_waitlist', function (Blueprint $table) {
           $table->unsignedBigInteger('table_id')->nullable()->default(null);
       });
    }

    /**   
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('event_waitlist', function (Blueprint $table) {
            $table->dropColumn('table_id');
        });
    }
}
