<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('first_name')->default("");
            $table->string('last_name')->default("");
            $table->string('email')->nullable()->default("");
            $table->string('username')->unique()->nullable();
            $table->string("phone")->unique()->nullable();
            $table->string('password');
            $table->tinyInteger('active')->default(0);
            $table->string("image")->default("");

            $table->integer("ban_count")->nullable()->default(0);
            $table->index('username');

            $table->enum('role', ['admin', 'manager', 'user'])->default("user");
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
